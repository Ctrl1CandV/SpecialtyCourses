#!/usr/bin/env python3
"""Validate student-only exam JSON and produce editable Markdown and print PDFs.

Use the bundled Codex Python runtime with reportlab, pypdf and pypdfium2.
No answer data is read or emitted by this tool. All input is in 试题源稿.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '资料整理' / '六套模拟卷成稿'
SOURCE = OUT / '试题源稿'
PDF_DIR = OUT / '学生卷PDF'
MD_DIR = OUT / '可编辑试题'
QA_DIR = ROOT / '_tmp' / 'exam_production' / 'rendered'
SECTIONS = {'I': ('一 程序阅读', 4, 20), 'II': ('二 单项选择', 10, 30),
            'III': ('三 综合应用', 7, 70), 'IV': ('四 算法设计与分析', 3, 30)}
INTRO = [
    '满分150分　考试时间180分钟',
    '姓名：________________　准考证号：________________',
    '请在另纸或答题纸上作答。单项选择题每题只有一个正确选项。',
    '程序使用C或类C记法；未特别说明时，数组下标从0开始，整数运算不溢出，辅助容器容量足够。算法题可用C、C++或语义明确的类C伪代码。',
    '不使用计算器。各题独立，题内约定优先于本页统一约定。',
]


def load_paper(paper: int) -> dict:
    data = json.loads((SOURCE / f'第{paper}套.json').read_text(encoding='utf-8-sig'))
    # The print font lacks these mathematical glyphs. Use explicit equivalent
    # notation in both editable text and PDF; never emit an invisible operand.
    replacements = {'−': '-', '–': '-', '—': '-', '‑': '-', '∅': 'NULL', '₀': '_0', '₁': '_1', '₂': '_2',
                    'ᵢ': '_i', 'ₖ': '_k', 'ₙ': '_n', '\u00a0': ' ', '↔': '<->'}
    for q in data.get('questions', []):
        q['content'] = re.sub(r'⌊([^⌊⌋]+)⌋', r'floor(\1)', q['content'])
        for old, new in replacements.items():
            q['content'] = q['content'].replace(old, new)
    return data


def validate(data: dict) -> list[str]:
    errors = []
    paper = data.get('paper')
    rows = data.get('questions', [])
    if paper not in range(1, 7) or len(rows) != 24:
        errors.append(f'paper={paper}: expected 24 questions')
    ids = set()
    for section, (_, count, points) in SECTIONS.items():
        group = [q for q in rows if q.get('section') == section]
        if len(group) != count or sum(q.get('points', 0) for q in group) != points:
            errors.append(f'S{paper}-{section}: section count/points mismatch')
        if [q.get('number') for q in group] != list(range(1, count+1)):
            errors.append(f'S{paper}-{section}: numbering mismatch')
    for i, q in enumerate(rows):
        qid = q.get('id', '')
        section = q.get('section')
        expected_id = f'S{paper}-{section}{q.get("number", 0):02d}'
        if qid != expected_id or qid in ids:
            errors.append(qid + ': duplicate or invalid ID')
        ids.add(qid)
        expected_points = [8,10,12][q['number']-1] if section == 'IV' else {'I':5,'II':3,'III':10}.get(section)
        if q.get('points') != expected_points:
            errors.append(qid + ': invalid points')
        if set(q) - {'id','section','number','points','content'}:
            errors.append(qid + ': student source contains unexpected metadata fields')
        body = q.get('content', '')
        if not isinstance(body, str) or len(body.strip()) < 25:
            errors.append(qid + ': incomplete question')
            continue
        if re.search(r'参考答案|答案蓝图|正确选项[为是：:]|教师答案|【答案】|评分细则|来源ID|待补齐|选用原题|TODO', body):
            errors.append(qid + ': teacher material or placeholder in student text')
        if body.count('```') % 2:
            errors.append(qid + ': unclosed code block')
        if section == 'II':
            choices = re.findall(r'^([ABCD])[.．、]\s*', body, re.M)
            if choices != ['A','B','C','D']:
                errors.append(qid + ': exactly four ordered choices required')
            options = re.findall(r'^[ABCD][.．、]\s*(.+)$', body, re.M)
            if len({re.sub(r'\s+', '', x) for x in options}) != 4:
                errors.append(qid + ': duplicate choice text')
        else:
            parts = [int(x) for x in re.findall(r'[（(]\s*(\d+)\s*分\s*[）)]', body)]
            if sum(parts) != q['points']:
                errors.append(qid + f': subquestion points {parts} != {q["points"]}')
        if section == 'I' and '```' not in body:
            errors.append(qid + ': reading question missing code')
    return errors


def markdown(data: dict) -> str:
    paper = data['paper']
    lines = [f'# 2027考研重邮802数据结构模拟试卷 第{paper}套', '']
    for s in INTRO:
        lines += [s, '']
    current = None
    for index, q in enumerate(data['questions'], 1):
        if q['section'] != current:
            current = q['section']
            title, count, points = SECTIONS[current]
            lines += [f'## {title}（共{count}题，{points}分）', '']
        lines += [f'### {index}（{q["points"]}分）', '', q['content'].strip(), '']
    return '\n'.join(lines)


def split_blocks(body: str):
    """Small predictable Markdown subset: paragraphs, fenced code and tables."""
    lines = body.strip().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith('```'):
            i += 1
            block = []
            while i < len(lines) and not lines[i].strip().startswith('```'):
                block.append(lines[i].rstrip())
                i += 1
            yield 'code', '\n'.join(block)
            i += 1
        elif line.startswith('|') and i+1 < len(lines) and re.match(r'^\|[\s:|-]+\|$', lines[i+1].strip()):
            block = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                entry = lines[i].strip()
                if not re.match(r'^\|[\s:|-]+\|$', entry):
                    block.append([x.strip().replace(r'\|','|') for x in re.split(r'(?<!\\)\|',entry.strip('|'))])
                i += 1
            yield 'table', block
        else:
            block = [line]
            i += 1
            while i < len(lines) and lines[i].strip() and not lines[i].strip().startswith(('```','|')):
                if re.match(r'^(?:[ABCD][.．、]|[（(]\d+[）)]|\d+[.．])', lines[i].strip()):
                    break
                block.append(lines[i].strip())
                i += 1
            yield 'paragraph', ' '.join(block)


def rich(text: str) -> str:
    value = html.escape(text)
    value = re.sub(r'`([^`]+)`', lambda m: m.group(1), value)
    value = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', value)
    value = re.sub(r'([\u4e00-\u9fff，。、；？]{1,5}（\d+分）)$', r'<nobr>\1</nobr>', value)
    return value


def init_pdf():
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfbase import pdfmetrics
    from reportlab.lib import textsplit
    from reportlab.platypus import paragraph
    # ReportLab's default kinsoku list omits common Chinese fullwidth marks.
    # Let one closing mark hang at the preceding line's edge instead of
    # starting the next line with punctuation.
    for module in (textsplit, paragraph):
        module.ALL_CANNOT_START += '，；：？！'
    font_dir = Path('C:/Windows/Fonts')
    pdfmetrics.registerFont(TTFont('ExamSong', str(font_dir/'simsun.ttc'), subfontIndex=0))
    pdfmetrics.registerFont(TTFont('ExamHei', str(font_dir/'simhei.ttf')))
    pdfmetrics.registerFontFamily('ExamSong', normal='ExamSong', bold='ExamHei', italic='ExamSong', boldItalic='ExamHei')


def check_font_coverage(datasets):
    from reportlab.pdfbase import pdfmetrics
    cmap = pdfmetrics.getFont('ExamSong').face.charToGlyph
    for data in datasets:
        for q in data['questions']:
            missing = sorted({c for c in q['content'] if ord(c) > 32 and ord(c) not in cmap})
            if missing:
                raise ValueError(f'{q["id"]}: unsupported print glyphs: {missing}')


def build_pdf(data: dict, target: Path):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, XPreformatted, CondPageBreak

    class CodeBlock(XPreformatted):
        def split(self, available_width, available_height):
            return []

    paper = data['paper']
    margin = 19*mm
    width = A4[0]-2*margin
    body_style = ParagraphStyle('Body', fontName='ExamSong', fontSize=10.5, leading=15,
                                spaceAfter=5, wordWrap='CJK', allowWidows=0, allowOrphans=0)
    section_style = ParagraphStyle('Section', parent=body_style, fontName='ExamHei', fontSize=12.5,
                                   leading=19, spaceBefore=6, spaceAfter=10, keepWithNext=True)
    number_style = ParagraphStyle('Number', parent=body_style, fontName='ExamHei', spaceBefore=8, spaceAfter=4, keepWithNext=True)
    title_style = ParagraphStyle('Title', parent=body_style, fontName='ExamHei', fontSize=17, leading=23, alignment=TA_CENTER, spaceAfter=7)
    info_style = ParagraphStyle('Info', parent=body_style, fontSize=10, leading=14, spaceAfter=4)
    code_style = ParagraphStyle('Code', fontName='ExamSong', fontSize=9.5, leading=12.5, leftIndent=8, spaceBefore=4, spaceAfter=7)
    cell_style = ParagraphStyle('Cell', parent=body_style, fontSize=10, leading=14, alignment=TA_CENTER, spaceAfter=0)
    doc = SimpleDocTemplate(str(target), pagesize=A4, rightMargin=margin, leftMargin=margin,
                            topMargin=18*mm, bottomMargin=17*mm,
                            title=f'2027考研重邮802数据结构模拟试卷 第{paper}套', author='', subject='学生试卷')
    story = [Paragraph('2027考研重邮802数据结构模拟试卷', title_style),
             Paragraph(f'第{paper}套', ParagraphStyle('PaperNo', parent=title_style, fontSize=14, leading=20))]
    for line in INTRO:
        story.append(Paragraph(rich(line), info_style))
    story.append(Spacer(1,5))
    current = None
    for index, q in enumerate(data['questions'], 1):
        group = []
        if q['section'] != current:
            current = q['section']
            title, count, points = SECTIONS[current]
            group.append(Paragraph(f'{title}（共{count}题，{points}分）', section_style))
        group.append(Paragraph(f'{index}．（{q["points"]}分）', number_style))
        for kind, value in split_blocks(q['content']):
            if kind == 'paragraph':
                # Put points beside the subquestion number, avoiding CJK line
                # breaking inside a trailing score at the right margin.
                match = re.match(r'^([（(]\d+[）)])\s*(.*?)\s*([（(]\d+分[）)])$', value)
                if match:
                    value = f'{match[1]}{match[3]} {match[2]}'
                group.append(Paragraph(rich(value), body_style))
            elif kind == 'code':
                # Protect code syntax and indent; never silently reflow a C line.
                from reportlab.pdfbase.pdfmetrics import stringWidth
                lines = value.splitlines()
                max_width = max((stringWidth(x, 'ExamSong', code_style.fontSize) for x in lines), default=0)
                if max_width > width-12:
                    raise ValueError(f'{q["id"]}: code line is too wide ({max_width:.1f} pt); wrap source explicitly')
                group.append(CodeBlock(html.escape(value), code_style))
            else:
                if not value or any(len(row) != len(value[0]) for row in value):
                    raise ValueError(q['id'] + ': malformed Markdown table')
                weights = [max(len(re.sub(r'`','',r[c])) for r in value) for c in range(len(value[0]))]
                weights = [max(4,min(24,x)) for x in weights]
                widths = [width*w/sum(weights) for w in weights]
                tbl = Table([[Paragraph(rich(c), cell_style) for c in row] for row in value], colWidths=widths, repeatRows=1, hAlign='LEFT')
                tbl.setStyle(TableStyle([
                    ('GRID',(0,0),(-1,-1),0.45,colors.HexColor('#D9D9D9')),
                    ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#EEEEEE')),
                    ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
                    ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),
                    ('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),
                ]))
                group.extend([tbl,Spacer(1,7)])
        group.append(Spacer(1,5))
        # Keep a question and its subparts together, and attach a section title
        # to its first question. Avoid nested KeepTogether: its synthetic height
        # can otherwise create a nearly empty page before a code question.
        story.append(KeepTogether(group))
    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont('ExamSong', 9)
        canvas.drawString(margin, 9*mm, f'重邮802数据结构模拟试卷  第{paper}套')
        canvas.drawRightString(A4[0]-margin, 9*mm, f'第{document.page}页')
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


def render_pdf(target: Path):
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(str(target))
    dest = QA_DIR / target.stem
    dest.mkdir(parents=True, exist_ok=True)
    for i in range(len(doc)):
        page = doc[i]
        bitmap = page.render(scale=1.5)
        bitmap.to_pil().save(dest/f'page-{i+1:02d}.png')
        bitmap.close()
        page.close()
    count = len(doc)
    doc.close()
    for old_page in dest.glob('page-*.png'):
        if int(old_page.stem.split('-')[-1]) > count:
            old_page.unlink()
    return count


def merge_all():
    from pypdf import PdfReader, PdfWriter
    writer = PdfWriter()
    for paper in range(1,7):
        path = PDF_DIR/f'重邮802模拟试卷第{paper}套.pdf'
        writer.append(PdfReader(path), outline_item=f'第{paper}套')
    target = OUT/'六套模拟试卷合订本.pdf'
    writer.add_metadata({'/Title':'2027考研重邮802数据结构六套模拟试卷','/Author':''})
    with target.open('wb') as f:
        writer.write(f)
    writer.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--papers', nargs='+', type=int, default=list(range(1,7)))
    args = parser.parse_args()
    datasets = [load_paper(p) for p in args.papers]
    errors = [e for data in datasets for e in validate(data)]
    if errors:
        raise SystemExit('\n'.join(errors))
    if args.build:
        PDF_DIR.mkdir(parents=True, exist_ok=True)
        MD_DIR.mkdir(parents=True, exist_ok=True)
        init_pdf()
        check_font_coverage(datasets)
    reports = []
    from pypdf import PdfReader
    for data in datasets:
        p = data['paper']
        target = PDF_DIR/f'重邮802模拟试卷第{p}套.pdf'
        if args.build:
            (MD_DIR/f'第{p}套试卷.md').write_text(markdown(data), encoding='utf-8')
            build_pdf(data, target)
        count = None
        if target.exists():
            pdf = PdfReader(target)
            count = len(pdf.pages)
            text = '\n'.join(page.extract_text() or '' for page in pdf.pages)
            if re.search('参考答案|答案蓝图|教师答案|评分细则|正确选项[为是：:]', text):
                raise SystemExit(f'Paper {p}: teacher content in PDF')
            for i in range(1,25):
                if not re.search(rf'(?m)^{i}[．.]\s*[（(]', text):
                    raise SystemExit(f'Paper {p}: question {i} missing in PDF text')
            if args.render:
                render_pdf(target)
        reports.append({'paper':p,'questions':24,'points':150,'pages':count,
                        'source_sha256':hashlib.sha256((SOURCE/f'第{p}套.json').read_bytes()).hexdigest()})
        print(f'PASS paper {p}: 24 questions, 150 points, {count} PDF pages')
    if args.build and sorted(args.papers) == list(range(1,7)):
        merge_all()
    if args.build:
        (OUT/'成卷结构核对.json').write_text(json.dumps({'papers':reports,'说明':'结构和题面无答案标记检查；不自动证明各选项唯一、数学结论正确或难度实测合格。'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__ == '__main__':
    main()
