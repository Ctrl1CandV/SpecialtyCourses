from pathlib import Path
import hashlib
import json
import zipfile
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '资料整理/六套模拟卷成稿'
PLAN = ROOT / '资料整理/六套模拟卷规划'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def content_sha(q):
    return hashlib.sha256(q['content'].encode('utf8')).hexdigest()

papers = [read(OUT / f'试题源稿/第{p}套.json') for p in range(1, 7)]
questions = {q['id']: q for p in papers for q in p['questions']}
rows = read(PLAN / '六套逐题蓝图.json')
assert len(questions) == len(rows) == 144
assert all(p['version'] == '2026-10-22-student-v3' for p in papers)
for r in rows:
    assert r['student_content_sha256'] == content_sha(questions[r['id']]), r['id']
audit = read(OUT / '内容复查核对.json')
assert audit['questions_reviewed'] == 144 and len(audit['changes']) == 29
for r in audit['changes']:
    assert r['student_sha256'] == content_sha(questions[r['id']]), r['id']
format_audit = read(OUT / '题型修订核对.json')
assert len(format_audit['changes']) == 102
for r in format_audit['changes']:
    assert r['student_sha256'] == content_sha(questions[r['id']]), r['id']

spec = read(OUT / '题型规范.json')
assert spec['version'] == '2026-10-22-format-v3'
assert sha(ROOT / spec['reference']) == spec['reference_sha256']
structure = read(OUT / '成卷结构核对.json')
texts, files = [], []
for p, summary in zip(papers, structure['papers']):
    n = p['paper']
    assert summary['source_sha256'] == sha(OUT / f'试题源稿/第{n}套.json')
    assert summary['questions'] == 24 and summary['points'] == 150
    pdf = OUT / f'学生卷PDF/重邮802模拟试卷第{n}套.pdf'
    md = OUT / f'可编辑试题/第{n}套试卷.md'
    pages = PdfReader(pdf).pages
    assert len(pages) == summary['pages'] == 19
    paper_texts = [page.extract_text() for page in pages]
    assert all(t.strip() for t in paper_texts)
    texts.extend(paper_texts)
    files.extend([pdf, md])
combined = OUT / '六套模拟试卷合订本.pdf'
reader = PdfReader(combined)
assert [page.extract_text() for page in reader.pages] == texts
assert len(reader.outline) == 6 and len(texts) == 114

readme = '''2027重邮802六套模拟试卷｜学生卷第3版
版本：2026-10-22-student-v3

本包包含六份独立PDF、六份可编辑Markdown及本说明，共13个文件。
每套24题、150分、180分钟：
一、程序阅读题4道，每道5分，共20分；一道复杂度、三道代码补全。
二、填空题10道，每道3分，共30分；无选择项。
三、综合应用题7道，每道10分，共70分。
四、算法设计与分析题3道，依次8、10、12分，共30分。

各大题内从1开始编号，请在卷内题后作答区写明空号和小问号。
程序空__1__等按编号作答；等价的正确表达式或语句可以作答。
程序阅读一题一页，填空每页5题，综合应用一题一页。
算法设计每题有题面页及整页续答区，请将过程和代码写在相应题后。
每套PDF19页，共114页，增加的页数用于书写过程、画图和代码。
Markdown与PDF使用同一学生题面源，PDF为正式打印版。

本轮复核全部144题，修改29道题面，包括全部24道程序阅读。
题型参照《真题24-25.pdf》，题数和分值以用户确认的固定安排为准。
内容以常考主干巩固和练习为目标，目标难度中等偏上。
六套预计作答用时依次169、172、171、165、174、176分钟，尚未经学生实测。
第5、6套复查时间较紧，建议审题时重点关注实际阅读和实现负担。
本包不含标准答案或教师参考代码；题面审定后再制作对应答案。
'''
archive = OUT / '六套学生卷_无答案.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for f in files:
        z.write(f, f.relative_to(OUT).as_posix())
    z.writestr('使用说明.txt', readme.encode('utf8'))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == 13
    for f in files:
        assert z.read(f.relative_to(OUT).as_posix()) == f.read_bytes()

times = [sum(r['minutes'] for r in rows if r['paper'] == p) for p in range(1, 7)]
assert times == [169, 172, 171, 165, 174, 176]
dbhash = sha(ROOT / '题库数据库/tiku.db').upper()
assert dbhash == '3F050FEA3CF82D0753DD24C8E518C0B1C49ED70C740B703D572A0B37E7B4D718'
manifest = {
    'date': '2026-10-22', 'version': '2026-10-22-student-v3',
    'format_version': spec['version'], 'design_version': '2026-10-22-r5',
    'student_questions': 144, 'total_points': 900,
    'pdf_pages': 114, 'pages_per_paper': [19] * 6, 'answers_produced': False,
    'files': [{'file': f.relative_to(OUT).as_posix(), 'sha256': sha(f), 'bytes': f.stat().st_size}
              for f in [combined, archive] + files],
    'source_checks': structure['papers'],
    'reference': spec['reference'], 'reference_sha256': spec['reference_sha256'],
    'student_content_hashes_checked': 144, 'changed_student_texts': 29,
    'extended_reading_questions': 24,
    'scope_policy': '常考主干巩固练习；不为覆盖率纳入新增或长期少考的非重点。35个内部练习单元已映射，不宣称全考纲覆盖。',
    'content_review': '144题分组独立复查，24道阅读跨组复核；修正提示泄漏、歧义、重复数据和算法实现负担。',
    'code_review': {'reading_compile_or_syntax_pass': 24, 'reading_main_run_pass': 21,
                    'external_interface_syntax_only': 3, 'extra_algorithm_boundary_check': 'S3-IV01'},
    'visual_review': '六套最终PDF共114页逐页检查；题面和主要作答区同页，无漏题、裁切或分值断行。',
    'combined_pdf_check': '114页逐页抽取文字与六份独立PDF按序拼接相同；6个分卷书签。',
    'archive_check': '13项；CRC通过；12份PDF/Markdown逐项字节相同。',
    'seed_verification': '21项检查覆盖16个既定综合/算法题位，签名未变；不代表全部144题自动核答。',
    'estimated_minutes': times, 'timing_empirically_validated': False,
    'limitations': ['第5、6套复查时间较紧，实际难度与用时需限时试做确认。',
                    '考纲使用此前存档的802转载副本，未核对原站附件与转载一致性。'],
    'database_sha256': dbhash, 'git_base': '4c819505ff381100aa8097a6bb4f3e7b56170d18'
}
(OUT / '交付核对.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print('PASS v3 delivery: 144 source hashes; 29 current and 102 prior-format hashes; 114 pages; 6 bookmarks; 13 ZIP entries; unchanged database.')
