from pathlib import Path
import json,hashlib,re,zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'资料整理/六套模拟卷成稿'
PLAN=ROOT/'资料整理/六套模拟卷规划'
HERE=Path(__file__).parent
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def h(s): return hashlib.sha256(s.encode('utf8')).hexdigest()
rows=read(PLAN/'六套逐题蓝图.json')
assert all(r['design_version']=='2026-10-22-r4' for r in rows),'Run migration once'
questions={q['id']:q for p in range(1,7) for q in read(OUT/f'试题源稿/第{p}套.json')['questions']}
with zipfile.ZipFile(PLAN/'历史版本/2026-10-22-r4/内容复查与留白调整前快照.zip') as z:
    before={q['id']:q for p in range(1,7) for q in json.loads(z.read(f'资料整理/六套模拟卷成稿/试题源稿/第{p}套.json'))['questions']}
reports=[]
for f in ('papers12_review.json','papers34_review.json','papers56_review.json'):
    d=read(HERE/f);reports+=d.get('reviews',d.get('questions',[]))
reviews={r['id']:r for r in reports}
assert len(reviews)==144
level={'基':'基','中':'中','辨':'辨','基础':'基','中等':'中','中上':'辨'}
root_fixes={
 'S2-I04':'填空外增加括号，避免条件表达式与加法的优先级歧义；严格编译运行复核。',
 'S5-I02':'用main中的动态尾插建表代替独立makeNode和重复从头扫描append，减少无关阅读；仍逐个分配和释放，严格编译运行复核。',
 'S5-I03':'共用判满函数承载待填式，删除会直接给出判满答案的重复条件与未调用pop0；严格编译运行复核。',
 'S6-I02':'将三组紧邻初始化/释放语句合行，保持完整程序同页；严格编译运行复核。'
}
changed=[]
for r in rows:
    q=questions[r['id']];check=reviews[r['id']];proposed=check.get('metadata_suggestion',{})
    # Scope and minute suggestions are review metadata, not source provenance.
    for key in ('title','chapter','tags','task_family'):
        if key in proposed:r[key]=proposed[key]
    r['minutes']=check['estimated_minutes']
    r['level']=level[check['difficulty']]
    r['time_reason']=f"扩充语境后预计{r['minutes']}分钟；为教师审稿估计，尚未经限时试做。"
    reason=check.get('change',check.get('change_reason','已逐题复查，题面保留。'))
    if r['id'] in root_fixes:reason+=' '+root_fixes[r['id']]
    differs=q['content']!=before[r['id']]['content']
    if differs:
        r['revision_note']+=' 2026-10-22第3版：'+reason
        parts=re.findall(r'([^\n]*?)[（(](\d+)分[）)]',q['content'])
        r['rubric']=[[re.sub(r'^[，、；。\s]+','',label.strip())[-160:] or f'得分项{i}',int(points)] for i,(label,points) in enumerate(parts,1)]
        assert sum(x[1] for x in r['rubric'])==r['points'],r['id']
        changed.append({'id':r['id'],'change':reason,'before_sha256':h(before[r['id']]['content']),'student_sha256':h(q['content'])})
    r['student_content_sha256']=h(q['content'])
    r['design_version']='2026-10-22-r5'
    r['review_version']='2026-10-22-quality-v3'

byid={r['id']:r for r in rows}
byid['S5-I02']['minutes']=8
byid['S5-I02']['time_reason']='删除无关的重复扫描建表后，由根代理与作者复核估为8分钟；仍未经学生限时试做。'
byid['S6-II01']['chapter']='栈队列'
byid['S2-II09']['data']='m=7，H(key)=key mod 7；依次插入20、13、8，等概率成功查找'
byid['S3-IV01']['task']='指出单次整表逆置的错误，完整实现reverse与rotateSegments，验证相邻两段原地轮换及空段边界'
byid['S3-IV01']['answer_blueprint']='题面已扩为两个完整C函数；待用户审定后制作对应答案、边界验证与评分细则。原地三次逆置思路保留。'
byid['S3-IV01']['evidence_required']='完整reverse和rotateSegments实现、空段处理、正确性及复杂度论证'
byid['S1-I01']['data']='readings[16]的采集读数；countOps(16)及一般n=2^k；只求visits与复杂度'
byid['S1-I01']['task']='在前缀累计场景中阅读countOps，求具体访问次数、一般返回值与时间复杂度'
write(PLAN/'六套逐题蓝图.json',rows)

# Existing numeric seeds cover III/IV slots unaffected by this task extension.
binding=read(PLAN/'核验输入绑定.json')
for qid,digest in binding['design_hashes'].items():
    payload={k:byid[qid].get(k,'') for k in ('task','data','answer_blueprint')}
    assert h(json.dumps(payload,ensure_ascii=False,sort_keys=True))==digest,qid
binding['version']='2026-10-22-r5'
binding['本轮内容复查说明']='第3版24道阅读扩充语境、若干题面约定修正；S3-IV01新增逆置辅助函数实现要求，不在本文件绑定中。现有16个综合/算法种子签名逐一验证未变。'
write(PLAN/'核验输入绑定.json',binding)

spec=read(OUT/'题型规范.json')
spec['version']='2026-10-22-format-v3'
spec['layout']={'authority':'用户本轮要求增加应用题和代码题的作答空间',
                'I':'每题独立页，题后作答区至少20mm；扩充有效代码语境',
                'II':'每页5题，各题另留空行',
                'III':'每题独立页，题后作答区至少85mm',
                'IV':'每题独立题面页及230mm续答页，题面页另有至少30mm作答区'}
write(OUT/'题型规范.json',spec)

summary={'version':'2026-10-22-quality-v3','baseline':'2026-10-22-student-v2','questions_reviewed':144,
         'changed_count':len(changed),'changes':changed,
         'reading_code_check':'24道阅读题补入一种可行实现后通过GCC C11严格编译或语法检查；其中21道含main程序运行核验，3道使用题设外部接口。未生成答案册。',
         'coverage':'常考核心，低频内容按用户取舍；详见考纲与重点覆盖复核.md',
         'difficulty_note':'难度及用时为内容审稿判断，尚无真实考生限时试做数据。',
         'question_reviews':[{'id':r['id'],'topic':r['title'],'chapter':r['chapter'],
                              'status':'已完成内容复查；题面待用户审定',
                              'review_dimensions':['题型及得分项','考纲范围与核心练习定位','数据和边界','可解性与工作量'],
                              'difficulty':r['level'],'estimated_minutes':r['minutes'],
                              'content_sha256':r['student_content_sha256']} for r in rows]}
write(OUT/'内容复查核对.json',summary)
# Keep the prior format audit traceable, and bind its entries to current text.
old=read(OUT/'题型修订核对.json')
old['version']='2026-10-22-student-v3'
old['说明']='题型修订记录保留前轮范围；哈希同步当前v3。当前轮29题内容变化另见内容复查核对.json。'
for entry in old['changes']:entry['student_sha256']=byid[entry['id']]['student_content_sha256']
write(OUT/'题型修订核对.json',old)
print('Reviewed144; changed',len(changed),'times',[sum(r['minutes'] for r in rows if r['paper']==p) for p in range(1,7)])
