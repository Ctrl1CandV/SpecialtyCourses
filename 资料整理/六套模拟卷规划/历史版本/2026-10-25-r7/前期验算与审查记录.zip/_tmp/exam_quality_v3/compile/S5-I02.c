#include <stdio.h>
#include <stdlib.h>
typedef struct Node { int data; struct Node *next; } Node;
Node *makeNode(int x) {
    Node *p = malloc(sizeof *p);
    if (p == NULL) exit(EXIT_FAILURE);
    p->data = x;
    p->next = NULL;
    return p;
}
void append(Node *head, int x) {
    Node *tail = head;
    while (tail->next != NULL) tail = tail->next;
    tail->next = makeNode(x);
}
void removeEven(Node *head) {
    Node *pre = head, *p = head->next;
    while (p != NULL) {
        if (p->data % 2 == 0) {
            pre->next = p->next;
            free(p);
            p = pre->next;
        } else {
            pre = p;
            p = p->next;
        }
    }
}
int main(void) {
    Node head = {0, NULL};
    const int input[] = {3, 8, 5, 6, 7};
    for (int i = 0; i < 5; ++i) append(&head, input[i]);
    removeEven(&head);
    Node *p = head.next;
    while (p != NULL) {
        Node *next = p->next;
        printf("%d ", p->data);
        free(p);
        p = next;
    }
    putchar('\n');
    return 0;
}
