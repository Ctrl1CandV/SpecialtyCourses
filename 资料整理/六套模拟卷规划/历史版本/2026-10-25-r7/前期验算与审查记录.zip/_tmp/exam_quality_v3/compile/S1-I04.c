#include <stdio.h>
typedef struct TNode {
    int data;
    struct TNode *left, *right;
} TNode;
int minLeafDepth(TNode *t) {
    if (t == NULL) return 0;
    if (t->left == NULL && t->right == NULL) return 1;
    if (t->left == NULL) return 1 + minLeafDepth(t->right);
    if (t->right == NULL) return 1 + minLeafDepth(t->left);
    int a = minLeafDepth(t->left);
    int b = minLeafDepth(t->right);
    return 1 + (a < b ? a : b);
}
void showDepth(const char *name, TNode *root) {
    printf("%s: %d\n", name, minLeafDepth(root));
}
int main(void) {
    TNode c = {3, NULL, NULL};
    TNode b = {2, NULL, &c};
    TNode a = {1, &b, NULL};
    TNode e = {5, NULL, NULL};
    TNode d = {4, &e, NULL};
    TNode root = {0, &a, &d};
    showDepth("single-child", &a);
    showDepth("branched", &root);
    showDepth("empty", NULL);
    return 0;
}
