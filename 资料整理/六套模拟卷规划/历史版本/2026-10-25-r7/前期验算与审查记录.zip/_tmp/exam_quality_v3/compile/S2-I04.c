#include <stdio.h>
#include <stdlib.h>
typedef struct TNode {
    struct TNode *left, *right;
} TNode;
int height(TNode *t) {
    if (t == NULL) return 0;
    int a = height(t->left), b = height(t->right);
    return 1 + (a > b ? a : b);
}
int isBalanced(TNode *t) {
    if (t == NULL) return 1;
    int leftOK = isBalanced(t->left);
    int rightOK = isBalanced(t->right);
    int d = height(t->left) - height(t->right);
    return leftOK && rightOK && abs(d) <= 1;
}
void report(const char *name, TNode *root) {
    printf("%s: height=%d, balanced=%d\n",
           name, height(root), isBalanced(root));
}
int main(void) {
    TNode left = {NULL, NULL}, right = {NULL, NULL};
    TNode balanced = {&left, &right};
    TNode c = {NULL, NULL}, b = {&c, NULL};
    TNode a = {&b, NULL};
    report("balanced", &balanced);
    report("single-chain", &a);
    report("empty", NULL);
    return 0;
}
