#include <stdio.h>
#include <stddef.h>
typedef struct Node {
    struct Node *left, *right;
} Node;
int heightOrFail(const Node *root) {
    if (root == NULL) return 0;
    int lh = heightOrFail(root->left);
    if (lh == -1) return -1;
    int rh = heightOrFail(root->right);
    if (rh == -1) return -1;
    if (lh - rh > 1 || rh - lh > 1) return -1;
    return 1 + (lh > rh ? lh : rh);
}
int isBalanced(const Node *root) {
    return heightOrFail(root) >= 0;
}
int main(void) {
    Node a = {NULL, NULL};
    Node b = {NULL, NULL};
    Node c = {NULL, NULL};
    Node left = {&a, &b};
    Node root = {&left, &c};
    printf("%d\n", isBalanced(&root));
    return 0;
}
