from pathlib import Path
import json, re, hashlib, zipfile
ROOT=Path(__file__).resolve().parents[2]
PLAN=ROOT/'资料整理/六套模拟卷规划'
OUT=ROOT/'资料整理/六套模拟卷成稿'
HERE=Path(__file__).parent
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def write(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=read(PLAN/'六套逐题蓝图.json')
assert all(r['design_version']=='2026-10-21-r3' for r in old), 'Run this migration only once'
meta=read(HERE/'papers12_revision.json')
meta.update({x['id']:x for x in read(HERE/'papers34_revision.json')})
m56=read(HERE/'papers56_revision.json')
meta.update({x['id']:x for x in m56['metadata_changes']})
meta.update({x['id']:{'revision_note':x['change']} for x in m56['iv_contract_clarifications']})
student={q['id']:q for n in range(1,7) for q in read(OUT/f'试题源稿/第{n}套.json')['questions']}
z=zipfile.ZipFile(PLAN/'历史版本/2026-10-21-r3/题型修正前快照.zip')
before={q['id']:q for n in range(1,7) for q in json.loads(z.read(f'资料整理/六套模拟卷成稿/试题源稿/第{n}套.json'))['questions']}

# Direct-source decisions were checked against the actual stored stems/PDF,
# rather than treating a changed question format as proof of originality.
direct={
 'S1-I02':(['真题-2024-阅读2'],'选用'),
 'S1-I03':(['真题-2025-阅读3'],'选用'),
 'S1-II03':(['真题-2024-填空1'],'改编'),
 'S1-II05':(['真题-2025-填空7'],'改编'),
 'S1-II06':(['真题-2024-填空9'],'选用'),
 'S1-II08':(['真题-2026-综合18'],'改编'),
 'S1-II09':(['408-2020-9'],'选用'),
 'S2-I01':(['真题-2025-阅读1'],'选用'),
 'S2-I02':(['真题-2025-阅读2'],'选用'),
 'S2-I03':(['真题-2026-阅读2'],'选用'),
 'S2-II02':(['真题-2026-填空12'],'改编'),
 'S2-II05':(['真题-2025-填空3'],'选用'),
 'S2-II06':(['408-2019-2'],'选用'),
 'S2-II08':(['真题-2026-填空13'],'改编'),
 'S3-I02':(['真题-2025-阅读4'],'改编'),
 'S3-I04':(['真题-2026-阅读1'],'改编'),
 'S3-II02':(['题集-02-选7'],'选用'),
 'S3-II03':(['真题-2026-填空9'],'选用'),
 'S3-II04':(['真题-2024-填空3'],'选用'),
 'S3-II05':(['真题-2024-填空6'],'选用'),
 'S3-II06':(['真题-2025-填空9'],'选用'),
 'S3-II09':(['题集-10-选30'],'选用'),
 'S4-I01':(['真题-2026-阅读4'],'改编'),
 'S4-I02':(['真题-2026-阅读3'],'改编'),
 'S4-I04':(['真题-2024-阅读5'],'选用'),
 'S4-II02':(['408-2016-2'],'选用'),
 'S4-II04':(['题集-04-选17'],'改编'),
 'S4-II05':(['真题-2025-填空7'],'改编'),
 'S4-II07':(['真题-2026-填空10'],'选用'),
 'S4-II08':(['408-2023-8'],'选用'),
 'S5-I02':(['题集-02-算12'],'改编'),
 'S5-I03':(['真题-2026-阅读2'],'选用'),
 'S5-I04':(['真题-2026-阅读5'],'改编'),
 'S5-II01':(['真题-2025-填空1'],'改编'),
 'S5-II02':(['真题-2024-填空2'],'选用'),
 'S5-II04':(['真题-2025-填空8'],'选用'),
 'S5-II05':(['真题-2026-填空8'],'改编'),
 'S6-I01':(['真题-2024-阅读1'],'选用'),
 'S6-I02':(['真题-2024-阅读3'],'改编'),
 'S6-I03':(['真题-2024-算法3'],'改编'),
 'S6-I04':(['真题-2024-阅读4'],'选用'),
 'S6-II01':(['真题-2024-填空1'],'选用'),
 'S6-II06':(['真题-2024-填空7'],'改编'),
 'S6-II08':(['题集-10-选30'],'选用'),
 'S6-II09':(['408-2022-10'],'改编'),
}
kept_fields=['title','chapter','tags','task','data','objective','evidence_required','task_family','novelty_type','minutes','level']
changes=[]
for row in old:
    q=student[row['id']]; m=meta.get(row['id'],{})
    row['design_version']='2026-10-22-r4'
    row['student_content_sha256']=hashlib.sha256(q['content'].encode('utf-8')).hexdigest()
    if row['section'] in ('I','II'):
        assert m.get('task'),row['id']
        old_sources=row['source_ids'][:]
        for k in kept_fields:
            if k in m: row[k]=m[k]
        row['chapter']={'栈和队列':'栈队列'}.get(row['chapter'],row['chapter'])
        row['task_family']={'状态计算':'过程追踪'}.get(row['task_family'],row['task_family'])
        if row['section']=='I' and row['number']>1:
            row['task_family']='代码补全'
            if row['novelty_type']=='错解诊断': row['novelty_type']='条件辨析'
        proposed=m.get('source_ids_recommendation',m.get('suggested_source_ids',m.get('proposed_source_ids',[])))
        history=m.get('history_ids_recommendation',m.get('history_ids',m.get('proposed_history_ids',row['history_ids'])))
        row['source_ids'],row['mode']=direct.get(row['id'],(proposed,'改编' if proposed else '原创'))
        row['history_ids']=list(dict.fromkeys(history+row['source_ids']))
        if row['mode']=='选用': row['novelty_type']='平行练习'
        guide=m.get('source_guidance',m.get('source_policy',m.get('source_review','')))
        row['source_review_note']='根代理对照原题题干复核：'+('保留直接来源；仅改题型、数字或补约定不计原创。' if row['source_ids'] else '原直接来源未支撑此具体任务，仅保留对应历史方法线索。')
        row['revision_note']='2026-10-22按用户确认重写为'+('程序阅读（复杂度分析/代码补全）' if row['section']=='I' else '填空题')+'。'+m.get('revision_note','')+' '+row['source_review_note']
        row['change']='作答方式改为'+('代码阅读及关键步骤补全' if row['section']=='I' else '直接填写结果')+'；现任务：'+row['task']+'。'
        row['answer_blueprint']='本题题型已重写，旧答案骨架停用；待用户审定学生题面后制作对应答案、等价解和评分细则。'
        row['misconception']='本题重点核对：'+row['objective']+'；不能套用旧题的答案字母或旧程序步骤。'
        row['transfer']='按真题作答形式练习'+row['title']+'；仅题型转换、换数据或补定义不计实质创新。'
        row['time_reason']=f'预计{row["minutes"]}分钟，完成题面所列代码空/结果空及必要分析；尚未经限时试做。'
        row['rubric']=[]
        for i,match in enumerate(re.finditer(r'[（(](\d+)分[）)]',q['content']),1):
            prefix=q['content'][:match.start()].split('\n')[-1]
            label=re.split(r'；|，|、|[（(]\d+分[）)]',prefix)[-1].strip().strip('`')
            label=f'得分项{i}：'+label[-52:]
            row['rubric'].append([label,int(match.group(1))])
        assert sum(x[1] for x in row['rubric'])==row['points'],row['id']
        row['exposure']['response']='课件引用仅作为旧方法线索，未证明本轮新题面已向学生发放；须按实际录制、课件和作业记录核实。'
    elif row['section']=='IV':
        row['revision_note']='2026-10-22补明C语言实现与题面所需结构/接口；数学任务、输入数据、分值不变。'+m.get('revision_note','')
    if q['content']!=before[row['id']]['content']:
        changes.append({'id':row['id'],'section':row['section'],'student_sha256':row['student_content_sha256'],'change':row['revision_note']})
write(PLAN/'六套逐题蓝图.json',old)
write(OUT/'题型修订核对.json',{'version':'2026-10-22-student-v2','source':'真题资料/真题24-25.pdf','authority':'用户确认题数分值；样本校准题型','changed_count':len(changes),'changes':changes,'answers_produced':False})
print('Metadata synchronized:',len(old),'questions,',len(changes),'changed student texts')
