from pathlib import Path
import hashlib, json, zipfile
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'资料整理/六套模拟卷成稿'
PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

papers=[read(OUT/f'试题源稿/第{p}套.json') for p in range(1,7)]
questions={q['id']:q for p in papers for q in p['questions']}
rows=read(PLAN/'六套逐题蓝图.json')
for r in rows:
    assert r['student_content_sha256']==hashlib.sha256(questions[r['id']]['content'].encode('utf8')).hexdigest(),r['id']
audit=read(OUT/'题型修订核对.json')
for r in audit['changes']:
    assert r['student_sha256']==hashlib.sha256(questions[r['id']]['content'].encode('utf8')).hexdigest(),r['id']
assert len(questions)==144 and len(audit['changes'])==102

spec=read(OUT/'题型规范.json')
assert sha(ROOT/spec['reference'])==spec['reference_sha256']
structure=read(OUT/'成卷结构核对.json')
texts=[]
files=[]
for p,summary in zip(papers,structure['papers']):
    n=p['paper']
    assert summary['source_sha256']==sha(OUT/f'试题源稿/第{n}套.json')
    pdf=OUT/f'学生卷PDF/重邮802模拟试卷第{n}套.pdf'
    md=OUT/f'可编辑试题/第{n}套试卷.md'
    pages=PdfReader(pdf).pages
    assert len(pages)==summary['pages']
    texts.extend(page.extract_text() for page in pages)
    assert all(t.strip() for t in texts)
    files.extend([pdf,md])
combined=OUT/'六套模拟试卷合订本.pdf'
reader=PdfReader(combined)
assert [page.extract_text() for page in reader.pages]==texts
assert len(reader.outline)==6
assert len(texts)==45

readme='''2027重邮802六套模拟试卷｜学生卷第2版
版本：2026-10-22

本包包含六份独立PDF、六份可编辑Markdown及本说明，共13个文件。
每套24题、150分、180分钟：
一、程序阅读题4道，每道5分，共20分；以代码补全为主。
二、填空题10道，每道3分，共30分；无选择项。
三、综合应用题7道，每道10分，共70分。
四、算法设计与分析题3道，依次8、10、12分，共30分。

各大题内从1开始编号；答题时写明大题、小题和空号。
程序空__1__等按编号作答；等价的正确表达式或语句可以作答。
试卷不另设答题区，请另备答题纸。保持整题同页，因此部分页面留白。
六份PDF分别8、7、8、9、6、7页。Markdown与PDF使用同一学生题面源。
PDF为打印使用，可编辑版本用于审核和修改。

题型参照《真题24-25.pdf》，题数和分值以用户确认的固定安排为准。
内容以常考主干巩固和练习为目标，目标难度中等偏上，实际用时与难度待试做。
本包仅供题面审查，不含标准答案或教师参考代码；题面审定后再制作对应答案。
'''
archive=OUT/'六套学生卷_无答案.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for f in files: z.write(f,f.relative_to(OUT).as_posix())
    z.writestr('使用说明.txt',readme.encode('utf8'))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==13
    for f in files: assert z.read(f.relative_to(OUT).as_posix())==f.read_bytes()

dbhash=sha(ROOT/'题库数据库/tiku.db')
assert dbhash.upper()=='3F050FEA3CF82D0753DD24C8E518C0B1C49ED70C740B703D572A0B37E7B4D718'
manifest={
    'date':'2026-10-22','version':'2026-10-22-student-v2',
    'format_version':spec['version'],'student_questions':144,'total_points':900,
    'pdf_pages':len(texts),'answers_produced':False,
    'files':[{'file':f.relative_to(OUT).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size} for f in [combined,archive]+files],
    'source_checks':structure['papers'],
    'reference':spec['reference'],'reference_sha256':spec['reference_sha256'],
    'student_content_hashes_checked':144,'changed_student_texts':102,
    'rewritten_reading_questions':24,'rewritten_fill_in_questions':60,
    'scope_policy':'常考主干巩固练习；考纲内低频不为覆盖率纳入',
    'content_review':'三组修改与交叉内容复查、主代理通读修订；旧答案骨架不作为新题答案。',
    'visual_review':'六套45页逐页检查；第3套p1/p7、第4套p4、第5套p3末次修改后定点复核。无漏题、裁切或分值断行；整题同页，部分页面留白。',
    'combined_pdf_check':'45页逐页抽取文字与六份独立PDF按序拼接相同；6个分卷书签。',
    'archive_check':'13项；CRC通过；12份PDF/Markdown逐项字节相同。',
    'seed_verification':'21项检查覆盖16个综合/算法题位，签名未变；不代表全部144题自动核答。',
    'database_sha256':dbhash.upper(),'git_base':'4c819505ff381100aa8097a6bb4f3e7b56170d18'
}
write(OUT/'交付核对.json',manifest)
print('PASS delivery: 144 source hashes, 102 change hashes, 45 merged pages, 6 bookmarks, 13 ZIP entries, unchanged 966-question database.')
