from pathlib import Path
import json, hashlib

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'资料整理/六套模拟卷成稿'
PLAN = ROOT/'资料整理/六套模拟卷规划'

def read(p): return json.loads(p.read_text(encoding='utf-8'))
def write(p, v): p.write_text(json.dumps(v, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')

papers = [read(OUT/f'试题源稿/第{p}套.json') for p in range(1,7)]
qs = {q['id']:q for p in papers for q in p['questions']}
q = qs['S3-I01']
old = '''unsigned long long count = 0;
for (long long i = 1; i <= n; i *= 2) {
    for (int j = n; j >= 1; --j) {
        ++count;
    }
}'''
new = '''unsigned long long countOps(int n) {
    unsigned long long count = 0;
    for (long long i = 1; i <= n; i *= 2) {
        for (int j = n; j >= 1; --j) {
            ++count;
        }
    }
    return count;
}'''
assert old in q['content']
q['content'] = q['content'].replace(old,new)
qs['S3-IV02']['content'] = qs['S3-IV02']['content'].replace('选按“先左子树、后右子树”DFS 最先遇到的一条','选按先左后右的顺序进行 DFS 时最先遇到的一条')
qs['S4-II04']['content'] = '长度 n 的文本与长度 m 的模式串做一次 KMP 匹配，`1≤m≤n`。在最坏情况下，`next` 表已给定时，匹配阶段的紧渐近时间阶为 ______（2分）；用标准 KMP 递推单独计算模式串 `next` 表的紧渐近时间阶为 ______（1分）。答案分别用 n、m 表示。'
assert 'P=ababaca' in qs['S3-II04']['content']
assert 'P=abacaba' in qs['S5-II04']['content']
for p in papers: write(OUT/f'试题源稿/第{p["paper"]}套.json',p)

rows = read(PLAN/'六套逐题蓝图.json')
by_id = {r['id']:r for r in rows}
r=by_id['S4-II10']
r['mode']='原创'
r['source_ids']=[]
r['source_review_note']='2024填空5与2026综合18考查AVL插入，未直接支持本题的最少结点递推；保留为AVL历史考点线索。'
r['revision_note'] += ' 最终溯源复核：'+r['source_review_note']
r=by_id['S4-II04']
r['task']='分别填写KMP匹配阶段与next预处理的最坏紧渐近时间阶'
r['objective']='区分匹配阶段和模式预处理阶段的工作量'
r['evidence_required']='两个分别用n和m表示的紧渐近阶'
r['rubric']=[['匹配阶段紧渐近阶',2],['next预处理紧渐近阶',1]]
r['revision_note'] += ' 最终复核：将总复杂度改为单独预处理复杂度，避免m≤n时两空等价。'
for qid in ['S3-I01','S3-IV02']:
    by_id[qid]['revision_note'] += ' 最终复核：补完整函数作用域或澄清DFS访问顺序，数学任务不变。'
for r in rows:
    r['student_content_sha256']=hashlib.sha256(qs[r['id']]['content'].encode('utf8')).hexdigest()
write(PLAN/'六套逐题蓝图.json', rows)
audit=read(OUT/'题型修订核对.json')
for entry in audit['changes']:
    r=by_id[entry['id']]
    entry['student_sha256']=r['student_content_sha256']
    entry['change']=r['revision_note']
write(OUT/'题型修订核对.json',audit)

# Verify existing seed signatures before updating their version label.
b=read(PLAN/'核验输入绑定.json')
for qid, expected in b['design_hashes'].items():
    payload={k:by_id[qid].get(k,'') for k in ('task','data','answer_blueprint')}
    actual=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True).encode('utf8')).hexdigest()
    assert actual==expected, qid
b['version']='2026-10-22-r4'
b['本轮题型修订说明']='本轮重写I/II；本文件绑定的16个III/IV题位数学任务、数据与答案骨架签名均保持不变。IV仅明确C语言接口或操作开销。此记录不验证前两部分新题。'
write(PLAN/'核验输入绑定.json',b)
print('Final source edits and 144 content hashes synchronized; 16 seed bindings unchanged.')
