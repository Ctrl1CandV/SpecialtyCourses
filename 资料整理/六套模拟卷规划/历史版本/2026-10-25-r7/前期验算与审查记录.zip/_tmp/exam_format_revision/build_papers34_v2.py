"""Temporary authoring helper for student papers 3/4 after format alignment."""

import json
import re
import zipfile
from pathlib import Path
from textwrap import dedent

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "资料整理/六套模拟卷成稿/试题源稿"
BLUEPRINT = ROOT / "资料整理/六套模拟卷规划/六套逐题蓝图.json"
META_OUT = ROOT / "_tmp/exam_format_revision/papers34_revision.json"
BACKUP = ROOT / "资料整理/六套模拟卷规划/历史版本/2026-10-21-r3/题型修正前快照.zip"

CONTENT = {}


def add(qid, body):
    CONTENT[qid] = dedent(body).strip()


# 第3套：程序阅读。首题保留完整程序；其余题在正确算法中留关键代码空。
add("S3-I01", r"""
设 `n` 是 `int` 范围内的正整数。阅读下面的 C 代码，`count` 记录内层循环体的执行次数。

```c
unsigned long long count = 0;
for (long long i = 1; i <= n; i *= 2) {
    for (int j = n; j >= 1; --j) {
        ++count;
    }
}
```

当 `n=8` 时，外层 `i` 依次为 ______（1分），`count=______`（1分）。若 `n=2^k`（k≥0），外层执行 ______ 次（1分）；以 n 为自变量，程序时间复杂度为 ______（2分）。
""")

add("S3-I02", r"""
带头结点的单链表每个数据结点含 `key`、`tag`、`next`；`tag` 区分同键记录，比较时只看 `key`。现对记录 `(4,a),(2,-),(4,b),(1,-)` 按 `key` 升序做简单选择排序。每轮选最小值时，若关键字相等则保留先遇到的记录作为 `best`。下面交换的是整个记录的 `key` 与 `tag`，不交换结点指针。补全代码。

```c
#include <stddef.h>
typedef struct Node {
    int key;
    char tag;
    struct Node *next;
} Node;

void selectionSort(Node *head) {
    for (Node *p = __1__; p != NULL; p = p->next) {
        Node *best = p;
        for (Node *q = __2__; q != NULL; q = q->next)
            if (__3__) best = q;
        if (best != p) {
            int key = p->key; char tag = p->tag;
            p->key = best->key; p->tag = best->tag;
            best->key = key; best->tag = tag;
        }
    }
}
```

填代码空 `__1__`（1分）、`__2__`（1分）、`__3__`（1分）；写出给定链表排序后的含 `tag` 记录序列 ______（1分），以及 n 个数据结点时的最坏时间复杂度 ______（1分）。
""")

add("S3-I03", r"""
`Token` 的 `isNumber` 为真时 `value` 是整数，否则 `op` 为 `+`、`-`、`*`、`/` 之一。输入保证是合法后缀表达式、除数非零、运算不溢出；`stack` 容量至少为 token 数，整数除法向零截断。补全按 token 顺序求值的代码。

```c
typedef struct { int isNumber, value; char op; } Token;
int eval(const Token tokens[], int n) {
    int stack[100], top = -1;  /* 本题 n <= 100 */
    for (int i = 0; i < n; ++i) {
        if (tokens[i].isNumber) {
            stack[++top] = tokens[i].value;
        } else {
            int right = stack[top--];
            int left = __1__;
            int v;
            switch (tokens[i].op) {
                case '+': v = left + right; break;
                case '-': v = __2__; break;
                case '*': v = left * right; break;
                default:  v = __3__; break;  /* 除法 */
            }
            stack[++top] = v;
        }
    }
    return stack[top];
}
```

填代码空 `__1__`（1分）、`__2__`（1分）、`__3__`（1分）。后缀式 `9 3 / 2 -` 的结果为 ______（1分）；n 个 token 的时间复杂度为 ______（1分）。
""")

add("S3-I04", r"""
无向图以 4×4 邻接矩阵表示，边集为 `{0,1}`、`{0,2}`、`{1,2}`，顶点 3 孤立。外层按顶点编号递增启动 DFS，邻点也按编号递增检查。补全下面只输出 DFS 树边并统计连通分量的 C 代码。

```c
#include <stdio.h>
int g[4][4] = {
    {0,1,1,0}, {1,0,1,0},
    {1,1,0,0}, {0,0,0,0}
};
int seen[4] = {0}, components = 0;
void dfs(int u) {
    seen[u] = 1;
    for (int v = 0; v < 4; ++v) {
        if (__1__) {
            printf("%d->%d ", u, v);
            __2__;
        }
    }
}
int main(void) {
    for (int u = 0; u < 4; ++u)
        if (__3__) { ++components; dfs(u); }
    return 0;
}
```

填代码空 `__1__`（1分）、`__2__`（1分）、`__3__`（1分）。推广到 V 个顶点、仍用邻接矩阵并遍历全部顶点时，时间复杂度为 ______（2分）。
""")


# 第3套：填空。每空都有单独的得分标记，答案是有限值或式子。
add("S3-II01", r"""设 n=2^k（k≥0），T(1)=1，T(n)=T(n/2)+n。T(n) 的紧渐近阶为 ______（3分）。""")
add("S3-II02", r"""长度为 n 的顺序表采用从 1 开始的逻辑位序。删除第 i 个元素（1≤i≤n），保持余下元素的相对次序，须前移 ______ 个元素（3分）。""")
add("S3-II03", r"""互异元素 1、2、3、4、5 依次入同一个空栈，允许入栈与出栈交替。若第一个出栈元素是 5，则唯一可能的完整出栈序列为 ______（3分）。""")
add("S3-II04", r"""模式串 `P=ababaca` 从 1 编号。采用下列 KMP 约定：`next[1]=0`；对 j>1，`next[j]` 等于 P 的前 j−1 个字符中“最长真前缀且同时为后缀”的长度加 1；无非空匹配时该长度为 0。写出 `next[1..7]=______`（3分）。""")
add("S3-II05", r"""二维整型数组 `A[5][7]` 按行主序存放，下标从 0 起，`A[0][0]` 的首地址为 400，每个元素占 4 字节。`A[3][2]` 相对首元素的元素偏移量为 ______（1分），其首地址为 ______（2分）。""")
add("S3-II06", r"""一棵非空树有 4 个度为 3 的结点、3 个度为 2 的结点、2 个度为 1 的结点，没有度超过 3 的结点。度为 0 的结点有 ______ 个（3分）。""")
add("S3-II07", r"""AOE 网中事件 u、v 的最早与最迟发生时间分别为 `ve(u)=vl(u)=2`、`ve(v)=vl(v)=7`。活动 u→v 持续 3。它的最早开始时间 `e=______`（1分），最迟开始时间 `l=______`（1分），总时差 `l−e=______`（1分）。""")
add("S3-II08", r"""长为 11 的散列表使用线性探测；只有地址 1、2、3 被占用，其他地址均为空。失败查找遇首个空槽才停止。若待查键的初始散列地址为 1，探测次数为 ______（1分）。若失败查询的初始地址在 0～6 中等可能，失败平均查找长度为 ______（2分）。""")
add("S3-II09", r"""小根堆用从 1 起编号的数组存为 `(1,4,2,9,7,6)`。插入键 0 并逐层上滤后，数组内容为 ______（3分）。""")
add("S3-II10", r"""互异键 BST 用 `X(左孩子,右孩子)` 表示，`∅` 为空。原树为 `40(20(10,30),60(50(∅,55),70))`。删除根 40 时采用“复制右子树最小键到根，再删除该原结点”的方法。新根键为 ______（1分），原键 50 的结点位置由键 ______ 的结点接替（1分），删除后的中序序列为 ______（1分）。""")


# 第4套：程序阅读。用短的、能独立运行的核心程序考查边界和状态维护。
add("S4-I01", r"""
阅读下面的 C 代码。输入 `n≥1`，数组有效下标为 `0..n−1`；函数返回前 n 个元素中的最小值。

```c
int minPrefix(const int a[], int n) {
    if (n == 1) return a[0];
    int t = minPrefix(a, n - 1);
    return t < a[n - 1] ? t : a[n - 1];
}
```

对 `a=(23,33,16,79,34,29)`、`n=6`，返回值为 ______（1分），三目表达式中的比较共执行 ______ 次（1分），最大同时存在的函数调用层数为 ______（1分）。以 n 为自变量，时间复杂度为 ______（1分），递归栈空间复杂度为 ______（1分）。
""")

add("S4-I02", r"""
两个带头结点的升序单链表 A、B 中，**各自键互异**。函数将 A 改造成两表的交集：保留 A 中相同键的原结点，释放 A 中不在 B 的结点；B 不变。头结点由调用者管理，输入链不共享数据结点。补全代码。

```c
#include <stdlib.h>
typedef struct Node { int key; struct Node *next; } Node;
void intersect(Node *A, const Node *B) {
    Node *pa = A->next, *tail = A;
    const Node *pb = B->next;
    A->next = NULL;
    while (pa != NULL && pb != NULL) {
        if (pa->key == pb->key) {
            Node *next = pa->next;
            tail->next = pa;
            tail = __1__;
            pa = next; pb = pb->next;
        } else if (pa->key < pb->key) {
            Node *next = pa->next;
            __2__;
            pa = next;
        } else {
            __3__;
        }
    }
    while (pa != NULL) {
        Node *next = pa->next;
        free(pa); pa = next;
    }
    tail->next = NULL;
}
```

填代码空 `__1__`（1分）、`__2__`（1分）、`__3__`（1分）；设两表原长分别为 m、n，时间复杂度为 ______（2分）。
""")

add("S4-I03", r"""
容量为 4 的顺序循环队列用 `count` 区分队空和队满；`front` 指向队首元素，`rear` 指向下一次入队位置。传入的 `q`、`out` 均为有效指针，且队列初始状态合法（`0≤count≤4`，两个下标都在 0～3）。入队满时返回 0，出队空时返回 0；其余返回 1。补全代码。

```c
typedef struct {
    int a[4];
    int front, rear, count;
} Queue;
int enq(Queue *q, int x) {
    if (__1__) return 0;
    q->a[q->rear] = x;
    q->rear = __2__;
    ++q->count;
    return 1;
}
int deq(Queue *q, int *out) {
    if (q->count == 0) return 0;
    *out = q->a[q->front];
    q->front = (q->front + 1) % 4;
    __3__;
    return 1;
}
```

填代码空 `__1__`（1分）、`__2__`（1分）、`__3__`（1分）；单次入队或出队的最坏时间复杂度为 ______（2分）。
""")

add("S4-I04", r"""
下列函数返回二叉树的叶结点数。空树返回 0，只有根结点的树返回 1。补全递归代码。

```c
#include <stddef.h>
typedef struct Node {
    int key;
    struct Node *left, *right;
} Node;
int leafCount(const Node *t) {
    if (__1__) return 0;
    if (__2__) return 1;
    return __3__;
}
```

填代码空 `__1__`（1分）、`__2__`（1分）、`__3__`（1分）；若树有 n 个结点，时间复杂度为 ______（2分）。
""")


# 第4套：填空。每题给可确定的数值、序列或表达式，不设置选项。
add("S4-II01", r"""设 n=2^k（k≥0），递归式 `T(1)=Θ(1)`、`T(n)=2T(n/2)+Θ(1)`，对应函数除递归调用外只做常数次操作。时间复杂度为 ______（2分），最大递归栈深度的渐近阶为 ______（1分）。""")
add("S4-II02", r"""带头结点的双向循环链表删除一个已定位数据结点 `p`。在执行 `free(p)` 前，应赋值 `p->prior->next=______`（1分）以及 `p->next->prior=______`（2分）。该写法也适用于只有一个数据结点的链表。""")
add("S4-II03", r"""互异元素 1、2、3、4、5 依次压入初始为空的栈。若出栈序列为 `3,2,4,1,5`，第一次出栈前已经压入 ______ 个元素（1分），整个过程中栈所需的最小容量为 ______（2分）。""")
add("S4-II04", r"""长度 n 的文本与长度 m 的模式串做一次 KMP 匹配，`1≤m≤n`。在最坏情况下，`next` 表已给定时匹配阶段的紧渐近时间阶为 ______（2分）；若还要计算模式串的 `next`，包含预处理的总时间紧渐近阶为 ______（1分）。答案用 n、m 表示。""")
add("S4-II05", r"""广义表 `L=((a,b),(c,d))`，`Head` 取表的首元素，`Tail` 取除首元素以外的表。`Head(Head(Tail(L)))=______`（2分），这个结果是原子还是表：______（1分）。""")
add("S4-II06", r"""一棵二叉树的先序序列为 `A,B`，后序序列为 `B,A`，结点互异。这棵树的根结点为 ______（1分），满足这两个序列的不同二叉树形态共有 ______ 种（2分）。""")
add("S4-II07", r"""有 n≥2 个顶点的简单有向图若强连通，其最少弧数为 ______（2分）；可达到该下界的一种连边结构是 ______（1分）。后一空写出结构名称或弧的规则。""")
add("S4-II08", r"""对 600 个互异键构成的升序顺序表做折半查找，每轮与一个中间元素比较。成功查找时最坏比较次数为 ______（3分）。""")
add("S4-II09", r"""稳定地归并两个按键非递减排列的序列，原记录次序为左段接右段。左段为 `(1,a),(3,a)`，右段为 `(1,b),(2,-),(3,b)`；元组第二项仅用于辨认同键记录。相等键时保持原记录的先后顺序，输出的完整记录序列为 ______（3分）。""")
add("S4-II10", r"""规定 AVL 树高度按层数计，空树高度为 0，单结点树高度为 1。高度 h 的 AVL 树的最少结点数记为 `N(h)`，已知 `N(0)=0`、`N(1)=1`。对 h≥2，递推式 `N(h)=______`（1分），`N(5)=______`（2分）。""")


IV_REPLACEMENTS = {
    "S3-IV01": [
        ("0 基顺序表由", "从下标 0 开始编号的顺序表由"),
        ("只使用给定 `reverse` 接口，写出正确的调用次序", "只使用给定 `reverse` 接口，写出 C 语言调用语句及其正确次序"),
    ],
    "S3-IV02": [
        ("```c\ntypedef struct Node {", "```c\n#include <stdbool.h>\n#include <stddef.h>\ntypedef struct Node {"),
        ("接口可写为 `bool longestMarkedPath(Node *root, /* 输出根到叶的结点序列 */)`。", "实现接口 `bool longestMarkedPath(Node *root, Node *out[], int *len)`；调用者提供容量至少为树高的 `out` 数组，成功时从 `out[0]` 起输出路径中的结点指针并通过 `*len` 返回长度，失败时令 `*len=0`。可自定义辅助函数。"),
        ("写关键伪码：求出", "写 C 语言关键代码：求出"),
    ],
    "S3-IV03": [
        ("```c\ntypedef struct Node {", "```c\n#include <stdbool.h>\n#include <stddef.h>\ntypedef struct Node {"),
        ("Node *mergeK(Node *L[], int k);", "Node *mergeK(Node *L[], int k);\nvoid push(Item x);\nItem pop(void);\n/* empty() 在堆空时返回 true；调用前堆已初始化为空。 */\nbool empty(void);"),
        ("写 `mergeK` 的关键伪码", "写 `mergeK` 的 C 语言代码"),
    ],
    "S4-IV01": [
        ("```c\ntypedef struct Node {", "```c\n#include <stdlib.h>\ntypedef struct Node {"),
        ("设计 C 风格算法 `int josephus(Node **tailRef, Node *cur, Node *pre, int n, int m)`，返回幸存编号，并通过 `*tailRef` 返回删除后的尾指针。可写完整伪码，但指针更新与释放次序必须明确。", "用 C 语言实现 `int josephus(Node **tailRef, Node *cur, Node *pre, int n, int m)`，返回幸存编号，并通过 `*tailRef` 返回删除后的尾指针；指针更新与释放次序必须明确。"),
        ("完整循环伪码", "完整循环代码"),
    ],
    "S4-IV02": [
        ("```c\ntypedef struct Node {", "```c\n#include <stdbool.h>\n#include <stddef.h>\ntypedef struct Node {"),
        ("设计判定算法，不得修改树。可用伪码表示可选的上下界及其是否包含端点，不得以 `INT_MIN`、`INT_MAX` 充当树外哨兵。", "用 C 语言实现判定算法，不得修改树。可为递归边界定义包含‘是否存在、端点值、是否包含端点’的结构；不得以 `INT_MIN`、`INT_MAX` 充当树外哨兵，也不得用键值加减 1 来代替严格不等号。"),
        ("关键伪码", "关键代码"),
    ],
    "S4-IV03": [
        ("给定无向无权简单图 `G` 的邻接表、顶点数 `V`、起点 `s` 和终点 `t`（可相同），返回三种状态之一：", "给定无向无权简单图 `G` 的邻接表、顶点数 `V≥1`、合法起点 `s` 和终点 `t`（可相同），返回三种状态之一："),
        ("不能枚举全部路径；可使用队列和长度 V 的 `dist`、`ways`、`pred` 数组，其中 `ways` 只保存 0、1、2，2 表示“至少 2 条”。", "不能枚举全部路径；可使用队列和长度 V 的 `dist`、`ways`、`pred` 数组，其中 `ways` 只保存 0、1、2，2 表示“至少 2 条”。请基于以下 C 结构与接口实现；无向边在两个顶点的邻接链中各存一条弧。调用者提供容量至少为 V 的 `path`，仅当返回 `UNIQUE` 时填写路径及 `*pathLen`，其他状态令 `*pathLen=0`。\n\n```c\n#include <stddef.h>\ntypedef struct Arc { int to; struct Arc *next; } Arc;\ntypedef struct { int V; Arc **head; } Graph;\ntypedef enum { UNREACHABLE, UNIQUE, MULTIPLE } Status;\nStatus classifyShortest(const Graph *g, int s, int t,\n                        int path[], int *pathLen);\n```"),
        ("入队的关键伪码", "入队的 C 语言关键代码"),
        ("时的更新规则", "时的 C 语言更新代码"),
    ],
}


META = {}


def meta(qid, title, tags, task, data, objective, evidence, family,
         novelty, minutes, level, policy="原来源支持考点或题型，题面为重新编写"):
    META[qid] = dict(title=title, tags=tags.split("、"), task=task, data=data,
                     objective=objective, evidence_required=evidence,
                     task_family=family, novelty_type=novelty, minutes=minutes,
                     level=level, source_policy=policy)


meta("S3-I01", "倍增外循环的频度与复杂度", "时间复杂度、循环频度", "读完整两层循环，求给定输入的频度与一般复杂度", "n=8；另令n=2^k", "把循环轮数和总执行次数联系起来", "i序列、count、轮数、Θ阶", "复杂度分析", "基础锚点", 5, "中", "无直接source_ids；2024/25阅读复杂度题仅作题型历史锚点")
meta("S3-I02", "链表选择排序关键代码补全", "单链表、选择排序、稳定性、记录身份", "补全选择排序三处遍历/比较代码，追踪带身份记录并算最坏复杂度", "(4,a),(2,-),(4,b),(1,-)", "理解选择排序的比较与整记录交换，以及相等键身份变化", "三处C表达式、完整输出、Θ阶", "代码补全", "表示转换", 6, "中")
meta("S3-I03", "后缀表达式求值代码补全", "后缀求值、栈", "补全操作数出栈及非交换运算表达式，求一次运算值与复杂度", "Token数组；9 3 / 2 -", "保持左右操作数次序并线性求值", "三处C表达式、求值结果、Θ阶", "代码补全", "基础锚点", 5, "基", "无直接source_ids；原历史填空题只支持后缀求值考点")
meta("S3-I04", "DFS森林树边代码补全", "DFS、DFS生成森林、图存储", "补全邻接矩阵DFS的递归条件、调用和外层起点判断，求复杂度", "四顶点无向图，顶点3孤立", "区分树边和非树边并覆盖所有连通分量", "三处C语句/条件、矩阵遍历Θ阶", "代码补全", "目标变化", 6, "中")
meta("S3-II01", "分治递归工作量填空", "递归复杂度", "求T(n)=T(n/2)+n的紧渐近阶", "n=2^k", "按递归层的工作量求总量", "一个Θ表达式", "复杂度分析", "基础锚点", 2, "中", "无直接source_ids；阅读题只作递归复杂度题型锚点")
meta("S3-II02", "顺序表删除移动次数填空", "顺序表、基本操作", "给定n与位序i求删除后移动次数", "从1编号，1≤i≤n", "对应删除区间i+1至n", "一个代数式", "状态计算", "基础锚点", 2, "基")
meta("S3-II03", "首出5的栈序列填空", "栈序列", "由入栈顺序及首出约束确定唯一完整出栈序列", "1..5顺次入栈，首出5", "追踪首出时栈内剩余顺序", "完整出栈序列", "逆向推断", "基础锚点", 2, "基")
meta("S3-II04", "KMP next数组计算", "KMP、next数组、前后缀", "按明确1基next定义写出模式串各位置的next值", "P=ababaca；next[1]=0", "由每个位置之前的最长真前后缀计算next", "next[1..7]整张小表", "过程追踪", "平行练习", 3, "中")
meta("S3-II05", "行主序二维数组地址计算", "数组地址、行主序", "求指定元素偏移量与字节地址", "A[5][7]；基址400；元素4字节；A[3][2]", "将二维下标映射为线性偏移", "元素偏移与地址两个数值", "表示转换", "基础锚点", 2, "基", "原408-2023-3是稀疏矩阵题，不能直接支持新题；建议清空source_ids，仅保留历史库存记录")
meta("S3-II06", "树的度数与叶子数", "树的度数、树的性质", "由各度结点数计算叶结点数", "度3有4、度2有3、度1有2", "用边数等于结点数减1求叶数", "一个整数", "状态计算", "基础锚点", 2, "中")
meta("S3-II07", "AOE活动时差计算", "AOE、时差", "由端点事件时间和持续时长求e、l及总时差", "ve(u)=vl(u)=2，ve(v)=vl(v)=7，持续3", "区分事件关键性与活动时差", "三个数值", "状态计算", "条件辨析", 2, "中", "无直接source_ids；2025综合AOE仅作知识历史锚点")
meta("S3-II08", "失败探测次数与ASL", "线性探测、失败ASL、散列地址分布", "求给定起点探测次数与等可能起点的失败ASL", "表长11，占1/2/3；初始地址0..6", "逐起点按首空槽停止统计", "一次探测次数与分数形式ASL", "过程追踪", "约束变化", 3, "中", "无直接source_ids；2026综合散列题仅作知识历史锚点")
meta("S3-II09", "小根堆插入后的数组", "小根堆、堆插入", "将键0插入并上滤，写最终数组", "初始堆(1,4,2,9,7,6)", "准确追踪堆插入交换路径", "最终完整数组", "过程追踪", "平行练习", 3, "中")
meta("S3-II10", "BST中序后继替代删除", "BST、双孩子删除、中序后继、孩子重连", "按后继键复制法删除根，求替代与最终中序", "40(20(10,30),60(50(∅,55),70))", "辨认后继原位置及唯一孩子接链", "新根、接替键、中序序列", "过程追踪", "条件辨析", 3, "中", "无直接source_ids；旧408材料仅为BST删除知识锚点")

meta("S4-I01", "递归前缀最小值程序阅读", "递归、数组边界、程序阅读", "阅读正确递归求最小值程序，求结果、比较次数、栈深与复杂度", "a=(23,33,16,79,34,29)", "分清返回值、每层比较和递归空间", "三个数值和两个Θ阶", "过程追踪", "基础锚点", 5, "中")
meta("S4-I02", "有序链表交集代码补全", "有序链表交集、内存所有权、指针重连", "补全交集保留A结点的指针与释放语句，并求复杂度", "A/B带头结点、各自键互异且不共享数据结点", "维护结果尾指针并保持B不变", "三处C语句/表达式、O(m+n)", "代码补全", "约束变化", 6, "中")
meta("S4-I03", "计数型循环队列代码补全", "循环队列、队满判定、取模", "补全队满条件、尾指针更新及计数更新并求单次复杂度", "容量4；front/rear/count合法；q/out有效", "区分物理下标环绕与队列逻辑长度", "三处C表达式、单次Θ阶", "代码补全", "基础锚点", 5, "基", "无直接source_ids；原2024/26填空只作队列知识锚点")
meta("S4-I04", "叶结点计数代码补全", "叶结点、递归、布尔条件", "补全空树、叶判定及左右递归求和，并求复杂度", "二叉链式Node，空树返回0", "正确处理单孩子结点不是叶", "三处C表达式、Θ阶", "代码补全", "表示转换", 5, "中")
meta("S4-II01", "双分支递归复杂度填空", "递归复杂度、调用栈", "求T(n)=2T(n/2)+Θ(1)的时间与栈深", "n=2^k", "区别调用树总工作与单支栈深", "两个Θ表达式", "复杂度分析", "基础锚点", 2, "中", "无直接source_ids；阅读复杂度材料仅作历史锚点")
meta("S4-II02", "双向循环链表摘链代码填空", "双链表、指针重连", "填写释放结点前的两个邻接指针赋值", "带头结点双向循环链表；已定位p", "同时维护前后向链", "两个C表达式", "代码补全", "基础锚点", 2, "基")
meta("S4-II03", "出栈序列的最小容量填空", "栈序列、栈容量", "由出栈序列求首次出栈前入栈数与最小容量", "压入1..5；弹出3,2,4,1,5", "模拟合法入出栈过程的最大深度", "两个整数", "过程追踪", "目标变化", 3, "中", "无直接source_ids；原真题仅作栈序列知识锚点")
meta("S4-II04", "KMP匹配与预处理复杂度", "KMP、时间复杂度", "分别填写已知next时匹配和含预处理的最坏紧渐近时间阶", "文本长n；模式长m；1≤m≤n", "区分匹配扫描和next构造", "两个渐近表达式", "复杂度分析", "条件辨析", 2, "基")
meta("S4-II05", "嵌套Head/Tail值与类型", "广义表、Head、Tail", "求嵌套操作结果并判断类型", "L=((a,b),(c,d))", "遵循Head返回元素、Tail返回表", "结果符号和类型", "过程追踪", "基础锚点", 2, "中")
meta("S4-II06", "先序后序可对应的树形数", "遍历重建、唯一性", "给定二结点先后序，求根与可能树形数量", "先序AB、后序BA", "识别单孩子左/右无法区分", "根符号与整数数量", "逆向推断", "逆向推断", 2, "中", "无直接source_ids；旧综合/算法仅作遍历知识锚点")
meta("S4-II07", "强连通最少弧数及构造", "强连通、有向图基本性质", "求最少弧数并给达到下界的结构", "n≥2的简单有向图", "以每点出度至少1和有向环构造对应", "最少弧数和构造名称/规则", "逆向推断", "基础锚点", 2, "基")
meta("S4-II08", "600元素折半查找上界", "折半查找、最坏比较次数", "求600元素成功查找的最坏比较次数", "升序600互异键", "由层数或比较上界推得精确整数", "一个整数", "状态计算", "平行练习", 2, "中")
meta("S4-II09", "稳定归并完整序列", "归并排序、稳定性", "按左段同键优先写稳定归并结果", "原次序左段接右段；左(1a,3a)，右(1b,2,3b)", "处理跨段相等键的稳定次序", "完整带标记序列", "过程追踪", "条件辨析", 2, "中", "无直接source_ids；2024综合只作排序知识历史锚点")
meta("S4-II10", "AVL最少结点递推与计算", "AVL、高度界", "填写最少结点递推式并计算N(5)", "N(0)=0，N(1)=1", "按左右子树高度差至多1构建最小规模", "递推表达式与一个整数", "状态计算", "基础锚点", 3, "中")


def main():
    canonical = {row["id"]: row for row in json.loads(BLUEPRINT.read_text(encoding="utf-8"))}
    assert len(CONTENT) == 28 and len(META) == 28
    proposals = []
    for paper in (3, 4):
        path = SRC / f"第{paper}套.json"
        with zipfile.ZipFile(BACKUP) as archive:
            member = f"资料整理/六套模拟卷成稿/试题源稿/第{paper}套.json"
            doc = json.loads(archive.read(member).decode("utf-8"))
        assert doc["paper"] == paper and len(doc["questions"]) == 24
        doc["version"] = "2026-10-22-student-v2"
        ids = set()
        for q in doc["questions"]:
            qid = q["id"]
            ids.add(qid)
            if qid in CONTENT:
                q["content"] = CONTENT[qid]
            for old, new in IV_REPLACEMENTS.get(qid, ()):
                if old in q["content"]:
                    q["content"] = q["content"].replace(old, new, 1)
                else:
                    assert new in q["content"], (qid, old)
            marks = [int(n) for n in re.findall(r"（(\d+)分）", q["content"])]
            assert sum(marks) == q["points"], (qid, marks, q["points"])
            if q["section"] == "I" and q["number"] in (2, 3, 4):
                assert all(f"__{i}__" in q["content"] for i in (1, 2, 3)), qid
                assert q["content"].count("```") >= 2, qid
            if q["section"] == "II":
                assert not re.search(r"(?m)^\s*[ABCD][\.、]", q["content"]), qid
            row = canonical[qid]
            if qid in META:
                patch = META[qid]
                revision_note = "2026-10-22题型修订：按真题形式重写为" + ("程序阅读代码填空" if q["section"] == "I" else "有限答案填空") + "；逐空标注分值。"
            else:
                patch = {}
                revision_note = ("2026-10-22题型修订：综合题保留原任务与分值。" if q["section"] == "III" else "2026-10-22题型修订：保留算法任务与分值；明确C语言代码及必要接口。")
            fields = ("id", "paper", "section", "number", "points", "title", "chapter", "tags", "task", "data", "objective", "evidence_required", "task_family", "novelty_type", "minutes", "level", "source_ids", "history_ids")
            proposal = {key: patch.get(key, row.get(key)) for key in fields}
            proposal["mode"] = ("程序阅读填空" if q["section"] == "I" else "填空" if q["section"] == "II" else row["mode"])
            proposal["revision_note"] = revision_note
            default_policy = ("原source_ids继续支持本次保留的考点；题面不是原题复刻"
                              if row["source_ids"] else
                              "无直接source_ids；原history_ids仅为考点历史锚点")
            proposal["source_policy"] = patch.get("source_policy", default_policy)
            proposal["suggested_source_ids"] = ([] if qid == "S3-II05" else row["source_ids"])
            proposals.append(proposal)
        assert len(ids) == 24 and len(doc["questions"]) == 24
        assert sum(q["points"] for q in doc["questions"]) == 150
        section_counts = {s: [q["points"] for q in doc["questions"] if q["section"] == s] for s in "I II III IV".split()}
        assert section_counts == {"I": [5] * 4, "II": [3] * 10, "III": [10] * 7, "IV": [8, 10, 12]}, section_counts
        path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(path.relative_to(ROOT), "questions=24", "points=150", "section_scores=20/30/70/30")
    assert len(proposals) == 48
    META_OUT.write_text(json.dumps(proposals, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(META_OUT.relative_to(ROOT), "proposals=48")


if __name__ == "__main__":
    main()
