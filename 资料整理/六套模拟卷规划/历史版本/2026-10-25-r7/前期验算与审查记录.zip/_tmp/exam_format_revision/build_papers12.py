"""Recast student papers 1–2 in the confirmed reading/fill-in format."""

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
STUDENT_DIR = ROOT / "资料整理/六套模拟卷成稿/试题源稿"
BLUEPRINT = ROOT / "资料整理/六套模拟卷规划/六套逐题蓝图.json"
OUT_META = ROOT / "_tmp/exam_format_revision/papers12_revision.json"


CONTENT = {
    "S1-I01": """阅读下面的 C 函数。设 n=2^k（k≥1），整数运算不溢出，填出代码的执行次数和时间复杂度。

@@@c
long countOps(int n) {
    long c = 0;
    for (int i = 1; i < n; i *= 2)
        for (int j = 0; j < i; ++j)
            ++c;
    return c;
}

@@@

当 n=16 时，返回值为 __1__（2分）；一般地，返回值为 __2__（2分）；因此时间复杂度为 Θ(__3__)（1分）。""",

    "S1-I02": """带头结点的单链表中，p 保证是表内数据结点，s 是尚未入表的新结点；head、p、s 均非空。补全把 s 插到 p 前面的 C 函数。

@@@c
typedef struct Node {
    int data;
    struct Node *next;
} Node;

void insertBefore(Node *head, Node *p, Node *s) {
    Node *prev = head;
    while (prev->next != p)
        prev = __1__;
    s->next = __2__;
    __3__ = s;
}
@@@

填写 __1__（1分）、__2__（2分）、__3__（2分）。各空填一个表达式，勿改动其余代码；p 为首个数据结点也应正确。""",

    "S1-I03": """循环单链表队列只保存尾指针 rear；空队列 rear=NULL，非空时 rear->next 指向队首。入队结点 x 原本不在队列中，出队结点交由调用者管理。补全下面的 C 代码。

@@@c
typedef struct Node {
    int data;
    struct Node *next;
} Node;
typedef struct { Node *rear; } Queue;

void enQueue(Queue *q, Node *x) {
    if (q->rear == NULL) {
        x->next = x;
        q->rear = x;
    } else {
        x->next = __1__;
        q->rear->next = x;
        q->rear = x;
    }
}
Node *deQueue(Queue *q) {
    if (q->rear == NULL) return NULL;
    Node *x = q->rear->next;
    if (x == q->rear) __2__;
    else __3__;
    x->next = NULL;
    return x;
}
@@@

填写 __1__（1分）、__2__（2分）、__3__（2分）。__1__ 填表达式，__2__、__3__ 各填一条不带分号的赋值语句；单结点出队后队列应为空。""",

    "S1-I04": """二叉树叶结点的左右孩子均为空。补全下列函数，使它返回从根到最近叶的结点数；空树返回 0。注意只有一个孩子时，不能把空孩子当成叶路径。

@@@c
typedef struct TNode {
    int data;
    struct TNode *left, *right;
} TNode;

int minLeafDepth(TNode *t) {
    if (t == NULL) return 0;
    if (t->left == NULL && t->right == NULL) return 1;
    if (t->left == NULL) return __1__;
    if (t->right == NULL) return __2__;
    int a = minLeafDepth(t->left);
    int b = minLeafDepth(t->right);
    return __3__;
}
@@@

填写 __1__（2分）、__2__（2分）、__3__（1分），均为表达式。""",

    "S1-II01": """函数 F(n) 在 n>1 时只调用一次 F(⌊n/2⌋)，本层其他工作为常数；n≤1 时直接返回。时间复杂度为 Θ(__1__)（2分），递归栈空间复杂度为 Θ(__2__)（1分）。""",

    "S1-II02": """容量足够的顺序表用连续数组 A[0..n−1] 存放 n 个元素，0≤i≤n。已给合法下标 i（读取时 i<n），读取 A[i] 的时间复杂度为 O(__1__)（1分）；在下标 i 处插入新元素，原有元素中必须向后移动 __2__ 个（2分）。""",

    "S1-II03": """循环队列使用长度为 8 的数组，f 指向队首元素的前一个位置，r 指向队尾元素，始终保留一个空槽。当前 f=6、r=2，队长为 __1__（1分）；用 f、r 表示的判满条件是 __2__（2分）。""",

    "S1-II04": """文本 T=ababab，模式 P=abab，允许重叠匹配，位置从 1 开始。P 在 T 中共出现 __1__ 次（1分），第二次出现的起始位置是 __2__（2分）。""",

    "S1-II05": """广义表 L=((a,b),(),c)。Head 取表的第一个元素，Tail 取除首元素外组成的表。Head(Tail(L)) 的结果是 __1__（3分）。请用广义表记法填写。""",

    "S1-II06": """一棵完全二叉树高为 6 层，根为第 1 层，第 5 层恰有 4 个叶结点。该树最多有 __1__ 个结点（3分）。""",

    "S1-II07": """有向图的邻接矩阵 A 中，顶点 v 所在行有 2 个 1，所在列有 3 个 1；图中没有自环。若将所有弧反向，v 的出度为 __1__（1分），入度为 __2__（2分）。""",

    "S1-II08": """依次向空 AVL 树插入 30、10、20。首次失衡属于 __1__ 型（1分），调整后整棵树的根关键字为 __2__（2分）。第一空填 LL、LR、RL 或 RR。""",

    "S1-II09": """一个大根堆至少有两个结点，且关键字互不相同。第二大关键字必位于根结点的某个 __1__ 结点处（3分）。请填与根的亲属关系。""",

    "S1-II10": """开放定址散列表采用线性探测。删除过的槽标为 DELETED，从未占用的槽标为 EMPTY。查找关键字遇到 DELETED 时应 __1__（1分）；遇到 EMPTY 时应 __2__（2分）。请分别填写查找动作。""",

    "S2-I01": """阅读下面的汉诺塔程序。n≥1，move(a,c) 把一枚盘从柱 a 移到柱 c，视为 O(1) 的基本操作；三个柱互不相同。填出 move 的调用次数和程序时间复杂度。

@@@c
void move(char a, char c);
void hanoi(int n, char a, char b, char c) {
    if (n == 1) {
        move(a, c);
        return;
    }
    hanoi(n - 1, a, c, b);
    move(a, c);
    hanoi(n - 1, b, a, c);
}
@@@

调用 hanoi(3,'A','B','C') 时，move 调用 __1__ 次（1分）。若 M(n) 表示 move 的调用次数，M(1)=1，则 n>1 时 M(n)=__2__（2分）；据此得时间复杂度 Θ(__3__)（2分）。""",

    "S2-I02": """双向链表局部链段为 x↔q↔p↔y，四个指针均非空，x、y 可以是哨兵结点。补全代码，把相邻的数据结点 q、p 交换为 x↔p↔q↔y。

@@@c
typedef struct DNode {
    int data;
    struct DNode *prior, *next;
} DNode;

void swapWithPrior(DNode *p) {
    DNode *q = p->prior, *x = q->prior, *y = p->next;
    x->next = p;
    p->prior = x;
    p->next = __1__;
    q->prior = p;
    q->next = __2__;
    y->prior = __3__;
}
@@@

填写 __1__（1分）、__2__（2分）、__3__（2分），均为指针表达式。""",

    "S2-I03": """两个栈共用长度为 6 的数组 data[0..5]。左栈顶 topL 初值 −1，右栈顶 topR 初值 6，右栈向左增长。函数成功返回 1、失败返回 0；出栈值经 out 返回。补全判满、右入栈和右出栈。

@@@c
typedef struct {
    int data[6];
    int topL, topR;
} SharedStack;

int full(const SharedStack *s) {
    return __1__;
}
int pushR(SharedStack *s, int x) {
    if (full(s)) return 0;
    s->data[__2__] = x;
    return 1;
}
int popR(SharedStack *s, int *out) {
    if (s->topR == 6) return 0;
    *out = s->data[__3__];
    return 1;
}
@@@

填写 __1__（1分）、__2__（2分）、__3__（2分）。__2__、__3__ 可在下标表达式中更新 topR；out 保证非空。""",

    "S2-I04": """下面的 C 程序用 height 求子树高度，再判断二叉树是否高度平衡；空树高度为 0，abs 求绝对值。补全代码并分析最坏情况。

@@@c
typedef struct TNode {
    struct TNode *left, *right;
} TNode;

int height(TNode *t) {
    if (t == NULL) return 0;
    int a = height(t->left), b = height(t->right);
    return 1 + __1__;
}
int isBalanced(TNode *t) {
    if (t == NULL) return 1;
    int leftOK = isBalanced(t->left);
    int rightOK = isBalanced(t->right);
    int d = height(t->left) - height(t->right);
    return __2__;
}
@@@

填写 __1__（1分）、__2__（2分）。对 n 个结点的单链树，由于重复求高，该程序的最坏时间复杂度为 Θ(__3__)（2分）；左右子树的递归检查均已执行。""",

    "S2-II01": """设 n≥2 且整数运算不溢出。下列代码中空语句的总执行次数量级为 Θ(__1__)（3分）。

@@@c
for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= i; j *= 2)
        ;
@@@""",

    "S2-II02": """带头结点的单链表有 n 个数据结点。已给结点 p 的指针，在 p 后插入一个已分配的新结点，时间复杂度为 Θ(__1__)（1分）；若只给位置 i（1≤i≤n），从 head 出发沿 next 指针到达第 i 个数据结点，恰需移动 __2__ 次（2分）。""",

    "S2-II03": """带头结点的链队列以 front 指向头结点、rear 指向最后一个数据结点；空队列满足 front==rear。当前仅有一个数据结点 x。将 x 出队并释放后，rear 应指向 __1__（1分），front->next 应为 __2__（2分）。""",

    "S2-II04": """模式 P=aaaaab，位置从 1 开始。定义 π(i) 为 P[1..i] 的最长“真前缀且为后缀”的长度；定义 next[1]=0，j>1 时 next[j]=π(j−1)+1。则 next[6]=__1__（1分），π(6)=__2__（2分）。""",

    "S2-II05": """三维数组 A[1..3][2..5][0..2] 按行优先连续存放，每个元素占 4 字节。A[1,2,0] 的地址为 400，则 A[2,3,2] 的地址是 __1__（3分）。""",

    "S2-II06": """将一棵有序树按“第一个孩子为左孩子、下一个兄弟为右孩子”转换为二叉树，且原树根没有右兄弟。所得二叉树的中序遍历序列，与原树的 __1__ 遍历序列相同（3分）。请填遍历名称。""",

    "S2-II07": """对无向三角形图 A—B—C—A，从 A 开始 BFS，A 的邻接点按 B、C 顺序检查；队列初始仅有 A。若某顶点出队时才标记 visited，且未标记的邻接点都可入队，则 C 在首次出队前共入队 __1__ 次（1分）。为避免重复，应在顶点首次 __2__ 时标记 visited（2分）。""",

    "S2-II08": """对 16 个不同关键字组成的升序顺序表做折半查找。搜索区间采用闭区间 [low,high]，mid 向下取整；每轮与 A[mid] 作一次三路比较，区间变空即判失败。一次失败查找最多比较 __1__ 次关键字（3分）。""",

    "S2-II09": """散列表长 m=11，散列函数 H(key)=key mod 11，按 12、23、34 的顺序插入，冲突时线性探测下一槽，槽号为 0..10。关键字 34 最终在槽 __1__（1分）；以这三个关键字等概率做成功查找，平均查找长度 ASL 为 __2__（2分）。探测一次槽算比较一次。""",

    "S2-II10": """对初始严格递增的 n 个不同关键字做降序二分插入排序：用二分查找确定插入位置，再移动元素腾位。关键字比较总次数为 Θ(__1__)（1分），元素移动总次数为 Θ(__2__)（2分）。""",
}

IV_CONTENT = {
    "S1-IV01": """带头结点的单链表定义如下。L 与 out 保证非空，L 只有头结点时表示空表。设计函数删除倒数第 k 个数据结点，并通过 out 返回其 data；成功返回 1，k≤0 或 k 大于数据结点数时返回 0，失败时链表与 out 原值不变。成功时释放被删结点。禁止先计算表长后从头再次遍历；要求单趟向前扫描、时间 O(n)、额外空间 O(1)。

@@@c
typedef struct Node {
    int data;
    struct Node *next;
} Node;
int deleteKthFromEnd(Node *L, int k, int *out);
@@@

（1）说明如何保持定位“待删结点的前驱”所需的指针间距。（2分）
（2）写出完整的 C 语言函数代码，包括成功与失败返回以及 free 释放结点。（4分）
（3）说明空表、k=1 和 k 越界的处理。（1分）
（4）给出时间、额外空间复杂度。（1分）""",

    "S1-IV02": """普通二叉树结点的 data 可能重复，因此只能通过结点指针判定目标。给定非空树根 root，指针 p、q 均指向树内结点，且允许 p==q。设计函数同时返回 p、q 的最近公共祖先结点指针，以及两结点之间的边数；返回 1 表示成功。outLca、outDist 均为有效指针。可使用与树高 h 成正比的辅助存储，要求时间 O(n)。

@@@c
typedef struct TNode {
    int data;
    struct TNode *left, *right;
} TNode;
int lcaAndDistance(TNode *root, TNode *p, TNode *q,
                   TNode **outLca, int *outDist);
@@@

可使用下面已提供的动态路径接口，不必实现容器本身。newPath 返回有效空路径；pushPath 在末尾追加结点，popPath 删除末尾结点；pathAt(P,i) 返回下标 i 的结点（从 0 开始）；pushPath 摊还 O(1)，容器占用 O(当前路径长度) 空间。用完后调用 freePath。结点是否相同应比较指针，不能比较 data。

@@@c
typedef struct Path Path;
Path *newPath(void);
void pushPath(Path *P, TNode *x);
void popPath(Path *P);
int pathSize(const Path *P);
TNode *pathAt(const Path *P, int i);
void freePath(Path *P);
@@@

（1）说明如何利用从根到 p、q 的路径确定最近公共祖先与边数。（2分）
（2）写出 C 语言函数代码，包含查找路径、比较公共前缀和输出结果；辅助函数也应给出实现。（5分）
（3）说明 p==q 时的返回结果。（1分）
（4）分析 n 个结点、高度 h 时的时间与额外空间复杂度。（2分）""",

    "S1-IV03": """有向无权图 G 采用邻接表，顶点编号 0～V−1，邻接表给出了图的全部弧且无重边；每个顶点的邻接点按编号升序排列。输入顶点 s、t（均合法，可相同）。设 dist(a,x) 为从 a 到 x 的最少边数，不可达时为∞。要求找一个从 s、t 都可达的顶点 x，使 max(dist(s,x),dist(t,x)) 最小；若并列，选编号最小者。同时输出各一条从 s、t 到 x 的最短路径。不存在这样的 x 时返回 0。

图与函数接口如下。G->head[v] 是从 v 出发的邻接链表，Arc.to 是弧的终点；V≥1，E 为弧数。输出参数均非空，路径数组由调用者提供，容量各至少 V；路径从起点写到 x，含两端点，lenS、lenT 返回结点数；成功返回 1。

@@@c
typedef struct Arc {
    int to;
    struct Arc *next;
} Arc;
typedef struct {
    int V, E;
    Arc **head;
} Graph;
int bestMeet(const Graph *G, int s, int t,
             int *x, int *radius,
             int *pathS, int *lenS, int *pathT, int *lenT);
@@@

（1）说明为何两次广度优先搜索足以取得选择 x 所需的信息。（2分）
（2）写出 C 语言代码，可自写 BFS 和路径恢复辅助函数；须包含距离、前驱记录、并列处理、路径恢复和失败返回。（6分）
（3）说明 s==t 及“仅从一个起点可达”的顶点如何处理。（2分）
（4）给出时间与额外空间复杂度，以 V 和 E 表示。（2分）""",

    "S2-IV01": """带头结点的单链表存放整数，要求把所有负数结点稳定地移到所有非负数结点之前。“稳定”指负数组内部及非负数组内部的原相对次序保持不变。只重连原有数据结点，不新建数据结点；允许使用局部哨兵变量。头结点地址 L 不变。要求 O(n) 时间、O(1) 额外空间。

@@@c
typedef struct Node {
    int data;
    struct Node *next;
} Node;
void stableNegFirst(Node *L);
@@@

（1）说明扫描时如何分别维护两类结点的次序。（2分）
（2）写出完整的 C 语言函数代码，包含断开旧链接并拼接两段。（4分）
（3）说明全为负数、全为非负数及空表时的结果，并分析复杂度。（2分）""",

    "S2-IV02": """一般树用孩子兄弟链表存储：firstChild 指向第一个孩子，nextSibling 指向下一个兄弟；根的 nextSibling 为 NULL。空树深度为 0，根所在层为 1。设计非递归算法求树深度。

@@@c
typedef struct TNode {
    struct TNode *firstChild, *nextSibling;
} TNode;
int treeDepth(TNode *root);
@@@

可使用如下已提供的动态栈接口，不必实现栈本身。newStack 返回有效空栈；push、pop 的调用均保证成功，栈空间按实际元素数增长；用完后调用 freeStack。

@@@c
typedef struct { TNode *node; int depth; } Item;
typedef struct Stack Stack;
Stack *newStack(void);
void push(Stack *s, Item x);
Item pop(Stack *s);
int empty(const Stack *s);
void freeStack(Stack *s);
@@@

（1）说明弹出一个结点时，其孩子和兄弟应分别携带什么层数。（2分）
（2）使用给定栈接口写出完整的 C 语言 treeDepth 函数代码，包含入栈、出栈及深度更新。（5分）
（3）说明空树和只有根结点的边界结果。（1分）
（4）给出 n 个结点时的时间复杂度及最坏额外空间复杂度。（2分）""",

    "S2-IV03": """无向简单图 G 采用邻接表，顶点编号 0～V−1，V≤12。输入三个互不相同的合法顶点 u、w、v 和整数 k。设计函数判断是否存在一条从 u 到 v、恰好经过 k 条边、途经 w、且顶点不重复的路径；找到时输出任意一条这样的顶点序列，找不到时返回 0。k<0 或 k>V−1 时应立即失败。路径数组由调用者提供，容量至少 V，pathLen 与 path 均有效；成功返回 1。

邻接表中 G->head[x] 列出 x 的全部邻接点，Arc.to 为邻接顶点。无向边在两个端点的邻接链表中各出现一次；E 表示无向边数。

@@@c
typedef struct Arc {
    int to;
    struct Arc *next;
} Arc;
typedef struct {
    int V, E;
    Arc **head;
} Graph;
int findPath(const Graph *G, int u, int w, int v, int k,
             int *path, int *pathLen);
@@@

（1）说明深度优先搜索时需要维护哪些状态，以及何时剪枝。（2分）
（2）写出 C 语言函数及所需辅助函数代码，包含 visited 标记、路径记录、成功判定、回溯撤销和失败返回。（6分）
（3）说明为何输出路径同时满足“简单、恰 k 条边、途经 w”，以及 k 越界的处理。（2分）
（4）给出一个以 V 表示的最坏时间上界和额外空间复杂度；说明输入邻接表是否计入额外空间。（2分）""",
}

# Title, concise task, given data, observable objective, submitted evidence,
# response family, novelty, expected minutes, level, source guidance.
META = {
    "S1-I01": ("几何循环次数与复杂度填空", "读双层循环填具体与一般执行次数及复杂度", "n=2^k；n=16", "求和后判断总工作量", "15、n−1、Θ(n)三个空", "复杂度分析", "基础锚点", 5, "中", "2024阅读1仅支持复杂度题型，循环内容为另编；旧历史锚点保留。"),
    "S1-I02": ("单链表前驱插入代码填空", "补前驱遍历及两次安全重连", "带头结点；p在表内；s未入表", "写出在首结点也成立的指针重连", "三个代码表达式", "程序填空", "平行练习", 5, "基", "2024阅读2支持单链表插入方法，但原题为代码片段排序；仅作历史方法锚点。"),
    "S1-I03": ("仅尾指针循环链队列程序填空", "补入队与空队列/非空队列出队的关键语句", "rear==NULL为空；rear->next为队首", "维护队尾及队首指针不变量", "入队表达式、单结点与多结点出队语句", "程序填空", "条件辨析", 5, "基", "2025阅读3为同结构队列代码填空，可支持任务形态；本题覆盖入队、两种出队分支与结点脱链，不宜称全新算法。"),
    "S1-I04": ("最近叶深度递归程序填空", "补仅有左/右孩子及双孩子的返回式", "空树0；叶结点1", "区分空孩子和真实叶路径", "三个分支返回表达式", "程序填空", "条件辨析", 5, "中", "独立组题，无直接历年来源；原历史锚点为空。"),
    "S1-II01": ("递半规模递归复杂度填空", "填时间及递归栈量级", "每层一次F(⌊n/2⌋)和常数工作", "依据递归深度判断两种资源", "两个渐近式", "复杂度分析", "基础锚点", 2, "基", "2025阅读1是复杂度题型锚点，非此递推实例；建议转历史锚点。"),
    "S1-II02": ("顺序表随机访问与插入位移", "填按下标访问复杂度和插入位移数", "n个元素，0≤i≤n，容量足够", "区分直接寻址与元素位移", "O(1)与n−i", "数量计算", "平行练习", 2, "基", "旧408选择题仅支持知识点，非本填空实例；建议转历史锚点。"),
    "S1-II03": ("循环队列长度与判满条件", "填给定指针下队长及判满条件", "数组长8；f=6，r=2；留空槽", "应用指定指针约定", "队长与模运算条件", "条件辨析", "基础锚点", 3, "中", "2024填空1支持相近题型和循环队列方法，可保留直接方法来源。"),
    "S1-II04": ("重叠模式匹配次数", "填重叠出现次数及第二个起点", "T=ababab，P=abab，1起始", "辨识允许重叠的匹配区间", "次数与位置", "数量计算", "平行练习", 2, "中", "独立组题，无直接历史来源。"),
    "S1-II05": ("广义表空表的Head/Tail", "填Head(Tail(L))的广义表结果", "L=((a,b),(),c)", "区分空表和原子", "表记法结果", "结构推断", "基础锚点", 2, "基", "独立组题；2025填空7仅可作为另题型背景，不新增未经核实的直接来源。"),
    "S1-II06": ("完全二叉树容量上界", "由指定层叶子数填最大结点数", "高6；第5层4叶", "由完全性约束推末层最大容量", "55及可复算层数", "数量计算", "条件辨析", 3, "中", "2024填空9为完全二叉树计数同法锚点，数据与条件不同。"),
    "S1-II07": ("邻接矩阵反向后的度", "填反弧后指定顶点入出度", "原矩阵行2列3；无自环", "将行/列与入/出度对应并反转", "出度3、入度2", "数量计算", "条件辨析", 2, "中", "独立组题，无直接历年来源。"),
    "S1-II08": ("AVL三键插入调整", "填失衡类型和调整后的根", "30、10、20", "识别LR双旋并确定新根", "LR、20", "结构推断", "基础锚点", 2, "中", "2026综合18为AVL方法参考，原题分量更大；建议历史方法锚点而非同题来源。"),
    "S1-II09": ("大根堆第二大位置", "填第二大值与根的关系", "互异关键字；堆至少2结点", "运用堆偏序性质定位候选", "根的孩子", "条件辨析", "基础锚点", 2, "基", "旧408来源支持堆性质，不确定是否与此题同问；建议历史锚点。"),
    "S1-II10": ("线性探测删除标记的查找", "分别填遇删除槽与空槽时的处理", "DELETED与EMPTY定义", "依据探测链保持条件判停", "自主写出继续探测与判失败动作", "条件辨析", "基础锚点", 2, "中", "独立组题，无直接历年来源。"),
    "S2-I01": ("汉诺塔调用次数与复杂度填空", "读递归代码填具体move次数、递推式和时间量级", "n=3；M(1)=1；move为O(1)基本操作", "从两次规模减一调用写递推", "7、2M(n−1)+1、Θ(2^n)", "复杂度分析", "基础锚点", 5, "基", "2025阅读1本身即汉诺塔复杂度，源题直接支持题型及方法；本题另问具体次数和递推，保持基础锚点标记。"),
    "S2-I02": ("双链表相邻交换代码填空", "补相邻结点交换后的三个链接", "x↔q↔p↔y，四指针非空", "维护双向链接对称性", "p->next、q->next、y->prior三个表达式", "程序填空", "基础锚点", 5, "中", "2025阅读2同为双链表邻接交换代码填空，直接支持方法与形式；明确为基础平行练习，不主张新算法。"),
    "S2-I03": ("共享栈右侧进出栈填空", "补判满、右入栈和右出栈下标", "容量6；topL=−1，topR=6", "正确处理相向增长的边界和指针更新", "满条件、前置递减、后置递增", "程序填空", "条件辨析", 5, "基", "2026阅读2仅为方法锚点；旧题错误诊断任务已改为正确代码填空，建议仅列历史。"),
    "S2-I04": ("重复求高的平衡树程序填空", "补height最大值、平衡判断表达式和最坏复杂度", "空树高度0；单链树n结点", "读正确程序识别重复求高成本", "最大值式、平衡式、Θ(n²)", "代码补全", "表示转换", 5, "中", "独立组题；避免与其他套失败传播错误诊断同任务。"),
    "S2-II01": ("嵌套对数循环复杂度", "填双层循环总执行量级", "i=1..n；j倍增至i", "对每个i计log i并求和", "Θ(n log n)", "复杂度分析", "基础锚点", 2, "中", "独立组题，2025填空1支持题型但代码不同，勿当直接来源。"),
    "S2-II02": ("给指针与给位置的插入", "填指针插入紧确量级与从头定位的移动次数", "带头结点单链表有n个数据结点；给p或给i，1≤i≤n", "区分Θ(1)重连与精确定位步数", "Θ(1)、沿next移动i次", "复杂度分析", "条件辨析", 2, "基", "2026填空12为方法参考，若未核实同任务仅保留历史锚点。"),
    "S2-II03": ("链队列最后结点出队", "填单结点出队后的两指针状态", "front头结点；rear唯一数据结点", "维护空队列不变量", "rear=front、front->next=NULL", "条件辨析", "基础锚点", 2, "中", "独立组题，无直接历年来源。"),
    "S2-II04": ("KMP两种next定义下的数值", "填next[6]与π(6)", "P=aaaaab；显式给π/next约定", "应用明示定义而非记忆版本", "5与0", "数量计算", "条件辨析", 3, "中", "2024填空3及2025填空8均有KMP next填空；模式与定义另编，作为题型/方法锚点。"),
    "S2-II05": ("三维数组行优先寻址", "填A[2,3,2]地址", "非零下界、元素4字节、基址400", "计算三维线性偏移", "468", "数量计算", "平行练习", 2, "基", "2025填空3为数组地址同法锚点；维数/下界/数值不同。"),
    "S2-II06": ("孩子兄弟转换后的遍历", "填二叉树中序对应的树遍历", "首孩子左、下兄弟右；根无右兄弟", "运用孩子兄弟编码顺序关系", "原树后序", "表示转换", "基础锚点", 2, "基", "旧408选择题可作方法参考，非本填空实例；建议历史锚点。"),
    "S2-II07": ("BFS标记时机的重复入队", "填小图中C入队次数和正确标记时机", "三角形；A起点；邻接B、C顺序", "追踪队列并修正访问时机", "2次及入队时", "过程追踪", "错解诊断", 3, "中", "独立组题，无直接历年来源。"),
    "S2-II08": ("二分查找失败比较上界", "填16键时最多比较数", "闭区间；mid下取整；三路比较", "追踪失败分支长度", "5", "数量计算", "基础锚点", 2, "中", "2026填空13可支持折半查找方法，条件不明时仅历史锚点。"),
    "S2-II09": ("线性探测槽位与成功ASL", "填34终槽和三键成功ASL", "m=11；H=mod11；12、23、34；线性探测", "逐次探测并平均比较次数", "槽3、ASL2", "过程追踪", "平行练习", 3, "中", "旧408-2022-9只支持散列知识；已由概念因素选择改为具体插入追踪，建议旧源仅历史锚点。"),
    "S2-II10": ("二分插入降序排序成本", "填比较及移动的渐近量级", "初始严格递增；目标降序", "区分定位比较与元素搬移", "Θ(nlogn)、Θ(n²)", "复杂度分析", "条件辨析", 3, "中", "题集-10-选7仅知识/任务方法参考；旧选择题格式已改填空，建议历史锚点。"),
}


def main():
    assert len(CONTENT) == len(META) == 28
    blueprint = {r["id"]: r for r in json.loads(BLUEPRINT.read_text(encoding="utf-8"))}
    revision = {}
    for paper in (1, 2):
        path = STUDENT_DIR / f"第{paper}套.json"
        obj = json.loads(path.read_text(encoding="utf-8"))
        assert len(obj["questions"]) == 24
        for q in obj["questions"]:
            if q["section"] == "IV":
                id_ = q["id"]
                q["content"] = IV_CONTENT[id_].replace("@@@", "```")
                scores = [int(n) for n in re.findall(r"（(\d+)分）", q["content"])]
                assert sum(scores) == q["points"], (id_, scores)
                revision[id_] = {
                    "revision_note": "算法契约与原题不变；卷面要求 C 语言代码，并补充数据结构/辅助栈接口，使字段、容量和分配责任明确。蓝图原 task/data/answer_blueprint/rubric 应保持不变。"
                }
                continue
            if q["section"] not in ("I", "II"):
                continue
            id_ = q["id"]
            q["content"] = CONTENT[id_].replace("@@@", "```")
            scores = [int(n) for n in re.findall(r"（(\d+)分）", q["content"])]
            assert sum(scores) == q["points"], (id_, scores)
            blanks = re.findall(r"__(\d+)__", q["content"])
            assert blanks and max(map(int, blanks)) <= 3, (id_, blanks)
            assert not re.search(r"(?m)^[ABCD]\.", q["content"]), id_
            title, task, data, objective, evidence, family, novelty, minutes, level, source_note = META[id_]
            old = blueprint[id_]
            direct = ("2025阅读1" in source_note and id_ == "S2-I01") or id_ in ("S1-I03", "S1-II03", "S1-II06", "S2-I02", "S2-II04", "S2-II05")
            source_ids = old.get("source_ids", []) if direct else []
            history_ids = list(dict.fromkeys(old.get("history_ids", []) + ([] if direct else old.get("source_ids", []))))
            revision[id_] = {
                "title": title, "chapter": old["chapter"], "tags": (
                    ["递归复杂度", "汉诺塔"] if id_ == "S2-I01" else
                    ["树与二叉树转换", "树的遍历"] if id_ == "S2-II06" else
                    old["tags"]
                ),
                "task": task, "data": data, "objective": objective,
                "evidence_required": evidence, "task_family": (
                    "代码补全" if q["section"] == "I" and q["number"] >= 2 else family
                ),
                "novelty_type": novelty, "minutes": minutes, "level": level,
                "revision_note": "按2024/2025回忆修订版及机构固定4/10/7/3结构，将学生题面改为可判定的程序阅读/填空；" + source_note,
                "source_guidance": source_note,
                "source_ids_recommendation": source_ids,
                "history_ids_recommendation": history_ids,
            }
        obj["version"] = "2026-10-22-student-v2"
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    OUT_META.write_text(json.dumps(revision, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("revised", len(revision), "questions; papers 1-2")


if __name__ == "__main__":
    main()
