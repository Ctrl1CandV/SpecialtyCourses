import json, importlib.util
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2]
PLAN=ROOT/'资料整理/六套模拟卷规划'
original=json.loads((PLAN/'历史版本/2026-10-20/六套逐题蓝图.json').read_text(encoding='utf-8'))
merged={r['id']:r for r in original}
for name in ('patch_s1_s2.json','patch_s3_s4.json','patch_s5_s6.json'):
    patch=json.loads((ROOT/'_tmp/exam_revision'/name).read_text(encoding='utf-8'))
    for qid,row in patch.items():
        assert row['id']==qid
        assert isinstance(row['paper'],int)
        assert isinstance(row['source_ids'],list)
        assert isinstance(row['evidence_required'],str)
        merged[qid]=row

def task_family(r):
    if r['section']=='IV': return '算法设计'
    if r['chapter']=='绪论' and r['title']!='共享队列接口下的表示不变量': return '复杂度分析'
    t=r['novelty_type']
    if t=='逆向推断': return '逆向推断'
    if t=='错解诊断': return '错误诊断'
    if t=='表示转换': return '表示转换'
    if r['section']=='III' and any(x in r['title'] for x in ('对照','选结构','成本','性能','最优性')): return '性能比较'
    if t=='约束变化': return '状态维护'
    if t=='条件辨析': return '条件辨析'
    if r['section']=='III' and any(x in r['title'] for x in ('构造','构树','整树','森林','Huffman')): return '结构构造'
    if r['section']=='II': return '条件辨析'
    return '过程追踪'

rows=[merged[r['id']] for r in original]
for r in rows:
    r['task_family']=task_family(r)
    r.pop('evidence',None)
    r['design_version']='2026-10-21-r2'
(PLAN/'六套逐题蓝图.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
spec=importlib.util.spec_from_file_location('seeds',ROOT/'tools/verify_exam_seeds.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
ids=sorted({r['id'] for r in mod.run_checks()})
binding={'version':'2026-10-21-r2','说明':'经本轮人工确认的task/data/answer_blueprint哈希。更改题目后须同时审查核验输入和预期结果，不能只重绑定使旧核验过关。','design_hashes':{qid:mod.signature(merged[qid]) for qid in ids}}
(PLAN/'核验输入绑定.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Task families',dict(Counter(r['task_family'] for r in rows)))
for p in range(1,7):
    items=[r for r in rows if r['paper']==p]
    print(p,len(items),sum(r['points'] for r in items),sum(r['minutes'] for r in items))
