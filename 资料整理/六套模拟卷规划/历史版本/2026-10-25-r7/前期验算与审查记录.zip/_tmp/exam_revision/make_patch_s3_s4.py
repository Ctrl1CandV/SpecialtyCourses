"""Create reviewed S3/S4 blueprint patch without changing the canonical blueprint."""

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "资料整理/六套模拟卷规划/六套逐题蓝图.json"
OUTPUT = Path(__file__).with_name("patch_s3_s4.json")
rows = {r["id"]: r for r in json.loads(SOURCE.read_text(encoding="utf-8-sig")) if r["paper"] in (3, 4)}
patch = {}

CHAPTER_REF = {
    "绪论": "课件/C2/C2-A-01/deck.yaml",
    "线性表": "课件/C2/C2-B-pro/C2-B-01/deck.yaml",
    "栈队列": "课件/C2/C2-B-pro/C2-B-03/deck.yaml",
    "串": "课件/C2/C2-A-06/deck.yaml",
    "数组广义表": "知识笔记/重邮数据结构.md",
    "树": "课件/C2/C2-B-pro/C2-B-05/deck.yaml",
    "图": "课件/C2/C2-B-pro/C2-B-06/deck.yaml",
    "查找": "课件/C2/C2-B-pro/C2-B-08/deck.yaml",
    "排序": "课件/C2/C2-B-pro/C2-B-10/deck.yaml",
}


def add(qid, *, objective, evidence, misconception, transfer, family, novelty,
        minutes, time_reason, rubric, exposure_status="待核实", exposure_refs=None,
        exposure_response="成稿前对照实际已发课件与实讲记录；同题仅作回顾，不冒称迁移。",
        revision_note="", **changes):
    row = dict(rows[qid])
    row.update(changes)
    for field in ("source_ids", "history_ids", "tags"):
        if isinstance(row[field], str):
            row[field] = [value.strip() for value in row[field].split("；") if value.strip()]
    row["objective"] = objective
    row["evidence_required"] = evidence
    row["misconception"] = misconception
    row["transfer"] = transfer
    row["task_family"] = family
    row["novelty_type"] = novelty
    row["minutes"] = minutes
    row["time_reason"] = time_reason
    row["rubric"] = rubric
    row["exposure"] = {
        "status": exposure_status,
        "references": exposure_refs if exposure_refs is not None else [CHAPTER_REF[row["chapter"]]],
        "response": exposure_response,
    }
    row["revision_note"] = revision_note or "保留可核的考试能力，题面和答案成稿时独立审校。"
    row["change"] = row["revision_note"]
    if sum(score for _, score in rubric) != int(row["points"]):
        raise ValueError(f"{qid}: rubric does not sum to points")
    if row["id"] != qid or row["section"] not in ("I", "II", "III", "IV"):
        raise ValueError(qid)
    patch[qid] = row


# 第三套：程序阅读。基础锚点可以保留，但答案须要求执行证据。
add("S3-I01", objective="把嵌套循环的每层工作量相加，而非数外层轮次", evidence="n=8逐层计数8+8+8+8=32；一般为n(⌊log₂n⌋+1)，时间Θ(n log n)", misconception="外层倍增就把整个程序误写成O(log n)", transfer="从单循环倍增转为外层倍增且每轮扫描n次，改变总工作量", family="程序阅读·复杂度", novelty="目标变化", minutes=5, time_reason="四轮表格与渐近判断，5分钟可完成", rubric=[["n=8四轮及总次数",2],["一般执行次数",2],["时间复杂度与理由",1]], answer_blueprint="n=8时外层i=1,2,4,8，各扫描8次，共32次；n为2的幂时n(log₂n+1)，Θ(n log n)，辅助空间Θ(1)。", revision_note="保留原创程序阅读；题面须给完整代码及计数语句，不以只写复杂度充题。")
add("S3-I02", objective="读懂链表选择排序中的数据交换，并判断记录身份的稳定性", evidence="跟踪(4a,2,4b,1)一轮选择后为(1,2,4b,4a)，末态相等键次序颠倒；给出Θ(n²)", misconception="只看关键字排序正确，就断言算法稳定；把数据交换当成结点重连", transfer="原2025阅读题的补空改为记录身份与稳定性诊断；不是平行换数", family="程序阅读·链表排序", novelty="错解诊断", minutes=6, time_reason="需追踪两轮及解释身份，略长于普通阅读空", rubric=[["说明代码交换记录域而非结点链接",1],["正确跟踪一轮及最终键序",2],["指出4b先于4a且不稳定",1],["比较次数Θ(n²)",1]], title="链表选择排序会不会稳定", task="给四个按next连接的记录(4a,2,4b,1)，代码每趟从未排序后缀找严格更小的结点，交换当前结点与最小结点的整条记录域，不重接next。阅读短代码，给第一趟和最终记录顺序，判断稳定性及最坏时间。", data="初始记录顺序(4a,2,4b,1)；相同键用a/b标识原先后。", answer_blueprint="首趟把1与4a交换，得(1,2,4b,4a)；最终也是(1,2,4b,4a)，相同键4的顺序颠倒，故不稳定。每趟扫描剩余链段，总时间Θ(n²)，辅助空间O(1)。", mode="改编", exposure_status="待录课件同题", exposure_refs=["课件/C3/C3-B-05/deck.yaml", "课件/C2/C2-B-pro/C2-B-01/deck.yaml"], exposure_response="旧C3课件未按现行方案发放；核B01实讲。保留稳定性诊断这一新增要求，不直接重印2025阅读原空。", revision_note="原案直接保留2025阅读4补空，改为有记录身份的运行与性质诊断；成稿须给短代码而非口头描述。")
add("S3-I03", objective="把后缀表达式的两次出栈映射为左右操作数", evidence="9 3 / 后栈顶3；再与2做减法得1；指出先弹的是右操作数", misconception="把先弹值作为减法或除法左操作数", transfer="基础读码题，无额外迁移；诚实作为栈与表达式的锚点", family="程序阅读·栈", novelty="基础锚点", minutes=5, time_reason="两次运算和一个方向解释", rubric=[["第一次左右操作数及结果3",2],["第二次结果1",1],["出栈赋值方向和非交换性理由",2]], task="给后缀求值短程序，栈中依次处理9 3 / 2 -；补出两个操作数的赋值方向，写两次运算后的栈顶和最终值。除法按整数整除。", answer_blueprint="第一次先弹3为右操作数，再弹9为左，9/3=3；第二次先弹2为右，再弹3为左，3-2=1。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-03/deck.yaml"], exposure_response="此题只承担基础检索，不标原创迁移；若课堂已用同一数据则更换表达式并重新核答。", revision_note="题目被旧稿标原创但只是基础求值；改为基础锚点并要求方向证据。")
add("S3-I04", objective="区分DFS扫描边与首次到达新顶点的树边", evidence="按0、1、2、3启动，树边0→1、1→2，分量2；打印语句应在未访问分支内", misconception="扫描过的边都属于DFS森林", transfer="从2026阅读题的代码补空转为非树边反例与输出修正", family="程序阅读·DFS", novelty="错解诊断", minutes=6, time_reason="四顶点运行轨迹与一处代码定位", rubric=[["指出打印语句必须在if未访问分支",2],["两条树边顺序",2],["分量数2",1]], answer_blueprint="外层从0开始，递归边为0→1、1→2；扫描回边/横边不打印；3单独成一棵树，共2个分量。", exposure_status="待录课件同题", exposure_refs=["课件/C2/C2-B-pro/C2-B-06/deck.yaml", "课程设计/C3课程内容设计.md"], exposure_response="2026阅读原题已在材料中，现改为运行反例；核实际课堂是否展示此代码，若已展示同图则改图。", revision_note="保留近年程序阅读风格，但不照抄有争议的原打印逻辑。")

# 第三套：单选各只认一项3分。靠真实误区而非冷僻事实分层。
add("S3-II01", objective="用递归层级之和判断线性层工作量的分治程序", evidence="n+n/2+n/4+…<2n，选Θ(n)", misconception="看到递归层数log n便选Θ(log n)", transfer="基础复杂度组合题，无复杂迁移", family="单选·复杂度", novelty="条件辨析", minutes=2, time_reason="一条等比和判断", rubric=[["唯一正确选项：Θ(n)",3]], answer_blueprint="T(n)=n+n/2+…+1=2n−1，故Θ(n)。", revision_note="选项须把Θ(log n)、Θ(n log n)、Θ(n²)设为有因果的干扰项。")
add("S3-II02", objective="确认顺序表删除保序时必须搬动的后缀长度", evidence="第i项之后恰有n−i项，选n−i", misconception="把被删元素也算入移动或误用0基位置", transfer="基础锚点；不包装成改编或创新", family="单选·顺序表", novelty="基础锚点", minutes=2, time_reason="一个位序公式", rubric=[["唯一正确选项：n−i",3]], answer_blueprint="位序i+1至n共n−i个元素须各前移一格。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-A-02/deck.yaml"], exposure_response="作为基础得分点保留；若原题已布置，换成等价情境仍标平行练习。", revision_note="保留一题必要的低门槛基础题。")
add("S3-II03", objective="根据首个出栈元素为最后入栈元素锁定剩余LIFO次序", evidence="余下n−1,…,1唯一；任给第i个位置按倒序求值", misconception="误以为首次出栈后还可随意重排已在栈中的元素", transfer="近年同任务基础锚点，不算迁移", family="单选·栈序列", novelty="基础锚点", minutes=3, time_reason="需要先画一次满栈", rubric=[["唯一正确选项：剩余输出唯一且递减",3]], task="互异元素1..5顺次入栈，若首个出栈的是5，选择完整可能输出序列。", answer_blueprint="为先弹5，1..5已全部入栈，余下只能4,3,2,1；完整输出5,4,3,2,1。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-03/deck.yaml"], exposure_response="仅作限时基础锚点，避免把近年真题当陌生迁移题。", revision_note="固定n=5让选项可独立核对；不再模糊问第i个值。")
add("S3-II04", objective="在KMP连续失配时保持文本指针不回退", evidence="i始终9，j由5→3→1，下一待比状态(9,1)", misconception="把i退回或把next值当作已比较字符数", transfer="从next表计算迁移到运行状态更新", family="单选·KMP", novelty="目标变化", minutes=3, time_reason="两次next跳转，需明确状态定义", rubric=[["唯一正确选项：(i,j)=(9,1)",3]], answer_blueprint="两次失配仅按next[5]=3、next[3]=1更新j，主串下标i=9保持不变。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-A-06/deck.yaml", "课件/C2/C2-B-pro/C2-B-03/deck.yaml"], exposure_response="next计算已教，阅读状态任务作为单选；实际讲过同一链时再换链。", revision_note="题面必须声明i、j都指下一待比较字符的1基下标。")
add("S3-II05", objective="理解稀疏矩阵三元组数据须伴随矩阵尺寸", evidence="坐标和值不足以区分尾部全零行列；需行数和列数", misconception="以最大出现下标反推原矩阵完整大小", transfer="基础锚点，无迁移", family="单选·稀疏矩阵", novelty="基础锚点", minutes=2, time_reason="一条反例即可判断", rubric=[["唯一正确选项：行数与列数",3]], answer_blueprint="三元组只列非零项；尾部全零行或列不会出现，须另存矩阵行数和列数（通常也存非零项数）。", revision_note="若题面问三元组表头，明确是否把非零项数计入必存信息。")
add("S3-II06", objective="用树的出度总和反推叶子数", evidence="n0=1+2n3+n2=1+8+3=12", misconception="把度1结点直接并入叶子，或漏掉根的常数1", transfer="基础性质应用，不伪装新题", family="单选·树性质", novelty="基础锚点", minutes=2, time_reason="一个公式一次代入", rubric=[["唯一正确选项：12",3]], answer_blueprint="由∑度=n−1，得n0=1+∑(d−1)n_d=1+2×4+1×3=12；度1结点不改变结果。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-A-07/deck.yaml"], exposure_response="若实际课件已给完全相同数字，平行数据练习仍按基础锚点标注。")
add("S3-II07", objective="区分关键事件与关键活动", evidence="e=ve(u)=2，l=vl(v)−3=4，时差2，非关键", misconception="活动两个端点是关键事件就必为关键活动", transfer="以相反结论检验AOE公式使用", family="单选·AOE", novelty="条件辨析", minutes=2, time_reason="两次代入并判断时差", rubric=[["唯一正确选项：e=2、l=4、非关键",3]], answer_blueprint="活动最早开始2、最迟开始4、总时差2，因此非关键。", exposure_status="课件同法", exposure_refs=["知识笔记/重邮数据结构.md"], exposure_response="知识笔记非发放证据；成稿前查专业课/已发题单，若同题则换数而仍标基础条件辨析。")
add("S3-II08", objective="失败ASL按题设查询分布加权，而非机械除表长", evidence="只对初始地址0..6七处取平均", misconception="表长11就一律以11作分母", transfer="改变散列查询分布这个前提", family="单选·散列ASL", novelty="条件辨析", minutes=2, time_reason="识别样本空间，不做完整探测表", rubric=[["唯一正确选项：起点0..6共7处",3]], answer_blueprint="失败查询初始地址只在0..6均匀分布，故ASL=(c0+…+c6)/7；其余起点概率0。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-08/deck.yaml"], exposure_response="已有ASL手算方法，但分布前提是新检查；不要求机械重复完整散列表。")
add("S3-II09", objective="追踪小根堆新键沿父链上滤", evidence="给(1,4,2,9,7,6)插0，新数组(0,4,1,9,7,6,2)", misconception="把插入当自底向下建堆或只同一层比较", transfer="现库题任务平行；只作为基础过程锚点", family="单选·堆", novelty="平行练习", minutes=3, time_reason="两次父子交换并核数组", rubric=[["唯一正确选项：(0,4,1,9,7,6,2)",3]], task="给小根堆1基顺序数组(1,4,2,9,7,6)，插入键0，选择两次上滤后的完整数组。", data="小根堆A[1..6]=(1,4,2,9,7,6)，新键0。", answer_blueprint="末尾插0；同父结点2换位，再同根1换位，得(0,4,1,9,7,6,2)。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-10/deck.yaml"], exposure_response="课堂若已有完全同数组则改数据，仍标平行练习，不计原创。", revision_note="原行未给实际堆，已补自包含可核数据。")
add("S3-II10", objective="判断互异键BST删除双孩子结点的合法替代键", evidence="只能选左子树最大或右子树最小，且须从原位置删除该替代结点", misconception="可直接取任意左/右孩子作为替代，或替值后不删源结点", transfer="官方范围未核，改用基础BST删除；B树题仅作条件备用", family="单选·BST删除", novelty="条件辨析", minutes=2, time_reason="性质判断，不做整树重画", rubric=[["唯一正确选项：左最大或右最小并移除原结点",3]], title="BST双孩子结点的替代键", task="互异键BST中删除同时有左右孩子的结点，要求保留BST性质。选择可放到该位置的替代键及随后必须做的操作。", data="键互异；树非空；被删结点有两个孩子。", answer_blueprint="可取左子树最大（中序前驱）或右子树最小（中序后继）替换，再删除该前驱/后继原结点；不能任取直接孩子。", source_ids="", history_ids="408-2018-8", mode="原创", scope="核心；原B树题转入条件备用，需核2027范围", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-08/deck.yaml"], exposure_response="BST删除算法在课件中，作为边界选择题；B树原题待官方范围确认后仅在备用表启用。", revision_note="落实范围保守处理：不把B树已经纳入2027官方考纲写进主卷。")

# 第三套：综合应用。让中间证据与最终结论都可评分，避免一题要求重画多棵大树。
add("S3-III01", objective="在三对角矩阵压缩表中双向换算下标并识别结构性零", evidence="n=6共16项；0基A[4,3]→k=11，k=15→A[5,5]；|i−j|>1不占位", misconception="把带外零也存入或把边界行按三项计", transfer="用逆向定位检验是否真正理解压缩布局，而非只背正向公式", family="综合·矩阵压缩", novelty="逆向推断", minutes=10, time_reason="一个总数、两个映射和一项边界解释，少于原三元组完整转置", rubric=[["行主序总存储项16及边界行理由",2],["正向k=2i+j并求A[4,3]索引11",3],["逆向k=15对应A[5,5]",3],["带外元素不存与合法条件",2]], title="三对角矩阵压缩的正反定位", task="6×6三对角矩阵仅存满足|i−j|≤1的项，按行从上到下、行内从左到右紧凑存入0基数组B。求B长度、A[4,3]的位置、B[15]来自A的哪个位置，并解释A[0,2]是否占B槽。", data="n=6，i、j、B下标均0基。", answer_blueprint="各行项数2,3,3,3,3,2，总16；带内k=2i+j，A[4,3]→B[11]；B[15]=A[5,5]；A[0,2]是结构性零，不单独存储。", source_ids="", history_ids="真题-2024-填空4", mode="原创", scope="核心；快速转置原题移至范围待核备用", exposure_refs=["知识笔记/重邮数据结构.md"], exposure_response="知识笔记只能证明教学范围，不能证明学生已见；对照已发专业课与官方年度范围后再定卷。", revision_note="替换原需逐项求rowStart与有序转置的过载题；快速转置保留为范围条件备用，不声称官方已确认。")
add("S3-III02", objective="从一次AVL失衡判断旋转类型并核对查找路径变化", evidence="插入22后30为首个失衡结点，LR双旋，终树根25；BST查22四次、AVL查22三次", misconception="只看新结点22在左侧就用LL，或把AVL旋转当成改变中序序列", transfer="由真题整树构造改为局部失衡定位与搜索代价比较", family="综合·AVL", novelty="目标变化", minutes=11, time_reason="一棵6结点树、一次插入、两条搜索路径，比双树8键全构造可控", rubric=[["指出首个失衡结点30及LR",2],["两次旋转后的正确树形",4],["普通BST与AVL查22路径各一条",2],["比较次数4与3并说明中序不变",2]], title="一次插入后的AVL旋转与搜索路径", task="互异键按30,20,40,10,25,22依次插入。画插入22前的普通BST，指出导致不平衡的最低祖先与旋转类型，画平衡后的AVL；比较在未平衡BST与AVL中查22经过的结点。", data="插入次序30,20,40,10,25,22；空树高0，单结点高1。", answer_blueprint="未平衡BST根30，左20(左10,右25(左22))，右40。30首个失衡且左子树右高，做LR：先20左旋、再30右旋，得根25，左20(10,22)，右30(空,40)。查22路径BST为30→20→25→22，共4；AVL为25→20→22，共3。", source_ids="真题-2026-综合18", mode="改编", exposure_status="待录课件同题", exposure_refs=["课件/C2/C2-B-pro/C2-B-08/deck.yaml"], exposure_response="AVL基础可能在B08待录材料中；本题不用2026原8键/原ASL表，成稿前核实是否已发同一6键实例。", revision_note="原题同时求BST/ASL/AVL八键整树，10分作答过载；改为可证明的旋转与搜索比较。")
add("S3-III03", objective="用Huffman合并权核算平均码长，并同等长方案比较", evidence="合并总成本2.61；八字符等长3 bit/字符；说明左右分支互换不影响码长", misconception="把概率WPL当总位数，或认为编码0/1左右交换后就不唯一正确", transfer="来源题任务本身适合作为高权重基础锚点，不假称创新", family="综合·Huffman", novelty="基础锚点", minutes=11, time_reason="八个概率合并7次，不强制逐一列出任意0/1码字", rubric=[["正确列七次合并权或等价树",4],["加权平均码长2.61",3],["等长3及差额0.39",2],["等价编码允许与码长口径",1]], task="八字符概率依次为0.07,0.19,0.02,0.06,0.32,0.03,0.21,0.10。按Huffman法列合并权并算平均码长，与统一3位定长码比较。无需写出每个字符的具体0/1码字。", answer_blueprint="按两最小合并，概率权归一化后合并权总和2.61，对比定长3 bit/字符，平均节省0.39 bit/字符；同权交换或左右0/1交换得等价最优树。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-05/deck.yaml"], exposure_response="Huffman构造已在课件讲法中，但本题用于综合过程核算；若同数据被发过则换独立概率并复算。", revision_note="不要求固定唯一编码表，减少非必要书写负担。")
add("S3-III04", objective="用相邻不可比较的顶点识别拓扑序非唯一，并最少补边固定顺序", evidence="可给AB C D E F G与AC B D F E G两条序；加B→C仅消去前一处分歧，另加E→F（或反向）总2条", misconception="加一条边就以为全序唯一；任意加边不检查是否成环", transfer="从生成一个拓扑序迁移到判断唯一性和构造最小约束", family="综合·拓扑序", novelty="逆向推断", minutes=11, time_reason="七点八边；仅要两条见证和两条边，不枚举全部四种", rubric=[["写两条不同合法拓扑序",2],["说明B/C与E/F各一处分歧",2],["只加B→C仍不唯一",2],["给两条使唯一的边并证明无环",4]], task="DAG边A→B,A→C,B→D,C→D,D→E,D→F,E→G,F→G。给出两条不同拓扑序；判断只加B→C是否唯一；若要求保持无环，至少再加几条边可使拓扑序唯一，给出一组边和理由。", answer_blueprint="两处分歧分别是B/C和E/F，共可取4种序。加B→C后仍可互换E/F；再加E→F或F→E，合计补2边即可得到唯一序，新边均顺原偏序方向，不成环。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-06/deck.yaml"], exposure_response="Kahn模板与拓扑验证已有课件；唯一性与加约束是实质新任务，仍需核具体图是否在题集中出现。", revision_note="删去列全体拓扑序数量计算要求，留下能区分理解的两处证据。")
add("S3-III05", objective="用交换边构造不同MST，并辨析相同边权与多解的逻辑关系", evidence="最优权7；AB+AC+BD+DE与AB+BC+CD+DE等均为权7；等权本身非充分条件", misconception="看到相同权边就断言所有MST不唯一", transfer="从Kruskal单次运行转为替代最优解与反例构造", family="综合·MST", novelty="条件辨析", minutes=11, time_reason="五点七边可手算，另需一个短反例", rubric=[["一棵合法MST及权7",3],["第二棵不同合法MST及同权",3],["说明为何不能更轻",2],["给等权仍唯一的树图反例",2]], answer_blueprint="任取三角ABC中的两条权1边、BD或CD权2边、DE权3边，最小总权2+2+3=7；至少两种组合得不同MST。若原图本身是一棵树且两条边等权，MST仍唯一，故等权不充分。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-07/deck.yaml"], exposure_response="MST标准过程已教；本题多解见证与逻辑反例才是新增证据。")
add("S3-III06", objective="在重复键数组中用半开区间搜索推得相等区间", evidence="对4得lower=1,upper=4；对9得lower=5,upper=7；相等区间为[lower,upper)", misconception="普通二分找到任一4就当首4；upper_bound用≥与>条件混淆", transfer="从普通二分查找到边界定位的目标变化", family="综合·折半边界", novelty="目标变化", minutes=12, time_reason="两个键各两次边界搜索，提供伪码骨架降低纯写码负担", rubric=[["正确写lower/upper分支条件",4],["4的区间[1,4)",2],["9的区间[5,7)",2],["空结果与半开区间解释",2]], task="0基有序数组(2,4,4,4,7,9,9,12)，给出半开区间[left,right)的二分伪码骨架。补lower_bound首个≥x、upper_bound首个>x的比较条件；给x=4和x=9的返回下标与相等区间。", answer_blueprint="lower的a[mid]<x时left=mid+1，否则right=mid；upper的a[mid]≤x时left=mid+1，否则right=mid。x=4得(1,4)即[1,4)，x=9得(5,7)即[5,7)；不存在时两个界相同。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-08/deck.yaml", "课件/C2/C2-B-pro/C2-B-09/deck.yaml"], exposure_response="普通折半已在课件中；边界搜索为新增目标。核实际是否讲过lower/upper同数据。", revision_note="把原抽象lower/upper题锁定为短伪码补条件与两个可核例子，避免学生凭库名作答。")
add("S3-III07", objective="在Shell不同增量的分组移动中跟踪相等键身份", evidence="原八项增量4首趟(8a,2,6,1,8b,3,7,4)；四项反例(2a,3,1,2b)经2后(1,2b,2a,3)使不稳定", misconception="组内严格大于才移动就以为Shell整体稳定", transfer="从趟次手算迁移到构造稳定性反例", family="综合·Shell排序", novelty="错解诊断", minutes=11, time_reason="仅算一趟八项与一个四项反例，删去三趟全表", rubric=[["八项首趟正确分组/结果",3],["四项反例增量2及1后顺序",3],["指出相等键2b越过2a",2],["解释组内稳定不推出跨组稳定",2]], task="八记录(8a,3,7,1,8b,2,6,4)按增量4做一趟Shell分组直接插入（只有严格大于才移动），写结果。再用(2a,3,1,2b)按增量2、1两趟，判断Shell是否稳定并解释。", answer_blueprint="八项第一趟(8a,2,6,1,8b,3,7,4)。四项增量2后为(1,2b,2a,3)，最终仍是(1,2b,2a,3)，原2a/2b次序倒置；即使各组内插入稳定，跨组仍不稳定。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-10/deck.yaml"], exposure_response="若课堂已完整演示该反例，换新的四项等价反例并仍标错解诊断。", revision_note="旧案要求八项写三趟又做反例，10分负担过高；只保留一趟与机制反例。")

# 第三套：算法题。新增限制/证据必须确实改变解法，而非换输入。
add("S3-IV01", objective="用三次区间逆置完成相邻两段原地轮换并证明内部次序保持", evidence="对A=(1,2)、B=(3,4,5)，reverse(A),reverse(B),reverse(all)得(3,4,5,1,2)；解释仅reverse(all)错误", misconception="整体逆置一次即可交换两段且保持段内顺序", transfer="原相邻段互换题改为错误方案诊断与不变量证明，操作骨架仍来自原题", family="算法·顺序表", novelty="错解诊断", minutes=10, time_reason="给reverse接口，学生只设计三次调用与证明，不重写逆置函数", rubric=[["三次reverse的正确区间/调用次序",4],["样例结果与m=0或n=0边界",2],["证明两段内部次序各逆两次",1],["时间O(m+n)、空间O(1)",1]], title="相邻两段轮换的错误方案修正", task="顺序表连续区间[A|B]，A长m、B长n，m或n可为0。已有reverse(a,l,r)原地逆置闭区间且空区间不操作。有人只调用reverse整个区间，声称得到[B|A]且段内顺序不变。指出反例，给不申请新数组的修正调用序列、证明和复杂度。", data="例A=(1,2)、B=(3,4,5)；0基数组长度m+n。", answer_blueprint="只reverse全段得到(5,4,3,2,1)，不是目标。依次reverse[0,m−1]、reverse[m,m+n−1]、reverse[0,m+n−1]，得(3,4,5,1,2)；每段元素先后被逆两次，内部顺序恢复；任一段空按空区间约定仍成立。O(m+n)时间、O(1)额外空间。", mode="改编", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-01/deck.yaml", "课件/C2/C2-B-pro/C2-B-02/deck.yaml"], exposure_response="若相邻段交换原题已在实际作业出现，本题仅按错解诊断训练；成稿前查已发课件和机构押题册，必要时调整情境。", revision_note="直接原题转成方案评价，reverse接口已给以控制8分作答量。")
add("S3-IV02", objective="在线性树遍历中同时追踪路径与是否经过标记结点，求合格最长根叶路径", evidence="DFS携带seenMark=seenMark∨mark(node)；仅叶子且seenMark真才比较长度，等长保持先到的左路径", misconception="先找普通最长路径再检查是否标记；它不合格时会漏掉次长合格路径", transfer="2025最长根叶路径的实质约束变化，需把资格状态带入递归", family="算法·树路径", novelty="约束变化", minutes=14, time_reason="一处布尔状态加原有路径数组/栈，给结点结构以免抄模板占时", rubric=[["思想中明确只有合格叶路径参与最大值比较",2],["递归携带并更新seenMark",2],["正确维护当前路径/最优路径及左优先平局",3],["空树或无合格叶返回无解",1],["时间O(n)、辅助空间O(h)及输出路径占用",2]], title="经过标记结点的最长根叶路径", task="二叉树结点含data、left、right及mark布尔域。输出一条从根到叶、且沿途至少经过一个mark=true结点的最长路径，长度按结点数；等长选先在左优先DFS中遇到的路径；若不存在返回无解。写思想、关键伪码与复杂度。", data="结点结构已给；可沿递归栈临时保存当前路径；不得对每个叶重新从根查标记。", answer_blueprint="DFS(node,seen,len,path)进入时令seen∨=node.mark并记录node；到叶时仅seen=true才与bestLen比较，严格大于才复制/记录最优路径以保持左优先。先左后右；无合格叶返回无解。O(n)时间、递归及当前路径O(h)，若复制最优路径只在更新时发生可能累计超O(n)，可先求最优长度再做一次左优先路径重建以保证总O(n)、O(h)辅助与O(h)输出。", mode="改编", exposure_status="待录课件同题", exposure_refs=["课件/C2/C2-B-pro/C2-B-05/deck.yaml", "课程设计/C3课程内容设计.md"], exposure_response="普通最长路径已在B05待录方案中，标记约束迫使改变递归状态；实际录课/作业若已有同约束则再改。", revision_note="为确保O(n)，标准答案建议两遍DFS：第一遍求合格最大长度，第二遍左优先构建首条目标路径；不可用每次破纪录全路径复制却宣称O(n)。")
add("S3-IV03", objective="用容量k的最小堆归并k条升序链表，并落实稳定并列顺序", evidence="堆中始终只放每条非空链表当前头；比较(key,listIndex)，弹出后补入该链后继；O(k+N log(k+1))", misconception="将所有N个结点入堆占O(N)空间，或仅按key比较使跨链相等键顺序不确定", transfer="从普通两表归并转为k路候选维护与稳定性约束；源自题集06算45独立任务", family="算法·堆归并", novelty="约束变化", minutes=18, time_reason="给堆接口与结点结构，12分用于不变量、指针重连、平局和复杂度", rubric=[["思想：每链只放当前头且弹出后补该链后继",2],["按(key,listIndex)的稳定比较和初始化",2],["正确重接结果链并处理空链/重复键",4],["不变量/正确性解释",2],["时间O(k+N log(k+1))、空间O(k)",2]], title="给定堆接口的k路稳定链表归并", task="有k条按key非递减排序的单链表L[0..k−1]，各链可为空；总N个结点。复用原结点形成一条非递减链表，相等key时先输出编号更小的链表中的结点；同链内部原次序保持。已提供minHeap.push(item)、pop()，堆比较可用(key,listIndex)；不需实现堆。写思想、关键伪码、正确性理由与时空复杂度。", data="每个堆项含当前Node*和链表编号；结果可用dummy头结点，结束时尾指针next=NULL；不新建数据结点。", answer_blueprint="初始化将所有非空链表首结点各入堆。反复弹最小(key,listIndex)的当前头，先保存该结点next，接到结果尾并断开其旧next，再把同一链的新头（若有）入堆。堆至多k项；相同key按链号出，同链只有当前头在堆且天然保序。时间O(k+N log(k+1))，堆O(k)，结果复用N结点。", source_ids="题集-06-算45", history_ids="真题-2024-阅读3", mode="改编", chapter="排序", tags="小根堆；k路归并；有序链表；稳定性；指针重连", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-10/deck.yaml", "课件/C2/C2-B-pro/C2-B-02/deck.yaml"], exposure_response="课堂可能分别讲过堆与两链归并，本题要求合成k路并保持跨链稳定。只读取题集06算45独立任务，避开字段串入46题。", revision_note="替换原2024长度k路径直接重印；打破六套固定线性8树10图12。需核题集-06-算45的字段截取并由教师独立验算。")

# 第四套：阅读侧集中于边界、所有权与代码修正。
add("S4-I01", objective="从函数参数n的含义定位递归数组越界", evidence="若处理前n项，新项是a[n−1]；例最小值16、比较5次、栈Θ(n)", misconception="把长度n直接当作最后合法下标", transfer="从2026存疑阅读代码重写为唯一有效的前缀接口与错误定位", family="程序阅读·递归边界", novelty="错解诊断", minutes=5, time_reason="定位一处越界并算六项最小值", rubric=[["定位a[n]越界并改a[n−1]",2],["返回最小值16",1],["比较次数5及递归栈Θ(n)",2]], title="前缀最小值中的最后下标", task="函数minPrefix(a,n)定义为返回a[0..n−1]的最小值，n≥1。代码基例n=1返回a[0]，递归步把minPrefix(a,n−1)与a[n]比较。指出并修正错误；对a=(23,33,16,79,34,29)求返回值、关键比较次数和最大递归深度。", data="数组0基；n=6；不讨论n=0调用。", answer_blueprint="递归步应比较a[n−1]；结果16；n=6时递归步比较5次，最大同时在栈6层，辅助栈Θ(n)。", exposure_status="待核实", exposure_refs=["题库数据库/导出/真题2026.md", "课件/C2/C2-A-01/deck.yaml"], exposure_response="2026原阅读有两版和越界风险，本题明确采用重写接口；核已发课件是否含相同代码。", revision_note="不把回忆版错误代码作为无条件的标准程序阅读题。")
add("S4-I02", objective="读懂交集归并中的结点归属，保持B表不变", evidence="A=(1,3,5,7)、B=(3,4,7)后A复用3与7结点，B仍(3,4,7)；淘汰A结点要释放并断尾", misconception="为求交集顺手摘走/释放B结点，或忘记把新A尾next置空", transfer="原交集骨架加入单表所有权限制，需要改变推进与释放操作", family="程序阅读·链表所有权", novelty="约束变化", minutes=6, time_reason="三处指针/释放空及一组小数据", rubric=[["B只读推进且最终不变",1],["A保留/淘汰结点操作正确",2],["结果3,7及尾链断开",2]], task="两条互不共享结点、带头结点且严格递增的集合单链表A=(1,3,5,7)、B=(3,4,7)。短代码用双指针求交集并复用A的保留结点，删除A其余结点；B及其头结点必须不变。补关键推进和断链语句，写最终A/B。", data="A与B不共享结点；A中删除结点应释放；B全程只读。", answer_blueprint="比较相等时把A当前结点接到结果尾并同时推进A/B；A较小时保存其后继后释放A结点；B较小时仅推进B。结束后释放A剩余结点并令结果尾next=NULL。最终A=(3,7)，B=(3,4,7)。", exposure_status="待录课件同题", exposure_refs=["课件/C2/C2-B-pro/C2-B-02/deck.yaml"], exposure_response="C2-B02有链表交/并相关方法，约束为B不变；实际学生是否拿到需核。", revision_note="必须在成稿给出短代码与内存所有权约定；不能把‘保留B’只当文字装饰。")
add("S4-I03", objective="按count而非front==rear判定计数型环形队列的满与空", evidence="最终front=rear=2、count=4且逻辑队列3,4,5,6", misconception="front==rear必为空，因而错误拒绝第4个元素", transfer="从牺牲一个空槽的循环队列改为count判满，容量语义改变", family="程序阅读·循环队列", novelty="表示转换", minutes=5, time_reason="八个短操作中只写最终状态和两处count更新", rubric=[["入队/出队count增减两空",2],["最终front=rear=2,count=4",2],["逻辑队列3,4,5,6且为满",1]], task="容量4的循环队列用front指首元素、rear指下一写入位、count区分满空；入队先写后rear循环加1，出队先读后front循环加1。补两处count更新；从空队依次入1,2,3,4，出两次，再入5,6，写最终状态。", answer_blueprint="入队count++、出队count--；最终front=2,rear=2,count=4，队列从front起为3,4,5,6，是满队；front==rear此时不表示空。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-A-05/deck.yaml", "课件/C2/C2-B-pro/C2-B-03/deck.yaml"], exposure_response="课件若主要用空一格判满，这里按count表示转换；已讲count接口则退为平行练习。")
add("S4-I04", objective="用单孩子树反例诊断叶子判定条件", evidence="只有左右孩子都空才是叶；五结点A(B(D,E),C)有3叶；空0、单结点1", misconception="把只有一个孩子的结点也当叶，使用or而非and", transfer="由2024原函数功能直接问答改为逻辑条件调试", family="程序阅读·树递归", novelty="错解诊断", minutes=5, time_reason="一处布尔条件与三个小样例", rubric=[["指出or错误并改and",2],["空树0与单结点1",1],["五结点树3并说明B非叶",2]], title="叶结点计数的单孩子陷阱", task="给递归leafCount(T)的短代码：空树返回0；非空时若`T->left==NULL || T->right==NULL`就返回1，否则递归求和。指出该条件的问题并修正；给空树、单结点树及A(B(D,E),C)的结果。", data="A左右孩子B/C，B左右孩子D/E，C/D/E均无孩子。", answer_blueprint="叶子条件须左右孩子都NULL，用&&；空0、单结点1、给定树叶为D/E/C共3。原||会把单孩子结点错误计为叶。", mode="改编", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-04/deck.yaml", "课件/C2/C2-B-pro/C2-B-05/deck.yaml"], exposure_response="叶数递归可能已教，本题仅将错误定位作为增量；如果原课件已有同一bug示例则换错误。")

# 第四套：单选维持基本面，错因明确；不让每题都装作原创。
add("S4-II01", objective="区分两次子调用的总工作量与一条调用链的最大深度", evidence="T(n)=2T(n/2)+Θ(1)为Θ(n)，栈Θ(log n)", misconception="把两分支的空间也乘到n，或把总时间误作log n", transfer="时间树与最大栈链分开分析", family="单选·递归复杂度", novelty="条件辨析", minutes=2, time_reason="一个递归树结论", rubric=[["唯一正确选项：时间Θ(n)、栈Θ(log n)",3]], answer_blueprint="满二叉递归树约n叶、O(n)结点；同一时刻调用深度log₂n+1。", revision_note="选项应含时间/空间配对，而非只问单一复杂度。")
add("S4-II02", objective="按邻接双链的四条局部连接正确删除p", evidence="p->prior->next=p->next及p->next->prior=p->prior；单结点/哨兵约定明确", misconception="只改一侧next而遗留prior悬挂", transfer="基础指针锚点；不包装为新变式", family="单选·双链表", novelty="基础锚点", minutes=2, time_reason="核两条对称重连语句", rubric=[["唯一正确选项：前驱next接后继且后继prior接前驱",3]], task="双向循环链表有哨兵头结点，p是非头的待删结点。选择在free(p)前应执行的两条重连语句；即使p是唯一数据结点也须正确。", answer_blueprint="p->prior->next=p->next；p->next->prior=p->prior；保存必要指针后free(p)。由于有哨兵，两式在唯一数据结点时仍成立。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-02/deck.yaml"], exposure_response="保留指针基础分，若408原题已布置则仍标基础锚点。")
add("S4-II03", objective="从给定出栈序列求执行中峰值栈容量", evidence="输出3前必须同时压1,2,3，峰值3；其余步骤可容量3完成", misconception="把最大输出数字5当容量，或只核最终栈长度", transfer="从合法性判断转为最小资源估算", family="单选·栈容量", novelty="目标变化", minutes=3, time_reason="一次5元素模拟", rubric=[["唯一正确选项：3",3]], answer_blueprint="为先弹3必须暂存1、2、3，容量至少3；弹3、2后推4再弹4，弹1，最后推5弹5，容量3足够。")
add("S4-II04", objective="把next预处理和文本扫描合并计入完整KMP复杂度", evidence="构造nextΘ(m)，扫描Θ(n)，总Θ(n+m)；已给next仅扫描Θ(n)", misconception="只记匹配扫描或把失配退跳误算成Θ(nm)", transfer="从算法单步过程转为接口层总成本", family="单选·KMP复杂度", novelty="条件辨析", minutes=2, time_reason="两项相加", rubric=[["唯一正确选项：含建表Θ(n+m)，已给表扫描Θ(n)",3]], answer_blueprint="标准KMP预处理模式Θ(m)、主串扫描Θ(n)，两者合Θ(n+m)；表已给则主扫描Θ(n)。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-03/deck.yaml"], exposure_response="若课堂已完整讲过，作为复杂度锚点。")
add("S4-II05", objective="按广义表Head/Tail返回类型逐层展开", evidence="Tail(L)=((c,d))，Head得(c,d)，再Head得原子c", misconception="把Tail视为删除元素后的原子，或混淆(c,d)与c", transfer="基础嵌套运算锚点", family="单选·广义表", novelty="基础锚点", minutes=3, time_reason="三次嵌套求值", rubric=[["唯一正确选项：原子c",3]], answer_blueprint="L=((a,b),(c,d))；Tail(L)=((c,d))，Head(Tail(L))=(c,d)，再Head得c（原子）。", exposure_refs=["知识笔记/重邮数据结构.md"], exposure_response="笔记不是学生见题证明；成稿前查课程/题集同题。")
add("S4-II06", objective="用最小树说明先序与后序不能区分单孩子方向", evidence="A根B可为左孩子或右孩子，共2形态，均先序AB后序BA", misconception="把先序加后序误作唯一构树", transfer="由构树任务逆向推断信息缺口", family="单选·遍历序列", novelty="逆向推断", minutes=2, time_reason="两结点反例即够", rubric=[["唯一正确选项：可有2种左右形态，不唯一",3]], answer_blueprint="A为根、B为其左孩子或右孩子，两树均先序AB后序BA；两遍历不能确定唯一二叉树。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-A-07/deck.yaml", "课件/C2/C2-B-pro/C2-B-05/deck.yaml"], exposure_response="先/中重建已在课件中；本题检验先/后信息不足，不把一般构树当新题。")
add("S4-II07", objective="以有向环构造n顶点强连通图的最少弧数", evidence="n≥2时各点至少出度1，总弧≥n；一个有向n环达到", misconception="把至少n+1写为答案或误把无向树n−1套用", transfer="原2026填空改为选择题，非实质迁移", family="单选·强连通", novelty="基础锚点", minutes=2, time_reason="一条下界加构造", rubric=[["唯一正确选项：n及有向n环",3]], answer_blueprint="每顶点至少一条出弧，故至少n弧；有向n环强连通且恰n弧。", exposure_status="待核实", exposure_refs=["题库数据库/导出/真题2026.md", "课件/C2/C2-A-09/deck.yaml"], exposure_response="这是2026原题的题型转换，不计原创；若近年原题已发给学生，仍只作基础锚点。", revision_note="保留勘误：原配套答案n+1错误，标准答案必须n。")
add("S4-II08", objective="用折半判定树高度估计600项有序表最坏比较次数", evidence="2^9−1=511<600≤1023=2^10−1，最坏10次", misconception="取⌊log₂600⌋=9而漏掉末层", transfer="基础锚点", family="单选·折半查找", novelty="基础锚点", minutes=2, time_reason="比较两档完全树容量", rubric=[["唯一正确选项：10次",3]], answer_blueprint="9层最多容纳511项，600项需第10层；每轮一次三路关键字比较，最坏成功比较10次。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-08/deck.yaml"], exposure_response="已讲折半判定树时只作短基础题。")
add("S4-II09", objective="判断稳定归并在左右当前键相等时的取数规则", evidence="相等时先取左段，保持原输入中左记录在右记录前", misconception="稳定排序只要求每段内部稳定，归并时可任意先取右", transfer="从手算归并转为稳定实现条件", family="单选·稳定归并", novelty="条件辨析", minutes=2, time_reason="一次同键对照", rubric=[["唯一正确选项：相等先取左",3]], answer_blueprint="左右段来自同一原序列的相邻区间；等键先取左元素，才能保持跨段原次序。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-10/deck.yaml"], exposure_response="如课件已讲同条件，则保留作概念锚点，不称原创。")
add("S4-II10", objective="按AVL最低结点递推算高度5的边界", evidence="N0=0,N1=1,N2=2,N3=4,N4=7,N5=12", misconception="误当满二叉树31结点或把高度基例偏一", transfer="基础性质与递推，不以换高度计创新", family="单选·AVL性质", novelty="基础锚点", minutes=3, time_reason="需写五步递推防基例错", rubric=[["唯一正确选项：12",3]], answer_blueprint="N(h)=1+N(h−1)+N(h−2)，N0=0、N1=1；依次2、4、7、12。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-08/deck.yaml"], exposure_response="若同高度课堂例题已给则换高度；仍按基础性质题标。")

# 第四套：综合应用用可复算的中间状态区分会算与会解释。
add("S4-III01", objective="在已给next与nextval定义下跟踪连续相等前缀的失配退跳", evidence="P=aaaab时next=(0,1,2,3,4)、nextval=(0,0,0,0,4)；T=aaaacaaaab首次匹配1基起点6；比较数14与11", misconception="以为nextval对任何文本都必降低比较次数，或把j=0推进算作字符比较", transfer="从求一张next表转为解释nextval消除无效重复比较的条件", family="综合·KMP运行", novelty="条件辨析", minutes=12, time_reason="仅一对短串，两张表与关键比较数；删去旧案第二条长文本全程手算", rubric=[["next表与1基约定",2],["nextval表",2],["首次匹配起点6",2],["两法比较数14与11且关键退跳可核",2],["说明nextval的收益有条件，j=0不计字符比较",2]], task="使用1基KMP约定：next[1]=0；失配时主串i不退，j按next[j]跳；nextval在即将比较相同模式字符时继续压缩退跳；j=0推进不算字符比较。对P=aaaab、T=aaaacaaaab，写next与nextval，给首次匹配起点和两法字符比较次数，并说明优化为何来自连续a的退跳。", data="P=aaaab，T=aaaacaaaab；字符比较指实际执行T[i]与P[j]的比较。", answer_blueprint="next=(0,1,2,3,4)，nextval=(0,0,0,0,4)；首次匹配从主串1基位置6开始；按约定普通next比较14次，nextval比较11次。主串第5位c对连续a失配时，nextval跳过重复a比较。优化不保证对所有文本严格少。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-A-06/deck.yaml", "课件/C2/C2-B-pro/C2-B-03/deck.yaml"], exposure_response="next构造已属课堂能力，给比较轨迹是新证据；若该P/T已作为已发作业，换串后重算，不以新数据冒称新任务。", revision_note="原题两文本、多张表与两轮比较数同时要求，10分过载；聚焦一个失配场景。需按成稿所给的精确伪码独立重算比较次数。")
add("S4-III02", objective="维护开放定址删除后的探测链并安全复用墓碑", evidence="m7插10,17,24,5后下标3,4,5,6；删17令4=DELETED，查24仍在5成功；插31复用4", misconception="把删除槽改EMPTY使后续查找提前失败；见墓碑就直接插入而不查重复键", transfer="从静态ASL手算转为删除与再插入的状态维护", family="综合·散列删除", novelty="约束变化", minutes=10, time_reason="表长7、四键和一删一插，状态表很短", rubric=[["初始四键位置3,4,5,6",2],["删除17后4为DELETED",2],["查24经过3,4,5并解释不能置EMPTY",3],["插31复用4且须确认键不存在",3]], task="长度7的散列表用H(k)=k mod 7和线性探测，槽有EMPTY/OCCUPIED/DELETED三态。依次插10,17,24,5；删17；追踪查24并说明若把被删槽写EMPTY会怎样；确认31原不存在后插入，给最终表。", data="表初始全EMPTY；查找遇DELETED继续探测，遇EMPTY停止；插入可记首个DELETED但要继续查重。", answer_blueprint="初始10在3、17在4、24在5、5在6；删17后4是DELETED。查24探测3(10)、4(墓碑)、5(24)成功；若4为EMPTY则误报不存在。31哈希3，确认不存在后复用4，最终3:10,4:31,5:24,6:5。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-08/deck.yaml"], exposure_response="线性探测已教，删除与墓碑维护是增量；若专业课已演示同数据则换键。")
add("S4-III03", objective="通过真实中序相邻关系修复错误线索", evidence="中序D,B,E,A,F,C,G；E右线索应指A且rtag=1", misconception="把叶E的后继误写成右子树C，或把线索当真实右孩子递归", transfer="由正常线索遍历转为线索表审计与纠错", family="综合·中序线索树", novelty="错解诊断", minutes=10, time_reason="七结点全树与一个错误表项，遍历序列可一次核", rubric=[["给出正确中序序列",3],["指出E的中序后继A",2],["修正E.rtag=1与rchild=A",2],["区分tag=0孩子/tag=1线索并能沿线索遍历",3]], task="树A(B(D,E),C(F,G))中，D/E/F/G均为叶。给出其中序线索表，除E的右线索被写成C外其余均正确。写中序序列，指出唯一错误并修正E的rtag和rchild，说明遍历时tag=1的处理。", data="真实孩子：A→(B,C)，B→(D,E)，C→(F,G)；空孩子才能挂线索；E无右孩子。", answer_blueprint="中序D,B,E,A,F,C,G；E的后继是A，因此E.rtag=1、E.rchild=A，而非C。tag=1沿后继线索，不把它当子树入口递归。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-A-07/deck.yaml", "课件/C2/C2-B-pro/C2-B-04/deck.yaml"], exposure_response="若课程仅讲线索概念，本题是表项审计；若已发同图同错则更换错误表项。")
add("S4-III04", objective="理解Floyd矩阵每轮允许的中转顶点范围及负边前提", evidence="允许0、1作中转后第0行(0,4,2,10)；最终第0行(0,4,2,5)，路径0→1→2→3；标准Dijkstra不适用负边", misconception="把第k轮理解为最多k条边；用Dijkstra直接处理负权边", transfer="从全矩阵填表转为阶段证据和方法选用", family="综合·最短路径", novelty="条件辨析", minutes=11, time_reason="只求两行和一条路径，避免抄两张4×4表", rubric=[["允许0、1后的第0行",3],["最终第0行及0→3长度5",3],["0→1→2→3路径",2],["负边不满足标准Dijkstra前提且Floyd合法",2]], task="有向网顶点0..3，边0→1(4)、0→2(9)、1→2(−2)、1→3(6)、2→3(3)、3→1(2)，其余无边。Floyd按0,1,2,3允许中转。只写允许0、1作中转后的第0行及最终第0行，给0到3一条最短路径，并判断标准Dijkstra能否直接用于原图。", data="无负环；初始矩阵对角0，无边∞；有限距离才可相加。", answer_blueprint="允许中转0、1后第0行(0,4,2,10)；最终第0行(0,4,2,5)；0→3路径0→1→2→3，权和4−2+3=5。Floyd可处理此无负环图，标准Dijkstra不满足非负权前提。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-07/deck.yaml"], exposure_response="最短路方法已教；负边与阶段解释属于条件判断，避免重做2024原全矩阵。", revision_note="原设计要求两张完整4×4矩阵，10分/11分钟负担过重；改为指定行和决策理由。")
add("S4-III05", objective="用多条并列关键路径判断单活动缩短是否改变总工期", evidence="原0→1→3→5与0→2→4→5均8；0→1由3缩2后前者7、后者8，总工期仍8", misconception="任一关键活动缩短1就把工期减1", transfer="从静态ve/vl手算转为变更后的关键路径重判", family="综合·AOE", novelty="约束变化", minutes=10, time_reason="六事件七活动，主要算两条最长链而非全ve/vl表", rubric=[["指出原两条关键路径及各长8",4],["修改后两条路径长度7与8",3],["工期仍8并解释并列瓶颈",3]], task="单源单汇AOE活动为0→1(3),0→2(2),1→3(3),2→4(4),3→5(2),4→5(2),1→4(1)。求原工期与关键路径；若仅把0→1工时由3降到2，新工期是否缩短？写出依据。", data="事件0为源，5为汇；无其他活动；工期取源到汇最长链。", answer_blueprint="原两条关键路径0-1-3-5与0-2-4-5均长8。改0→1为2后前一路长7，后一路仍8，故工期仍8；不能只看被缩短活动原来是否关键。", exposure_status="课件同法", exposure_refs=["知识笔记/重邮数据结构.md"], exposure_response="笔记仅为知识依据，查实际已发专业课；若原图已出现则换图并复算。", revision_note="删除全事件ve/vl与全部活动时差表，10分聚焦决策和过程。")
add("S4-III06", objective="以稳定排序实现部门主键、成绩次键及同分原序", evidence="先成绩降序得ID2,3,5,1,4,6,7；再部门升序得2,5,4,7,3,1,6", misconception="先主键后次键会破坏部门分组；把稳定性只用于同部门", transfer="从一次单关键字排序组合为多关键字约束", family="综合·稳定排序", novelty="约束变化", minutes=11, time_reason="七记录两次序列各7项，仍有解释负担", rubric=[["先次关键字成绩降序、再主关键字部门升序",3],["第一次ID序列正确",2],["最终ID序列正确",3],["相同部门成绩保持输入次序及不稳定风险",2]], task="七条记录依输入次序：1(B,80),2(A,90),3(B,90),4(A,80),5(A,90),6(B,80),7(A,70)。目标部门A先B后，部门内成绩降序，同部门同成绩保留原输入顺序。仅有稳定的单关键字排序函数，给两次排序键与方向、每次后的ID序列，并说明顺序为何不能反过来。", answer_blueprint="先按成绩降序稳定排序，ID为2,3,5,1,4,6,7；再按部门升序稳定排序，ID为2,5,4,7,3,1,6。第二次稳定保留同部门内第一次的成绩顺序及完全相同记录的原序。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-10/deck.yaml"], exposure_response="稳定排序性质已讲，双关键字组合是新增任务；检查专业课是否已有同数据。")
add("S4-III07", objective="辨别一组前缀码合法性与Huffman最优性并用权值核算差距", evidence="给码字A000,B001,C01,D10,E11合法且WPL57；权2,3,3,7,11的Huffman合并5,8,15,26，最优WPL54", misconception="前缀码合法就一定最优，或机械沿用2024答案215", transfer="由原2024按权构树变为审查一个看似正确的编码方案并给改进证据", family="综合·Huffman诊断", novelty="错解诊断", minutes=11, time_reason="五权、四次合并与一组码长，比七权重画全树轻", rubric=[["证明给定码表是前缀码",2],["给定码表WPL=57",2],["Huffman四步合并5,8,15,26",3],["最优WPL=54及差3",2],["指出合法不等于最优",1]], title="有效前缀码是否已经最优", task="字符A..E的权值分别为2,3,3,7,11。方案甲编码为A=000,B=001,C=01,D=10,E=11。判断它是否前缀码并计算WPL；再按Huffman两最小合并给最优WPL，判断甲是否最优。无需给最优树的唯一0/1标号。", data="A:2,B:3,C:3,D:7,E:11；相同权任选其一先合并，等价最优答案均接受。", answer_blueprint="甲无任一码字是另一完整码字的前缀，合法；WPL=2×3+3×3+3×2+7×2+11×2=57。Huffman合并权依次5,8,15,26，WPL=54，甲比最优多3。合法前缀码不保证最优。", source_ids="", history_ids="真题-2024-综合5", mode="原创", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-05/deck.yaml"], exposure_response="2024原Huffman权值及答案已有错，本题另设五权/给码审查，成稿独立核算；课堂若已讲该新权组则更换。", revision_note="替换原样重用2024综合5七权构树；以有效性和最优性分开检验，结果可复核。")

# 第四套：算法设计题仍保持8/10/12分；新增修错/边界状态/证明证据。
add("S4-IV01", objective="修复循环链表报数删除时的尾指针与单结点边界", evidence="删除cur前保存next，若cur==tail则tail=pre；m=1时每轮也能推进；n=5从2起m=1幸存1", misconception="删尾后tail悬挂或按m=1重复free当前结点", transfer="约瑟夫原题的关键操作未变；新增代码审计与所有权边界，不以换参数冒充创新", family="算法·循环链表", novelty="错解诊断", minutes=11, time_reason="给原循环骨架，只改删除段并举两边界，控制8分代码量", rubric=[["思想：pre始终为cur前驱、报数m−1步",2],["删除前保存后继并正确接链/free",2],["删tail时更新tail；n=1不入循环",2],["样例幸存1和O(nm)时间/O(1)辅助",2]], title="循环链表报数的尾指针修复", task="n个结点按1..n围成单向循环链表，tail指向最后结点；给定从编号s的结点cur开始、其前驱pre已经定位，m≥1。给出删除循环骨架，其中`pre->next=cur->next; free(cur); cur=pre->next`，却未处理cur==tail。修复并返回幸存编号；说明n=1和m=1时为何安全，对n=5,s=2,m=1给结果及复杂度。", data="1≤s≤n，n≥1，m≥1；出列结点由算法释放，最后幸存结点由调用者持有并负责释放；报数当前cur算1。", answer_blueprint="维持pre->next=cur，报数时前进m−1步；删除前先存next=cur->next，若cur==tail则tail=pre，再pre->next=next、free(cur)、cur=next、remain--。remain=1时停止，返回cur->id，幸存结点不释放。n=1不删；m=1直接删当前。n=5,s=2,m=1依次删2,3,4,5，幸存1。若逐步数m，O(nm)时间，O(1)额外空间（不计输入链）。", source_ids="真题-2026-算法24", mode="改编", exposure_status="待录课件同题", exposure_refs=["课件/C2/C2-B-pro/C2-B-02/deck.yaml", "课件/C3/C3-B-01/deck.yaml"], exposure_response="B02与旧C3均有约瑟夫相关内容，旧C3未按新方案发放；成稿前核实际录课。若尾指针修复也已讲过则换为其他链表错误诊断。", revision_note="不重印2026幸存者标准算法；给骨架，让8分集中在指针不变量与删除边界。")
add("S4-IV02", objective="在允许重复键仅进右子树的BST中用祖先范围验证整棵树", evidence="递归携带下界包含、上界不包含：左(<key)，右(≥key)；root5/right8/left4是跨祖先违规", misconception="只比较父子可漏跨层违规；用INT_MIN/MAX作哨兵排除合法极值", transfer="由2024严格BST判定改为重复键策略、开闭界与整树约束", family="算法·BST校验", novelty="约束变化", minutes=14, time_reason="给结点定义，主要写区间递归和极值处理，比完整构树轻", rubric=[["思想：传祖先允许区间而非只查父子",2],["左上界严格、右下界包含的递归",4],["用可选界/宽整数处理INT_MIN/MAX及空树",2],["跨祖先反例和O(n)时间/O(h)栈",2]], task="整数键二叉树被定义为BST：对每个结点，左子树所有键严格小于其键，右子树所有键大于或等于其键；同键可在该结点右子树的更深处。键可取INT_MIN或INT_MAX。写校验算法，说明为什么只比较父子不够，并分析复杂度。", data="结点含int key及左右指针；空树视为合法；不得用INT_MIN/INT_MAX充当无穷哨兵而误拒绝端点。", answer_blueprint="递归携带可选区间[lo,hi)；若有lo要求key≥lo，若有hi要求key<hi；左调用上界key，右调用下界key。root5→right8→left4的父子比较均通过，但4低于祖先5，应拒绝。空树真；用是否存在界的标记或更宽类型，允许INT_MIN/MAX。O(n)时间、O(h)栈。", source_ids="真题-2024-算法1", mode="改编", exposure_status="待录课件同题", exposure_refs=["课件/C2/C2-B-pro/C2-B-05/deck.yaml", "课程设计/C3课程内容设计.md"], exposure_response="严格BST判定已在B05方案；重复键策略与区间传递属实质约束变化，核实际课堂是否讲过同规则。", revision_note="比原中序严格递增判定多了重复键的右侧范围，INT极值处理不能靠错误哨兵。")
add("S4-IV03", objective="用BFS层次累计至多2条最短路，区分不可达、唯一与多条", evidence="首到v设dist与ways；再从同层最短前驱到v时ways[v]=min(2,ways[v]+ways[u])；唯一时沿pred回溯", misconception="普通visited首次到达即断言唯一；枚举全部路径或把非最短路计入", transfer="由普通BFS最短距离扩展为最短路唯一性状态与见证输出", family="算法·无权图最短路", novelty="目标变化", minutes=18, time_reason="给图表示/BFS队列接口；12分包含状态更新、输出和证明", rubric=[["思想：BFS层次+截断计数",2],["首次到达设置dist/ways/pred并入队",3],["同最短层再遇到时累加ways并截断2",3],["不可达/唯一/多条三态与唯一路径输出",2],["O(V+E)时间、O(V)空间与正确性依据",2]], task="无向无权简单图G给源s与终点t，返回三态：不可达、恰一条最短路、至少两条最短路。仅在恰一条时输出该路径。可使用邻接表、队列、dist/ways/pred数组；ways只需记录0、1、2（2表示至少2），不枚举全部路径。写思想、关键伪码、正确性理由与复杂度。", data="n个顶点，邻接表；包括s=t，此时长度0的唯一路径[s]；平行边不存在。可用小图A-B,A-C,B-D,C-D,D-E作为多最短路例。", answer_blueprint="初始化dist=-1、ways=0；dist[s]=0,ways[s]=1后BFS。边u-v若v未访问，设dist[v]=dist[u]+1、ways[v]=ways[u]、pred[v]=u并入队；若dist[v]==dist[u]+1，令ways[v]=min(2,ways[v]+ways[u])，ways成为2时pred无需改。全BFS后ways[t]=0/1/2对应三态；为1时pred逆链输出。BFS按距离递增处理，所以到v的最短路都来自前一层，截断2不影响三态。O(V+E)时间、O(V)空间。", exposure_status="课件同法", exposure_refs=["课件/C2/C2-B-pro/C2-B-06/deck.yaml", "课件/C2/C2-B-pro/C2-B-07/deck.yaml"], exposure_response="BFS已教，但路径条数三态是新增状态；核实际课件/作业是否已出现最短路计数。", revision_note="保留原原创高价值任务，并给出s=t、不可达、同层更新的完整答案边界。")

# Fix legacy tags/target levels on rows whose central task changed.
for qid, tags, level in [
    ("S3-I02", "单链表；选择排序；稳定性；记录身份", "中"),
    ("S3-III01", "三对角矩阵；压缩存储；逆向寻址", "中"),
    ("S3-III02", "BST；AVL；LR旋转；查找路径", "中"),
    ("S3-IV02", "二叉树递归；受限根叶路径；状态传递", "辨"),
    ("S3-IV03", "小根堆；k路归并；有序链表；稳定性；指针重连", "辨"),
    ("S4-I01", "递归；数组边界；程序阅读", "中"),
    ("S4-I04", "叶结点；递归；布尔条件纠错", "中"),
    ("S4-III07", "前缀码；译码树；在线译码；截断检测", "中"),
    ("S4-IV01", "循环链表；约瑟夫环；尾指针；内存所有权", "中"),
]:
    patch[qid]["tags"] = tags.split("；")
    patch[qid]["level"] = level

# The counterexample must actually distinguish || from &&. A full tree does not.
patch["S4-I04"].update({
    "task": "给递归leafCount(T)的短代码：空树返回0；非空时若`T->left==NULL || T->right==NULL`就返回1，否则递归求和。指出该条件的问题并修正；给空树、单结点树及四结点树A(左B(C,D),右空)的正确返回值，并指出旧代码在该四结点树上的输出。",
    "data": "A只有左孩子B；B有左右孩子C/D；C/D无孩子。",
    "answer_blueprint": "叶子条件须左右孩子都NULL，用&&。空树0、单结点1、四结点树的真正叶子C/D共2；旧||在A处把它当叶，错误返回1。",
    "evidence_required": "只有左右孩子都空才是叶；四结点单孩子反例A(左B(C,D),右空)正确2、旧代码1",
    "rubric": [["指出or错误并改and",2],["空树0与单结点1",1],["四结点反例正确2、错误程序1并说明原因",2]],
})

# S4-III07 checks decoding and stream completeness; S5 handles Huffman
# optimality, so this paper must test a different operation.
patch["S4-III07"].update({
    "title": "前缀码译码与末尾截断检测",
    "task": "已知前缀码A=000、B=001、C=01、D=10、E=11。画出译码树，说明为何能逐位无歧义译码；对比特流001100001101按读到叶子就输出并回根的规则逐符号译码。若传输中恰好丢失最后1位，指出可完整译出的字符、剩余未完成前缀，并判断截断后的流能否作为完整消息。原流编码5个字符共用多少比特？与5字符定长编码所需位数比较。",
    "data": "字符集只有A、B、C、D、E；消息边界已知；流中无分隔符，码表固定。5字符定长码每字符需3比特。",
    "answer_blueprint": "译码树根的0支接中间结点，00支再分000=A、001=B，01=C；1支分10=D、11=E。五个码字互不为前缀。原流切为001|10|000|11|01，得BDAEC，共12比特；固定长编码需5×3=15比特，少3比特。截断流00110000110切为001|10|000|11|0，完整译出BDAE，末尾0仍在内部结点，不能视为完整消息。",
    "objective": "用译码树逐位处理无分隔比特流，识别末尾截断留下的未完成码字",
    "evidence_required": "原流001|10|000|11|01→BDAEC；删末位后001|10|000|11|0→BDAE+残前缀0；12比特对定长15比特",
    "misconception": "把前缀0误当完整码字，或仅凭已译出四字符就断言整个截断流完整",
    "transfer": "从识别前缀码结构转向无分隔串的在线译码与消息边界检查；无需重构Huffman树或比较最优WPL",
    "task_family": "综合·前缀码译码",
    "novelty_type": "目标变化",
    "time_reason": "五叶译码树与两条短流逐位追踪，11分钟可完成",
    "rubric": [["译码树结构与前缀性质",2],["原流正确切分及BDAEC",3],["截断后BDAE、残0及不完整结论",3],["12比特对15比特，差3",2]],
    "exposure": {"status": "课件同法", "references": ["课件/C2/C2-B-pro/C2-B-05/deck.yaml"], "response": "课件包含编码树方法；是否见过同码表或同串待核。成稿核实后若同题则更换码表和流并重算。"},
    "revision_note": "由重复的Huffman最优性审查改为译码与截断检测，避免与第5套同构；位流已独立复核。",
    "change": "由重复的Huffman最优性审查改为译码与截断检测，避免与第5套同构；位流已独立复核。",
})

# The caller must observe a changed ring tail. Request a complete deletion
# algorithm, not a three-line patch to a supplied loop.
patch["S4-IV01"].update({
    "title": "循环链表报数删除与可见尾指针",
    "task": "n个结点按编号1..n构成单向循环链表。调用者持有尾指针tail，从编号s的结点cur开始报数，其前驱pre已定位；当前cur算1，每报到m就删除该结点，直到只剩一个。请按C式接口`int josephus(Node **tailRef, Node *cur, Node *pre, int n, int m)`写完整报数和删除循环伪码，使调用者通过*tailRef取得更新后的尾指针；返回幸存编号。说明删尾、n=1、m=1的处理，给n=5、s=2、m=1的幸存编号与复杂度。",
    "data": "n≥1，m≥1，1≤s≤n，初始*tailRef=tail。输入满足pre->next=cur；n=1时pre=cur=tail。算法释放每个出列结点，幸存结点保留给调用者释放；单结点环的next指回自己。",
    "answer_blueprint": "局部t=*tailRef，remain=n。while(remain>1){for(j=1;j<m;j++){pre=cur;cur=cur->next;} next=cur->next; if(cur==t)t=pre; pre->next=next; free(cur); cur=next; remain--;} *tailRef=cur; return cur->id。循环不变量pre->next=cur；报数后它仍成立。删尾时t转到其前驱，最终*tailRef指唯一幸存结点，且不释放幸存者。n=1直接跳过；m=1无前进但每轮删除并令cur=next。n=5,s=2,m=1依次删2,3,4,5，幸存1。O(nm)时间，O(1)额外空间。",
    "objective": "写完整循环链表报数算法，并保证尾指针变化能传回调用者",
    "evidence_required": "完整报数m−1步/保存next/删尾改t/接链释放/推进/最终*tailRef=cur；样例删2,3,4,5留1",
    "misconception": "只改变函数的局部tail而使调用者尾指针悬挂；删除后访问cur->next；m=1漏删当前结点",
    "task_family": "算法·循环链表",
    "novelty_type": "错解诊断",
    "time_reason": "需自行写完整报数删除循环并说明外部可见尾指针，11分钟用于约20行伪码及边界解释",
    "rubric": [["循环不变量与报数m−1步",2],["保存后继、正确接链释放及推进的完整循环",3],["删尾更新且最终写回*tailRef",1],["n=1、m=1及样例幸存1",1],["O(nm)/O(1)与幸存者所有权",1]],
    "exposure": {"status": "待录课件同题", "references": ["课件/C2/C2-B-pro/C2-B-02/deck.yaml", "课件/C3/C3-B-01/deck.yaml"], "response": "B02与旧C3均有约瑟夫相关内容；旧版本课件，实际发放待核。若完整尾指针接口算法已讲过，则换链表任务。"},
    "revision_note": "从直接重现幸存者模板改为完整删除循环与Node**接口，明确尾指针写回和结点所有权。",
    "change": "从直接重现幸存者模板改为完整删除循环与Node**接口，明确尾指针写回和结点所有权。",
})
patch["S3-I02"]["exposure"]["response"] = "旧版本C3课件，实际发放待核；核B01实讲。保留稳定性诊断这一新增要求，不直接重印2025阅读原空。"

# A one-pass implementation that copies every newly best path can take
# quadratic time on a comb-shaped tree, so require and score a two-pass DFS.
patch["S3-IV02"].update({
    "task": "二叉树结点含data、left、right及mark布尔域。输出一条从根到叶、且沿途至少经过一个mark=true结点的最长路径，长度按结点数；等长选先在左优先DFS中遇到的路径；若不存在返回无解。要求O(n)时间，写思想、关键伪码与复杂度。",
    "answer_blueprint": "两遍左优先DFS。第一遍携带seen=seen∨node.mark与深度，仅在叶且seen时更新bestLen，不复制路径。若无合格叶返回无解。第二遍同样携带seen和当前路径栈，按左、右顺序查找首个满足seen且深度=bestLen的叶，找到即停止并输出栈；严格先左保证等长先到。两遍各至多访每结点一次，O(n)时间，递归和路径O(h)辅助空间，输出O(h)。",
    "rubric": [["仅合格叶路径参与最大值比较",2],["第一遍递归正确传递seen并求bestLen",2],["第二遍左优先找首条目标路径",3],["空树或无合格叶返回无解",1],["两遍均O(n)、O(h)栈和输出空间解释",2]],
})

# Do not repeat S1-III06's capacity/forward/reverse trio. Diagnose a false
# fixed-width mapping first, then derive the valid band mapping.
patch["S3-III01"].update({
    "title": "三对角压缩映射的首个错位",
    "task": "6×6三对角矩阵只存满足|i−j|≤1的项，按行主序紧凑放入0基数组B，i、j均从0计。有人套用k=3i+j，声称每行都按3项排。①按实际存储次序找出该式第一次给错的带内元素、错误下标及正确下标，说明错因。②依据各行实际长度推导任意带内A[i,j]的正确下标公式，并用A[4,3]检验。③用首末两行核验边界：B[15]来自A的哪个位置？A[0,2]是否占B槽？说明理由。",
    "data": "矩阵阶数n=6；仅带内元素占槽，结构性零不存；B下标从0起连续无空位。",
    "answer_blueprint": "行0仅A[0,0],A[0,1]，分别在B[0],B[1]；下一项A[1,0]应在B[2]，错式3i+j给3，故此处首次错位。行0只有2项，不能当作固定3槽；末行也只有2项。各行起始槽依次为0,2,5,8,11,14；行i的带内元素按列递增占连续槽，化简得k=2i+j（|i−j|≤1）。A[4,3]→B[11]。末行A[5,4]→B[14]、A[5,5]→B[15]，故B[15]=A[5,5]；A[0,2]在带外，为结构性零，不占槽。",
    "objective": "识别固定三槽假设在边界行造成的首个错位，并从实际行长推导压缩映射",
    "evidence_required": "首错A[1,0]：错误3、正确2及行0仅2项；正确k=2i+j且A[4,3]→11；末行B[15]→A[5,5]及A[0,2]无槽",
    "misconception": "把每一行都当3槽，忽略首末行只有2项；把结构性零也计入B下标",
    "transfer": "从直接代公式转为审错、根据真实行边界推导映射并检验首末行",
    "task_family": "综合·压缩布局诊断",
    "novelty_type": "错解诊断",
    "time_reason": "首错定位、行起点推导及两项边界检验三步，预计10分钟",
    "rubric": [["首错A[1,0]：错式给3、实际为B[2]及行0原因",3],["从真实行长推导k=2i+j并验A[4,3]→11",4],["末行B[15]=A[5,5]、带外A[0,2]无槽",3]],
    "revision_note": "由容量、正向与逆向套算改为错误映射诊断；仍保留A[4,3]和B[15]用于独立数值核验。",
    "change": "由容量、正向与逆向套算改为错误映射诊断；仍保留A[4,3]和B[15]用于独立数值核验。",
})

# S1-III01 already has the E→A inorder successor. Audit a different thread
# on this full tree to avoid revealing the answer across papers.
patch["S4-III03"].update({
    "title": "F的中序右线索审计",
    "task": "树A(B(D,E),C(F,G))中，D/E/F/G均为叶。给出其中序线索表，除F的右线索被误写为G外其余均正确。写中序序列，指出唯一错误并修正F的rtag和rchild，说明遍历时tag=1应怎样处理。",
    "data": "真实孩子：A→(B,C)，B→(D,E)，C→(F,G)；空孩子才能挂线索；F无右孩子。",
    "answer_blueprint": "中序为D,B,E,A,F,C,G；F的中序后继是C，因此F.rtag=1、F.rchild=C，而非G。tag=1沿后继线索，不把它当真实右子树递归。",
    "objective": "通过真实中序相邻关系审计F的错误右线索",
    "evidence_required": "中序D,B,E,A,F,C,G；F后继C而非G；F.rtag=1、F.rchild=C及tag=1的遍历语义",
    "misconception": "把F的树形兄弟G当作中序后继，或把右线索当真实右子树入口",
    "transfer": "由正常线索遍历转为F的线索表项审计；避开其他套题已显露的E→A关系",
    "rubric": [["给出正确中序序列",3],["指出F的中序后继C而非G",2],["修正F.rtag=1与F.rchild=C",2],["区分tag=0真实孩子、tag=1后继线索并用于遍历",3]],
    "revision_note": "改审计F→C，避开第1套遍历题已给出的E→A线索答案。",
    "change": "改审计F→C，避开第1套遍历题已给出的E→A线索答案。",
})

if set(patch) != set(rows):
    raise ValueError(f"missing={sorted(set(rows)-set(patch))}, extra={sorted(set(patch)-set(rows))}")
for paper in (3, 4):
    selected = [r for r in patch.values() if r["paper"] == paper]
    points = sum(int(r["points"]) for r in selected)
    minutes = sum(r["minutes"] for r in selected)
    if len(selected) != 24 or points != 150 or not 155 <= minutes <= 168:
        raise ValueError(f"paper {paper}: {len(selected)} rows, {points} points, {minutes} minutes")
    print(f"paper {paper}: {len(selected)} questions, {points} points, {minutes} minutes")
for row in patch.values():
    for ref in row["exposure"]["references"]:
        if not (ROOT / ref).exists():
            raise FileNotFoundError((row["id"], ref))
OUTPUT.write_text(json.dumps(patch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"wrote {OUTPUT}")
