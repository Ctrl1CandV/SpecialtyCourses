"""Build a temporary v5 patch; never writes the formal papers."""

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / "资料整理/六套模拟卷成稿/试题源稿"
BLUEPRINT = ROOT / "资料整理/六套模拟卷规划/六套逐题蓝图.json"
IDS = ("S5-I04", "S5-II01", "S6-I01", "S6-I02", "S6-I03", "S6-I04")

papers = {
    paper: json.loads((SOURCE / f"第{paper}套.json").read_text(encoding="utf-8"))
    for paper in (5, 6)
}
questions = {
    row["id"]: row
    for paper in papers.values()
    for row in paper["questions"]
    if row["id"] in IDS
}
blueprint = {
    row["id"]: row
    for row in json.loads(BLUEPRINT.read_text(encoding="utf-8"))
    if row["id"] in IDS
}


def replace_once(value: str, before: str, after: str) -> str:
    if value.count(before) != 1:
        raise ValueError(f"Expected exactly one occurrence: {before[:50]!r}")
    return value.replace(before, after, 1)


def metadata(question_id: str, **changes: object) -> dict:
    original = blueprint[question_id]
    keys = (
        "title", "mode", "chapter", "tags", "points", "minutes", "level",
        "task", "data", "source_ids", "history_ids", "rubric", "objective",
        "evidence_required", "novelty_type", "task_family", "time_reason",
        "revision_note", "transfer", "innovation", "reference_alignment",
        "source_policy",
    )
    result = {key: original[key] for key in keys if key in original}
    result.update(changes)
    result["points"] = original["points"]
    return result


s5_i04 = """给定容量 m≥1 的散列表，空槽用 -1 表示；待插入的关键字均为非负整数，每次调用前表中均不含该 key。散列函数为 H(key)=key mod m；发生冲突时，沿地址递增方向循环探测；若探测完 m 个槽仍无空槽，则插入失败。阅读完整程序，补全线性探测的关键表达式。
@@FENCE@@c
#include <stdio.h>
enum { CAP = 11, EMPTY = -1 };
int insertLinear(int table[], int m, int key) {
    int pos = __1__;
    for (int step = 0; step < m; ++step) {
        if (table[pos] == EMPTY) {
            table[pos] = key;
            return 1;
        }
        pos = __2__;
    }
    return 0;
}
int main(void) {
    int table[CAP];
    const int keys[] = {7, 18, 29, 3};
    for (int i = 0; i < CAP; ++i)
        table[i] = EMPTY;
    for (int i = 0; i < 4; ++i)
        insertLinear(table, CAP, keys[i]);
    for (int i = 0; i < CAP; ++i)
        printf("%d ", table[i]);
    putchar('\\n');
    return 0;
}
@@FENCE@@
填 __1__（2分）、__2__（2分）；一次 insertLinear 调用的最坏时间复杂度为 __3__（1分），用 m 表示。""".replace("@@FENCE@@", chr(96) * 3)

s5_ii01 = (
    "对数组 A=(6,2,5,1,4,3,7) 作升序冒泡排序。每趟从左向右比较相邻元素，"
    "只有前者大于后者才交换；第一趟依次比较下标(0,1)至(5,6)，第二趟依次比较"
    "(0,1)至(4,5)，不提前停止。第一趟结束后的数组为 __1__（1分）；"
    "第二趟结束后的数组为 __2__（1分）；这两趟合计交换 __3__（1分）次。"
)

s6_i01 = questions["S6-I01"]["content"]
s6_i01 = replace_once(
    s6_i01,
    "以 n=65536 调用 grow，count 是有效指针，实际运行无溢出。分析增长阶时，n 为足够大的 2 的幂，采用无溢出的数学整数模型，每次数学整数算术操作计为常数时间。",
    "以 n=65536 调用 grow，count 是有效指针。分析时间复杂度时，假定整数运算不会溢出，且每次整数运算、比较和赋值均耗时常数。",
)
s6_i01 = replace_once(
    s6_i01,
    "在所给数学整数模型下，循环次数关于 n 的紧渐近界为 __3__（2分）",
    "grow 关于 n 的时间复杂度为 __3__（2分）",
)
s6_i01 = replace_once(
    s6_i01,
    "grow 按固定数量标量计的额外空间复杂度为 __4__（1分）",
    "grow 的额外空间复杂度为 __4__（1分）",
)

s6_i02 = questions["S6-I02"]["content"]
s6_i02 = replace_once(s6_i02, "p->next = __3__;", "p->next = out;")
s6_i02 = replace_once(
    s6_i02,
    "填 __1__（1分）、__2__（1分）、__3__（1分）；mergeReverse 的最坏时间复杂度为 __4__（1分），额外空间复杂度为 __5__（1分），用 m、n 表示。",
    "填 __1__（2分）、__2__（2分）；mergeReverse 的最坏时间复杂度为 __3__（1分），用 m、n 表示。",
)

s6_i03 = questions["S6-I03"]["content"]
s6_i03 = replace_once(s6_i03, "total += __3__;", "total += leaves * level;")
s6_i03 = replace_once(
    s6_i03,
    "填 __1__（1分）、__2__（1分）、__3__（1分）；若树有 N 个结点、最大层宽为 W，weightedLeaves 的最坏时间复杂度为 __4__（1分），队列额外空间复杂度为 __5__（1分）。",
    "填 __1__（2分）、__2__（2分）；若树有 N 个结点，weightedLeaves 的最坏时间复杂度为 __3__（1分）。",
)

s6_i04 = questions["S6-I04"]["content"]
s6_i04 = replace_once(s6_i04, "return __3__;", "return count == V;")
s6_i04 = replace_once(
    s6_i04,
    "填 __1__（1分）、__2__（1分）、__3__（1分）；若图有 V 个顶点、E 条弧，kahn 的时间复杂度为 __4__（1分），包含 indeg 副本和队列的额外空间复杂度为 __5__（1分）。",
    "填 __1__（2分）、__2__（2分）；若图有 V 个顶点、E 条弧，kahn 的最坏时间复杂度为 __3__（1分）。",
)

patch = [
    {
        "id": "S5-I04",
        "content": s5_i04,
        "metadata": metadata(
            "S5-I04",
            title="线性探测散列表插入代码补全",
            mode="原创",
            chapter="查找",
            tags=["散列表", "线性探测", "开放定址"],
            minutes=7,
            level="中",
            task="补全散列表初始地址与循环探测地址，分析一次插入最坏时间",
            data="m≥1；H(key)=key mod m；-1为空；非负键且调用前表中无该key；循环探测至多m槽；表满失败",
            source_ids=[],
            history_ids=["真题-2024-综合2"],
            rubric=[["散列初始地址 __1__", 2], ["下一探测地址 __2__", 2], ["一次插入最坏时间复杂度 __3__", 1]],
            objective="在完整C程序中补全线性探测插入并判断表满情况下的时间上界",
            evidence_required="__1__、__2__ 两个代码表达式与 __3__ 一次插入最坏时间复杂度",
            novelty_type="表示转换",
            task_family="代码补全",
            time_reason="预计7分钟；两处关键代码空及一次复杂度填空，含完整调用场景，未做学生限时试做。",
            revision_note="第5版建议：删除与S2-I04近似的平衡树补码，改为线性探测散列表插入；散列方法有真题锚点，但程序阅读形式为迁移。",
            transfer="2024真题综合2为线性探测散列；本题把相同方法迁移为程序补全。",
            innovation=True,
            reference_alignment="真题散列方法迁移到程序补全，非近三年同型程序阅读。",
            source_policy="仅历史方法锚点；当前题目另编，不记直接来源",
        ),
        "reason": "与S2-I04平衡树阅读重复；改考常教散列表核心方法，并用m次探测界限覆盖表满。",
    },
    {
        "id": "S5-II01",
        "content": s5_ii01,
        "metadata": metadata(
            "S5-II01",
            title="冒泡排序两趟轨迹与交换次数",
            mode="原创",
            chapter="排序",
            tags=["冒泡排序", "排序轨迹", "交换次数"],
            minutes=3,
            level="中",
            task="按明确比较顺序求冒泡前两趟结果和合计交换次数",
            data="A=(6,2,5,1,4,3,7)；升序；仅逆序相邻对交换；首两趟不提前停止",
            source_ids=[],
            history_ids=["真题-2025-填空1"],
            rubric=[["第一趟后的数组 __1__", 1], ["第二趟后的数组 __2__", 1], ["两趟交换总次数 __3__", 1]],
            objective="具体跟踪冒泡排序的比较和交换，而非套用有序输入下的直接计数",
            evidence_required="两趟结束数组及总交换次数各一空",
            novelty_type="平行练习",
            task_family="过程追踪",
            time_reason="预计3分钟；需实际完成两趟相邻交换，未做学生限时试做。",
            revision_note="第5版建议：已排序输入过易，改成七元素非平凡两趟轨迹，仍是常规冒泡。",
            transfer="2025真题填空1是冒泡程序复杂度；本题另编数组两趟轨迹。",
            innovation=False,
            reference_alignment="2025真题填空1提供冒泡程序方法锚点；数组与两趟轨迹任务另编，非直接原题。",
            source_policy="仅历史方法锚点；当前题目另编，不记直接来源",
        ),
        "reason": "原已升序数据可直接写0次交换，考查力度不足；现需实际执行两趟。",
    },
    {
        "id": "S6-I01",
        "content": s6_i01,
        "metadata": metadata(
            "S6-I01",
            title="反复平方循环的时间复杂度",
            task="由完整C函数grow求返回值、计数与普通O表示的时间复杂度",
            data="n=65536、x初值2、每轮平方；整数基本操作常数时间且忽略溢出",
            rubric=[["本次返回值 x=__1__", 1], ["本次循环计数 count=__2__", 1], ["grow 的时间复杂度 __3__", 2], ["grow 额外空间复杂度 __4__", 1]],
            objective="由循环状态追踪结果并用普通O记法表达时间复杂度",
            evidence_required="x、count、时间复杂度、额外空间复杂度四空",
            revision_note="第5版建议：删去未教的‘紧渐近界/Θ’措辞，代码与计算任务不变。",
        ),
        "reason": "将‘紧渐近界’改为普通时间复杂度，避免超出课堂记法；原代码不改。",
    },
    {
        "id": "S6-I02",
        "content": s6_i02,
        "metadata": metadata(
            "S6-I02",
            minutes=8,
            task="补全归并循环条件、同键选取条件和最坏时间复杂度",
            rubric=[["归并循环条件 __1__", 2], ["同键先取A的条件 __2__", 2], ["最坏时间复杂度 __3__", 1]],
            objective="在完整链表归并程序中补全循环与选结点的核心表达式",
            evidence_required="两处关键代码表达式和一次时间复杂度填空",
            time_reason="预计8分钟；从五空减至三空，其中两处为关键条件，未做学生限时试做。",
            revision_note="第5版建议：给出头插连接语句，删除额外空间问；保留两处关键代码空和时间复杂度空。",
        ),
        "reason": "原五空过碎；保留决定算法正确性的循环边界及同键选取条件。",
    },
    {
        "id": "S6-I03",
        "content": s6_i03,
        "metadata": metadata(
            "S6-I03",
            minutes=7,
            task="补全层界定、叶结点判定和最坏时间复杂度",
            data="q调用时为空；N结点；队列基本操作均O(1)",
            rubric=[["本层结点数 __1__", 2], ["叶结点判定 __2__", 2], ["最坏时间复杂度 __3__", 1]],
            objective="在层序遍历语境中区分当前层界限与叶结点条件",
            evidence_required="层结点数、叶判定两处代码空及一次时间复杂度填空",
            time_reason="预计7分钟；从五空减至三空，层权累加已给，未做学生限时试做。",
            revision_note="第5版建议：给出层号加权语句，删除队列空间问；保留两个关键代码空和时间复杂度空。",
        ),
        "reason": "减少机械空数，仍检验层序边界与叶定义。",
    },
    {
        "id": "S6-I04",
        "content": s6_i04,
        "metadata": metadata(
            "S6-I04",
            mode="改编",
            minutes=7,
            task="补全拓扑队列循环、入度递减判零和最坏时间复杂度",
            rubric=[["队列循环条件 __1__", 2], ["入度更新判零 __2__", 2], ["最坏时间复杂度 __3__", 1]],
            objective="在Kahn拓扑程序中补全队列控制和入度更新",
            evidence_required="两处关键代码表达式和一次时间复杂度填空",
            time_reason="预计7分钟；从五空减至三空，最终计数判定已给，未做学生限时试做。",
            revision_note="第5版建议：给出全顶点输出判定，删除额外空间问；保留两处关键代码空和时间复杂度空。",
        ),
        "reason": "减少零散空数，保留Kahn过程最核心的队列和入度更新判断。",
    },
]

for item in patch:
    qid = item["id"]
    marks = [int(x) for x in re.findall(r"（(\d+)分）", item["content"])]
    if sum(marks) != blueprint[qid]["points"]:
        raise ValueError(f"{qid}: point markers sum to {sum(marks)}")
    expected = 4 if qid == "S6-I01" else 3
    blanks = {int(x) for x in re.findall(r"__(\d+)__", item["content"])}
    if blanks != set(range(1, expected + 1)):
        raise ValueError(f"{qid}: wrong blank set {blanks}")
    if sum(point for _, point in item["metadata"]["rubric"]) != sum(marks):
        raise ValueError(f"{qid}: rubric score mismatch")
    if qid.endswith("I04") or (qid.startswith("S6-I")):
        if item["content"].count(chr(96) * 3 + "c") != 1:
            raise ValueError(f"{qid}: missing C context")

OUT.mkdir(parents=True, exist_ok=True)
(OUT / "patch_reading.json").write_text(
    json.dumps(patch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print("Wrote 6 patch entries; blank sequences and point totals valid.")
