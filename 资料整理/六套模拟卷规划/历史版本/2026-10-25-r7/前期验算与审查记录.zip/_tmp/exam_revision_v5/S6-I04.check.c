#include <stddef.h>
typedef struct Queue Queue;
typedef struct Arc { int to; struct Arc *next; } Arc;
int empty(const Queue *q);
void enqueue(Queue *q, int x);
int dequeue(Queue *q);
void output(int x);
int kahn(int V, Arc *head[], int indeg[], Queue *q) {
    int count = 0;
    for (int u = 0; u < V; ++u)
        if (indeg[u] == 0) enqueue(q, u);
    while (!empty(q)) {
        int u = dequeue(q);
        output(u);
        ++count;
        for (Arc *e = head[u]; e != NULL; e = e->next)
            if (--indeg[e->to] == 0) enqueue(q, e->to);
    }
    return count == V;
}
int sampleDag(Queue *q) {
    Arc e23 = {3, NULL}, e12 = {2, NULL}, e02 = {2, NULL};
    Arc *head[4] = {&e02, &e12, &e23, NULL};
    int indeg[4] = {0, 0, 2, 1};
    return kahn(4, head, indeg, q);
}
int sampleCycle(Queue *q) {
    Arc e01 = {1, NULL}, e10 = {0, NULL};
    Arc *head[2] = {&e01, &e10};
    int indeg[2] = {1, 1};
    return kahn(2, head, indeg, q);
}
#include <assert.h>
#include <stdio.h>
struct Queue { int items[32], front, rear; };
int empty(const Queue *q) { return q->front == q->rear; }
void enqueue(Queue *q, int x) { q->items[q->rear++] = x; }
int dequeue(Queue *q) { return q->items[q->front++]; }
static int emitted[32], emitted_count;
void output(int x) { emitted[emitted_count++] = x; }
int main(void) {
    Queue q = {0};
    assert(sampleDag(&q) == 1);
    assert(emitted_count == 4);
    assert(emitted[0] == 0 && emitted[1] == 1
        && emitted[2] == 2 && emitted[3] == 3);
    Queue cycle_q = {0};
    emitted_count = 0;
    assert(sampleCycle(&cycle_q) == 0);
    assert(emitted_count == 0);
    Arc s01 = {1, NULL}, s12 = {2, NULL}, s21 = {1, NULL};
    Arc *partial_head[3] = {&s01, &s12, &s21};
    int partial_indeg[3] = {0, 2, 1};
    Queue partial_q = {0};
    assert(kahn(3, partial_head, partial_indeg, &partial_q) == 0);
    assert(emitted_count == 1 && emitted[0] == 0);
    printf("topology DAG/cycle checks passed\n");
    return 0;
}
