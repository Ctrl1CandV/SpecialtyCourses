from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
OUT=ROOT/'资料整理/六套模拟卷成稿';PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.write_text(s.strip()+'\n',encoding='utf8')
rows=read(PLAN/'六套逐题蓝图.json');audit=read(OUT/'内容复查核对.json');patches=read(HERE/'applied_patches.json')
changes=audit['changes'];byid={r['id']:r for r in rows}
papers=[read(OUT/f'试题源稿/第{p}套.json') for p in range(1,7)]
qs={q['id']:q for p in papers for q in p['questions']}
names={'I':'一','II':'二','III':'三','IV':'四'}
def label(qid):
 r=byid[qid];return f"卷{r['paper']} {names[r['section']]}.{r['number']}"
times=[sum(r['minutes'] for r in rows if r['paper']==p) for p in range(1,7)]
structure=read(OUT/'成卷结构核对.json');pages=[r['pages'] for r in structure['papers']]
table='| 题位 | 原题问题 | 本轮修改 |\n|---|---|---|\n'+'\n'.join(f"| {label(c['id'])} | {c['old_title']} | {c['new_title']}；{c['reason']} |" for c in changes if not c['supplemental'])
text=['# 本轮修改题面待审稿','','2026年10月25日，第5版审阅稿。按用户列出的11个题位修改，另对4个题位同步调整未教术语。以下为修改后的完整题面，分值与各卷一致，不含答案。全卷文件仍供审阅，待用户确认后再收尾。','',table,'','## 同步调整的术语','','卷一一.1、卷二一.1、卷四二.1、卷五一.1也出现Θ或紧渐近界，本轮一起改为课堂常用的时间复杂度和O记法。相关代码和分值保持原样。','']
for c in changes:
 q=qs[c['id']]
 text += [f"## {label(c['id'])} {c['new_title']}",'',f"{q['points']}分。修改：{c['reason']}",'',q['content'],'']
write(OUT/'本轮修改题面待审稿.md','\n'.join(text))
write(PLAN/'14_第二轮逐题审阅修订.md',f'''# 第二轮逐题审阅修订

2026年10月25日，设计r7、学生卷v5。依据用户亲自审卷列出的11处问题修改，另清理4题中的同类未教术语。完整题面见[本轮修改题面待审稿](../六套模拟卷成稿/本轮修改题面待审稿.md)。本轮为待审稿，用户确认后再进入收尾。

{table}

同类术语同步涉及卷一一.1、卷二一.1、卷四二.1、卷五一.1，只修改问法，不借此增加新任务。卷六一.2、一.3、一.4均改为两处代码空各2分、时间复杂度空1分，每题共三个空。

保守卷的希尔、基数排序不再采用，优先快排、归并、直接插入、堆等常教任务；不能仅因某年有排序题就把全部排序算法视为常考。该取舍依用户本轮教学与审题判断，不声称学校官方排除了这些内容。

卷五新散列程序阅读是将已教散列方法迁移到代码补全，不冒充近三年直接同型程序阅读。因新增此项，卷五的明确拓展位为5个，其余创新卷仍为4个；此前4题上限属于编辑选择，本轮据实际改题调整，用户没有给定此配额。

结构核对覆盖六套144题，题数和20/30/70/30分值不变。内容专项核验对应本轮改动，不能借此声称重新独立求解全部144题。估时仍为审稿判断。原第4版保存在`历史版本/2026-10-22-r6/用户逐题审阅修改前第4版快照.zip`。
''')
paper_table='| 套卷 | 定位 | 明确拓展题位 | 估计作答时间 | 页数 |\n|---|---|---|---:|---:|\n'+'\n'.join(f"| 第{p}套 | {'保守卷' if p<=3 else '适度创新卷'} | {'、'.join(r['id'].split('-')[1] for r in rows if r['paper']==p and r['innovation']) or '无'} | {times[p-1]}分钟 | {pages[p-1]} |" for p in range(1,7))
write(OUT/'README.md',f'''# 2027重邮802六套模拟卷学生卷

现行题面2026-10-25-student-v5，设计2026-10-25-r7，待用户审阅。第1—3套为保守卷，第4—6套为适度创新卷。

本轮修改用户点名的11题，另有4题只调整未教术语。先看[本轮修改题面待审稿](本轮修改题面待审稿.md)，再查看[合订本](六套模拟试卷合订本.pdf)。完整修改和核验边界见[审查与修订说明](审查与修订说明.md)。

- [无答案审阅包](六套学生卷_无答案.zip)：六份独立PDF、六份Markdown和说明。
- [用户分层规则](../六套模拟卷规划/12_用户审题意见与分层命题规则.md)。
- [本轮逐题修订](../六套模拟卷规划/14_第二轮逐题审阅修订.md)。
- [144题取舍对照](本轮逐题取舍对照.md)。

每套24题、150分、180分钟：程序阅读4×5分，填空10×3分，综合应用7×10分，算法设计8、10、12分。算法设计统一要求基本思想、C语言实现、时间与辅助空间复杂度。卷六后三道阅读各三个空。

{paper_table}

| 套卷 | PDF | 可编辑题稿 |
|---|---|---|
'''+ '\n'.join(f'| 第{p}套 | [PDF](学生卷PDF/重邮802模拟试卷第{p}套.pdf) | [Markdown](可编辑试题/第{p}套试卷.md) |' for p in range(1,7))+f'''

每套{pages[0]}页，合计{sum(pages)}页；应用题每题独立页，算法设计每题配整页续答区。页数用于书写。正式打印以PDF为准。答案、参考实现和详细评分细则待用户审定题面后制作。

学生JSON为题面源，规划JSON为元数据源。修改后同步哈希，运行`tools/exam_blueprint.py --write`和`tools/build_exam_papers.py --build --render`。旧种子核验不适用于新题。
''')
write(OUT/'审查与修订说明.md',f'''# 第5版用户逐题审阅修改说明

2026年10月25日。现行学生卷v5、设计r7，为待审稿。本轮修改11个点名题位，另修改4题的同类未教术语。第4版144题审查及124题修改属于历史工作，不能据此替代本轮结论。

{table}

## 问法与重复

所有学生题面移除Θ、紧渐近界和Theta。保守卷移除希尔、基数排序。卷五一.4更换重复的平衡树代码，卷六一.2至一.4每题减至三个空，并按2、2、1分分配；不以删除必要条件来缩短题干。

卷四四.3更换算法目标，使用常教方法完成较难迁移。完整题面和本轮理由见[待审稿](本轮修改题面待审稿.md)。卷五新增散列程序补全据实计为明确拓展，编辑上限改为5个；其他创新卷仍为4个。

## 核验与边界

本轮专项核验包括新排序过程、地址含义与单位、冒泡执行次数、拓扑序计数、替换算法的可实现性，以及修改阅读代码的补空编译和运行。只调整O记法的题位保留原代码。具体执行结果记录在`交付核对.json`，不把历史种子核验移用于新题。

六套仍各24题150分，分值20/30/70/30；PDF与Markdown由同一题面源生成，每套{pages[0]}页。修改页重新查看，未变页面可依据渲染字节一致性承接上一版检查。合订本逐页文字与六份独立卷按序一致，当前144条题面哈希与蓝图对应。无答案包只含学生材料。

预计作答时间依次{'、'.join(map(str,times))}分钟，尚未经学生限时试做；中等偏上仍是命题目标。用户本次审定后再收尾，答案、参考实现及详细评分细则继续暂缓。
''')
lines=['# 六套逐题取舍对照','','2026年10月25日第5版，144题。最新改动见本轮待审稿；未改题位的取舍说明承接第4版。','']
for p in range(1,7):
 lines += [f'## 第{p}套','', '| 题位 | 当前任务 | 定位与依据 | 处理说明 |','|---|---|---|---|']
 for r in rows:
  if r['paper']==p:lines.append('| '+r['id']+' | '+r['title']+' | '+('明确拓展。' if r['innovation'] else '同型或同法练习。')+r['reference_alignment'].replace('|','／')+' | '+r['change'].replace('|','／')+' |')
 lines.append('')
write(OUT/'本轮逐题取舍对照.md','\n'.join(lines))
lines=['# 重点考点与题号对照','','2026年10月25日第5版，按当前144题实际主任务索引。','']
for chapter in ('绪论','线性表','栈队列','串','数组广义表','树','图','查找','排序'):
 lines += ['## '+chapter,'','| 题位 | 任务 | 卷型 |','|---|---|---|']
 lines += [f"| {r['id']} | {r['title']} | {r['paper_profile']} |" for r in rows if r['chapter']==chapter]
 lines.append('')
write(OUT/'重点考点题号对照.md','\n'.join(lines))
write(PLAN/'00_总设计与执行说明.md',f'''# 六套模拟卷总设计与执行说明

现行设计2026-10-25-r7、学生卷2026-10-25-student-v5，待用户审阅。执行[用户分层规则](12_用户审题意见与分层命题规则.md)与[本轮逐题反馈](14_第二轮逐题审阅修订.md)，强参考为[近三年802实际任务](13_近三年802任务证据.md)。

固定每套24题150分：程序阅读4×5，填空10×3，应用7×10，算法8/10/12。第一至三套保守，第四至六套适度创新。

{paper_table}

保守卷优先常教重点，希尔、基数排序退出。全卷只采用已教的复杂度问法，卷六后三道阅读每题三空。算法题清楚描述单个任务，统一要求思路、C语言实现、时间和辅助空间复杂度；不追加分步小问。倒数第k等点名经典原功能不恢复。

创新数量为编辑尺度，卷五因本轮散列程序阅读迁移增为5个，其他创新卷仍为4个；不为凑数添加任务。题面源和蓝图须同步维护，改题后生成14个蓝图投影及学生文件。旧种子核验不可只改哈希继续沿用。题面审定后才编答案和详细评分。

本轮完整改题文本见[修改题面待审稿](../六套模拟卷成稿/本轮修改题面待审稿.md)，PDF和无答案包见[成稿入口](../六套模拟卷成稿/README.md)。
''')
for rel in ('README.md','资料整理/README.md','资料整理/工作区资料索引.md','资料整理/下一阶段工作入口.md','资料整理/模拟卷设计底稿.md','资料整理/后续实施流程与核查标准.md'):
 p=ROOT/rel;s=p.read_text(encoding='utf-8-sig')
 s=s.replace('2026-10-22-student-v4','2026-10-25-student-v5').replace('2026-10-22-r6','2026-10-25-r7')
 s=s.replace('第4版','第5版').replace('设计r6','设计r7')
 prefix='资料整理/' if rel=='README.md' else ''
 notice=f'> 现行更新（2026-10-25第5版待审稿）：按用户逐题反馈修改11题，另4题清理未教术语；保守卷移除希尔、基数排序，卷六后三道阅读各三空。先看[本轮修改题面]({prefix}六套模拟卷成稿/本轮修改题面待审稿.md)，用户审定后再收尾。'
 s=re.sub(r'^> 现行更新.*$',notice,s,flags=re.M)
 write(p,s)
# Keep historical evidence, while making current entry versions unambiguous.
for name in ('07_覆盖去重与风险.md','08_范围条件与备用题.md','09_蓝图数据复核记录.md','10_设计诊断与修订依据.md','11_代表题命题示例.md'):
 p=PLAN/name;s=p.read_text(encoding='utf8')
 notice='> 现行题面为2026-10-25-student-v5、设计r7，用户审阅中；本轮修订见[14号记录](14_第二轮逐题审阅修订.md)。历史版本结论不直接沿用于改题。'
 if notice not in s:
  first,rest=s.split('\n',1);s=first+'\n\n'+notice+'\n'+rest
 write(p,s)
p=OUT/'题型对齐依据.md';s=p.read_text(encoding='utf8').replace('现行第4版要求','现行第5版要求')
s+='\n## 第5版用户逐题修订\n\n2026-10-25按用户反馈修改11个指定题位，另4题清理同类未教术语。固定题型分值和卷内书写空间沿用；保守卷撤希尔和基数排序，复杂度采用O记法，卷六后三道阅读各三个空。当前内容见本轮修改题面待审稿。\n'
write(p,s)
# Keep the prior coverage discussion, but update actual main-chapter totals.
p=OUT/'考纲与重点覆盖复核.md';s=p.read_text(encoding='utf8')
s=s.replace('2026-10-22第4版','2026-10-25第5版')
s=s.replace('本轮以三保守三适度创新重新安排144题','在第4版三保守三适度创新基础上，本轮修改15题并更新144题汇总')
for chapter in ('绪论','线性表','栈队列','串','数组广义表','树','图','查找','排序'):
 points=sum(r['points'] for r in rows if r['chapter']==chapter)
 s=re.sub(r'\| '+re.escape(chapter)+r' \| \d+ \|',f'| {chapter} | {points} |',s)
write(p,s)
print('Published v5 pending-review entry and complete revised questions.')
