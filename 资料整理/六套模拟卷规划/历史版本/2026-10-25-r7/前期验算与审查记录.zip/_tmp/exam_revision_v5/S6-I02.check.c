#include <assert.h>
#define main original_main
#include <stdio.h>
#include <stdlib.h>
typedef struct Node { int key; struct Node *next; } Node;
Node *fromArray(const int x[], int n) {
    Node dummy = {0, NULL}, *tail = &dummy;
    for (int i = 0; i < n; ++i) {
        Node *p = malloc(sizeof *p);
        if (p == NULL) exit(EXIT_FAILURE);
        p->key = x[i]; p->next = NULL;
        tail->next = p; tail = p;
    }
    return dummy.next;
}
Node *mergeReverse(Node *a, Node *b) {
    Node *out = NULL, *p;
    while (a != NULL || b != NULL) {
        if (b == NULL || (a != NULL && a->key <= b->key)) {
            p = a; a = a->next;
        } else {
            p = b; b = b->next;
        }
        p->next = out;
        out = p;
    }
    return out;
}
int main(void) {
    const int x[] = {1, 3, 3}, y[] = {2, 3, 4};
    Node *a = fromArray(x, 3), *b = fromArray(y, 3);
    Node *p = mergeReverse(a, b);
    while (p != NULL) {
        Node *next = p->next;
        printf("%d ", p->key);
        free(p); p = next;
    }
    putchar('\n');
    return 0;
}
#undef main
int main(void) {
  assert(original_main() == 0);
  assert(mergeReverse(NULL, NULL) == NULL);
  int a[] = {1, 3, 3}, b[] = {2, 3, 4};
  Node *out = mergeReverse(fromArray(a, 3), fromArray(b, 3));
  int expect[] = {4, 3, 3, 3, 2, 1};
  for (int i = 0; i < 6; ++i) {
    assert(out != NULL && out->key == expect[i]);
    Node *next = out->next; free(out); out = next;
  }
  assert(out == NULL);
  Node first = {3, NULL}, second = {3, NULL};
  Node *tied = mergeReverse(&first, &second);
  assert(tied == &second && tied->next == &first);
  return 0;
}
