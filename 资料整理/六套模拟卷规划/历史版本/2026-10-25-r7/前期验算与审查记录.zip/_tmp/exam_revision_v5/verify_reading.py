"""Private C checks for the temporary reading patch; no answer artifact."""

import json
import re
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve().parent
GCC = Path("D:/Program Files/mingw64/bin/gcc.exe")
PATCH = {
    row["id"]: row for row in json.loads((HERE / "patch_reading.json").read_text(encoding="utf-8"))
}
code = {}
for qid, row in PATCH.items():
    match = re.search(re.escape(chr(96) * 3) + r"c\n(.*?)\n" + re.escape(chr(96) * 3), row["content"], re.S)
    if match:
        code[qid] = match.group(1)


def fill(qid, replacements):
    result = code[qid]
    for blank, value in replacements.items():
        token = f"__{blank}__"
        if result.count(token) != 1:
            raise ValueError(f"{qid}: {token} must occur exactly once in code")
        result = result.replace(token, value)
    if re.search(r"__\d+__", result):
        raise ValueError(f"{qid}: unfilled code blank")
    return result


hash_code = fill("S5-I04", {1: "key % m", 2: "(pos + 1) % m"})
hash_code = (
    "#include <assert.h>\n#define main original_main\n"
    + hash_code
    + "\n#undef main\n"
    + "int main(void) {\n"
    + "  assert(original_main() == 0);\n"
    + "  int table[3] = {0, 1, 2};\n"
    + "  assert(insertLinear(table, 3, 3) == 0);\n"
    + "  int sparse[3] = {-1, -1, -1};\n"
    + "  assert(insertLinear(sparse, 3, 4) == 1);\n"
    + "  assert(insertLinear(sparse, 3, 7) == 1);\n"
    + "  assert(insertLinear(sparse, 3, 10) == 1);\n"
    + "  assert(sparse[0] == 10 && sparse[1] == 4 && sparse[2] == 7);\n"
    + "  return 0;\n"
    + "}\n"
)

reverse_code = fill(
    "S6-I02", {1: "a != NULL || b != NULL", 2: "a->key <= b->key"}
)
reverse_code = (
    "#include <assert.h>\n#define main original_main\n"
    + reverse_code
    + "\n#undef main\n"
    + "int main(void) {\n"
    + "  assert(original_main() == 0);\n"
    + "  assert(mergeReverse(NULL, NULL) == NULL);\n"
    + "  int a[] = {1, 3, 3}, b[] = {2, 3, 4};\n"
    + "  Node *out = mergeReverse(fromArray(a, 3), fromArray(b, 3));\n"
    + "  int expect[] = {4, 3, 3, 3, 2, 1};\n"
    + "  for (int i = 0; i < 6; ++i) {\n"
    + "    assert(out != NULL && out->key == expect[i]);\n"
    + "    Node *next = out->next; free(out); out = next;\n"
    + "  }\n"
    + "  assert(out == NULL);\n"
    + "  Node first = {3, NULL}, second = {3, NULL};\n"
    + "  Node *tied = mergeReverse(&first, &second);\n"
    + "  assert(tied == &second && tied->next == &first);\n"
    + "  return 0;\n"
    + "}\n"
)

leaves_code = fill(
    "S6-I03",
    {1: "size(q)", 2: "p->left == NULL && p->right == NULL"},
)
leaves_code += """
#include <assert.h>
#include <stdio.h>
struct Queue { Node *items[32]; int front, rear; };
int empty(const Queue *q) { return q->front == q->rear; }
int size(const Queue *q) { return q->rear - q->front; }
Node *dequeue(Queue *q) { return q->items[q->front++]; }
void enqueue(Queue *q, Node *p) { q->items[q->rear++] = p; }
int main(void) {
    Queue q = {0};
    assert(sample(&q) == 8);
    Queue empty_q = {0};
    assert(weightedLeaves(NULL, &empty_q) == 0);
    Node one = {NULL, NULL};
    Queue one_q = {0};
    assert(weightedLeaves(&one, &one_q) == 1);
    printf("weighted leaves checks passed\\n");
    return 0;
}
"""

topo_code = fill(
    "S6-I04", {1: "!empty(q)", 2: "--indeg[e->to] == 0"}
)
topo_code += """
#include <assert.h>
#include <stdio.h>
struct Queue { int items[32], front, rear; };
int empty(const Queue *q) { return q->front == q->rear; }
void enqueue(Queue *q, int x) { q->items[q->rear++] = x; }
int dequeue(Queue *q) { return q->items[q->front++]; }
static int emitted[32], emitted_count;
void output(int x) { emitted[emitted_count++] = x; }
int main(void) {
    Queue q = {0};
    assert(sampleDag(&q) == 1);
    assert(emitted_count == 4);
    assert(emitted[0] == 0 && emitted[1] == 1
        && emitted[2] == 2 && emitted[3] == 3);
    Queue cycle_q = {0};
    emitted_count = 0;
    assert(sampleCycle(&cycle_q) == 0);
    assert(emitted_count == 0);
    Arc s01 = {1, NULL}, s12 = {2, NULL}, s21 = {1, NULL};
    Arc *partial_head[3] = {&s01, &s12, &s21};
    int partial_indeg[3] = {0, 2, 1};
    Queue partial_q = {0};
    assert(kahn(3, partial_head, partial_indeg, &partial_q) == 0);
    assert(emitted_count == 1 && emitted[0] == 0);
    printf("topology DAG/cycle checks passed\\n");
    return 0;
}
"""

cases = {
    "S5-I04": hash_code,
    "S6-I01": code["S6-I01"],
    "S6-I02": reverse_code,
    "S6-I03": leaves_code,
    "S6-I04": topo_code,
}
for qid, source in cases.items():
    source_file = HERE / (qid + ".check.c")
    executable = HERE / (qid + ".check.exe")
    source_file.write_text(source, encoding="utf-8")
    compiled = subprocess.run(
        [str(GCC), "-std=c11", "-Wall", "-Wextra", "-Werror", str(source_file), "-o", str(executable)],
        capture_output=True,
        text=True,
    )
    if compiled.returncode:
        raise RuntimeError(f"{qid} compile failed:\n{compiled.stderr}")
    ran = subprocess.run([str(executable)], capture_output=True, text=True)
    if ran.returncode:
        raise RuntimeError(f"{qid} run failed:\n{ran.stderr}")
    print(f"{qid}: C11 compile and run pass; output={ran.stdout.strip()!r}")

array = [6, 2, 5, 1, 4, 3, 7]
snapshots = []
swaps = 0
for pass_no in range(2):
    for i in range(len(array) - 1 - pass_no):
        if array[i] > array[i + 1]:
            array[i], array[i + 1] = array[i + 1], array[i]
            swaps += 1
    snapshots.append(array.copy())
if snapshots != [[2, 5, 1, 4, 3, 6, 7], [2, 1, 4, 3, 5, 6, 7]] or swaps != 8:
    raise RuntimeError("S5-II01 bubble trace mismatch")
print("S5-II01: two-pass trace and 8 total swaps pass")
