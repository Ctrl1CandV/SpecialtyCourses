from pathlib import Path
import hashlib,json,zipfile
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
OUT=ROOT/'资料整理/六套模拟卷成稿';PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
baseline=read(HERE/'baseline.json');oldq={q['id']:q for p in baseline['papers'] for q in p['questions']}
papers=[read(OUT/f'试题源稿/第{p}套.json') for p in range(1,7)];qs={q['id']:q for p in papers for q in p['questions']}
rows=read(PLAN/'六套逐题蓝图.json');audit=read(OUT/'内容复查核对.json');spec=read(OUT/'题型规范.json');structure=read(OUT/'成卷结构核对.json')
assert len(rows)==len(qs)==144
assert all(p['version']=='2026-10-25-student-v5' for p in papers)
changed={q for q in qs if qs[q]['content']!=oldq[q]['content']}
assert changed=={x['id'] for x in audit['changes']} and len(changed)==15
for r in rows:assert r['student_content_sha256']==hashlib.sha256(qs[r['id']]['content'].encode('utf8')).hexdigest(),r['id']
for x in audit['records']+audit['changes']:assert x['student_sha256']==hashlib.sha256(qs[x['id']]['content'].encode('utf8')).hexdigest()
texts=[];files=[];pages=[]
for n,s in enumerate(structure['papers'],1):
    assert s['paper']==n and s['points']==150 and s['questions']==24
    assert s['source_sha256']==sha(OUT/f'试题源稿/第{n}套.json')
    pdf=OUT/f'学生卷PDF/重邮802模拟试卷第{n}套.pdf';md=OUT/f'可编辑试题/第{n}套试卷.md'
    reader=PdfReader(pdf);assert len(reader.pages)==s['pages']==19
    texts.extend(p.extract_text() for p in reader.pages);files.extend([pdf,md]);pages.append(len(reader.pages))
combined=OUT/'六套模拟试卷合订本.pdf';reader=PdfReader(combined)
assert len(reader.pages)==114 and len(reader.outline)==6
assert [p.extract_text() for p in reader.pages]==texts
assert sha(ROOT/spec['reference'])==spec['reference_sha256']
visual=read(HERE/'visual_review.json')
for n in range(1,7):
    v=visual[str(n)];assert v['pdf_sha256']==sha(OUT/f'学生卷PDF/重邮802模拟试卷第{n}套.pdf')
    assert v['all_changed_pages_reviewed'] and v['status']=='pass'
    assert len(v['changed_pages'])+v['unchanged_render_pages']==19
times=[sum(r['minutes'] for r in rows if r['paper']==p) for p in range(1,7)]
archive=OUT/'六套学生卷_无答案.zip'
info=f'''2027重邮802六套模拟试卷 第5版待审稿
版本：2026-10-25-student-v5

第1至3套保守卷，第4至6套适度创新卷。
按用户2026年10月25日反馈修改11题，另4题统一为已教的O记法。
程序阅读4×5分、填空10×3分、综合7×10分、算法8/10/12分。
每套24题150分180分钟，19页。应用题各一页，算法题附续答页。
卷六后三道阅读各3个空，分值2+2+1。

本包包含6份PDF、6份Markdown及本说明，共13个文件。
本版供用户审阅，题面审定后再收尾及制作答案、参考代码和评分细则。
估计用时依次{'、'.join(map(str,times))}分钟，尚未经考生限时试做。
'''
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.relative_to(OUT).as_posix())
    z.writestr('使用说明.txt',info.encode('utf8'))
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==13 and z.testzip() is None
    for f in files:assert z.read(f.relative_to(OUT).as_posix())==f.read_bytes()
dbhash=sha(ROOT/'题库数据库/tiku.db').upper()
assert dbhash=='3F050FEA3CF82D0753DD24C8E518C0B1C49ED70C740B703D572A0B37E7B4D718'
manifest={'date':'2026-10-25','version':'2026-10-25-student-v5','design_version':'2026-10-25-r7','format_version':spec['version'],
 'status':'待用户审定题面，尚未收尾','student_questions':144,'total_points':900,'pdf_pages':114,'pages_per_paper':pages,'answers_produced':False,
 'user_named_revisions':11,'supplemental_notation_revisions':4,'changed_student_texts':15,'student_content_hashes_checked':144,
 'changed_ids':sorted(changed),'estimated_minutes':times,'timing_empirically_validated':False,
 'innovation_ids':{str(p):[r['id'] for r in rows if r['paper']==p and r['innovation']] for p in range(1,7)},
 'content_review':'本轮专项审查15个改动题位；其余129题内容承接第4版。结构与版本核对覆盖144题。',
 'visual_review':visual,'combined_pdf_check':'114页逐页文字与六份独立卷按序相同，6个分卷书签。',
 'archive_check':'13项；CRC通过；12份PDF/Markdown逐项字节相同。',
 'source_checks':structure['papers'],'reference':spec['reference'],'reference_sha256':spec['reference_sha256'],
 'files':[{'file':f.relative_to(OUT).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size} for f in [combined,archive]+files],
 'seed_verification':'第4版以前的旧输入不适用，本轮按实际换题进行专项内部核验。',
 'limitations':['本轮仍待用户审阅；实际难度和完成时间需限时试做。','官方原站附件与现存考纲转载副本的一致性未重新核查。'],
 'database_sha256':dbhash}
(OUT/'交付核对.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('PASS v5 pending review: 15 updated questions; 144 hashes; 114 pages; 6 bookmarks; 13 archive files; unchanged database.')
