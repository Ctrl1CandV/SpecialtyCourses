from pathlib import Path
import json,hashlib,re
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
OUT=ROOT/'资料整理/六套模拟卷成稿';PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def digest(s):return hashlib.sha256(s.encode('utf8')).hexdigest()
baseline=read(HERE/'baseline.json');papers=baseline['papers'];rows=baseline['blueprint']
assert all(read(OUT/f'试题源稿/第{p}套.json')['version']=='2026-10-22-student-v4' for p in range(1,7)), 'Run the v4-to-v5 migration once only'
questions={q['id']:q for p in papers for q in p['questions']};byid={r['id']:r for r in rows}
patches=[]
for name in ('patch_sort_array.json','patch_graph.json','patch_reading.json'):
    data=read(HERE/name)
    if isinstance(data,dict):data=data.get('patches',data.get('questions',data))
    assert isinstance(data,list),name
    patches.extend(data)
for qid,old,new in (
    ('S1-I01','Θ(__3__)','O(__3__)'),
    ('S2-I01','Θ(__3__)','O(__3__)'),
    ('S5-I01','work(n) 运行时间的紧渐近界为 __4__','work(n) 的时间复杂度为 O(__4__)'),
):
    assert old in questions[qid]['content']
    r=byid[qid]
    rubric=[[str(label).replace('Θ(', 'O(').replace('运行时间的紧渐近界','时间复杂度'),points] for label,points in r['rubric']]
    patches.append({'id':qid,'content':questions[qid]['content'].replace(old,new),
                    'metadata':{'rubric':rubric},'reason':'检查到同类未教术语，同步改用课堂常用时间复杂度及O记法；代码和分值不变。','supplemental':True})
patches.append({'id':'S4-II01','content':'设 n=2^k（k≥0），递归函数在 n=1 时执行一次基本操作；n>1 时调用两次规模为 n/2 的自身，并额外执行一次基本操作。基本操作次数满足 T(1)=1、T(n)=2T(n/2)+1。该函数的时间复杂度为 ______（2分），递归调用所需的辅助空间复杂度为 ______（1分），均用 O 记法表示。',
 'metadata':{'title':'二分递归的时间与递归栈空间','task':'根据两次半规模递归计算时间与递归栈空间复杂度','data':'n=2^k；T(1)=1，T(n)=2T(n/2)+1；顺序递归调用',
             'rubric':[['时间复杂度',2],['递归栈辅助空间复杂度',1]]},
 'reason':'将递归式中的Θ常数项改为明确基本操作次数，按已教的时间、空间复杂度填写。','supplemental':True})
expected={'S2-III07','S3-II05','S3-III07','S4-IV03','S5-I04','S5-II01','S5-II07','S6-I01','S6-I02','S6-I03','S6-I04','S1-I01','S2-I01','S4-II01','S5-I01'}
assert {x['id'] for x in patches}==expected and len(patches)==15
changes=[]
for patch in patches:
    qid=patch['id'];q=questions[qid];r=byid[qid];before=q['content'];oldtitle=r['title']
    assert before!=patch['content'],qid
    q['content']=patch['content'];r.update(patch.get('metadata',{}))
    if qid=='S6-I03':
        r['reference_alignment']='2024原PDF物理p6算法3包含二叉树按层统计叶结点的任务；本题将分层叶数计算迁移为层序程序补全，非近三年同型程序阅读。'
    if not r['source_ids']:r['mode']='原创'
    r['previous_revision_note']=r['revision_note']
    r['change']=f'第5版：原「{oldtitle}」改为「{r["title"]}」。'+patch['reason']
    r['revision_note']='2026-10-25用户逐题审阅修订：'+patch['reason']
    r['objective']=r['task'];r['evidence_required']='；'.join(str(x[0]) for x in r['rubric'])
    r['transfer']=r['reference_alignment']
    r['time_reason']=f"本轮审稿估计{r['minutes']}分钟，未经过考生限时实测。"
    changes.append({'id':qid,'old_title':oldtitle,'new_title':r['title'],'reason':patch['reason'],
                    'supplemental':patch.get('supplemental',False),
                    'before_sha256':digest(before),'student_sha256':digest(q['content'])})
for r in rows:
    q=questions[r['id']]
    r['design_version']='2026-10-25-r7';r['review_version']='2026-10-25-quality-v5'
    r['student_content_sha256']=digest(q['content'])
    r['answer_blueprint']='待用户审定第5版题面后，再制作答案、C参考实现和详细评分细则。'
for p in papers:
    p['version']='2026-10-25-student-v5'
    write(OUT/f"试题源稿/第{p['paper']}套.json",p)
write(PLAN/'六套逐题蓝图.json',rows)
spec=read(OUT/'题型规范.json');spec['version']='2026-10-25-format-v5'
policy=spec['content_policy'];policy['authority']='用户2026-10-22分层要求及2026-10-25逐题反馈，详见规划12、14号文件'
policy['untaught_notation_excluded']=['Θ','Theta','紧渐近界']
policy['conservative_sorting_excluded']=['Shell排序','希尔排序','基数排序']
policy['paper6_completion_blank_cap']=3
policy['innovation_slot_caps']={str(p):4 for p in range(1,7)}
policy['innovation_slot_caps']['5']=5
policy['cap_note']='编辑上限，非用户固定比例；卷五本轮新增散列程序阅读迁移，允许5个明确拓展位。'
write(OUT/'题型规范.json',spec)
write(OUT/'内容复查核对.json',{'version':'2026-10-25-quality-v5','baseline':'2026-10-22-student-v4',
 'questions_in_set':144,'questions_reviewed':15,'user_named_questions':11,'supplemental_notation_questions':4,'changed_count':15,
 'changes':sorted(changes,key=lambda x:list(questions).index(x['id'])),
 'records':[{'id':r['id'],'paper_profile':r['paper_profile'],'innovation':r['innovation'],'reference_alignment':r['reference_alignment'],'minutes':r['minutes'],
             'student_sha256':r['student_content_sha256'],'changed_this_revision':r['id'] in expected} for r in rows]})
write(HERE/'applied_patches.json',patches)
print('Applied 11 named revisions and 4 notation-only revisions. Minutes:',[sum(r['minutes'] for r in rows if r['paper']==p) for p in range(1,7)])
