from pathlib import Path
import json,hashlib,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
OUT=ROOT/'资料整理/六套模拟卷成稿';PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'tools'));import build_exam_papers as b
from pypdf import PdfReader
b.init_pdf();rows=read(PLAN/'六套逐题蓝图.json');r={x['id']:x for x in rows};structure=read(OUT/'成卷结构核对.json')
replacements={2:('S2-I01','本次调用 move 共执行 __1__ 次（1分）。设 M(n) 是 n 个盘时的移动次数，M(1)=1，则 n>1 时 M(n)=__2__（2分）；程序时间复杂度为 O(__3__)（2分）。','本次 move 共执行 __1__ 次（1分）。设 n 个盘的移动次数为 M(n)，M(1)=1；当 n>1 时，M(n)=__2__（2分）。程序时间复杂度为 O(__3__)（2分）。'),5:('S5-I04','一次 insertLinear 调用的最坏时间复杂度为','一次插入的最坏时间复杂度为')}
review=OUT/'本轮修改题面待审稿.md';review_text=review.read_text(encoding='utf8');polish=[]
for n,(qid,old,new) in replacements.items():
 path=OUT/f'试题源稿/第{n}套.json';p=read(path);q=next(x for x in p['questions'] if x['id']==qid)
 assert old in q['content'];q['content']=q['content'].replace(old,new);write(path,p)
 assert old in review_text;review_text=review_text.replace(old,new)
 r[qid]['student_content_sha256']=hashlib.sha256(q['content'].encode('utf8')).hexdigest()
 target=b.PDF_DIR/f'重邮802模拟试卷第{n}套.pdf';before=sha(target)
 dest=b.QA_DIR/f'重邮802模拟试卷第{n}套';before_png={f.name:sha(f) for f in dest.glob('page-*.png')}
 d=b.load_paper(n);assert not b.validate(d);b.check_font_coverage([d]);spaces,qpages=b.build_pdf(d,target);b.render_pdf(target)
 after_png={f.name:sha(f) for f in dest.glob('page-*.png')};changed=[k for k in after_png if after_png[k]!=before_png[k]]
 (b.MD_DIR/f'第{n}套试卷.md').write_text(b.markdown(d),encoding='utf8')
 s=next(x for x in structure['papers'] if x['paper']==n);s.update(pages=len(PdfReader(target).pages),answer_spaces=spaces,question_pages=qpages,source_sha256=sha(path))
 polish.append({'paper':n,'previous_checked_pdf_sha256':before,'pdf_sha256':sha(target),'changed_render_pages':changed,'unchanged_since_group_review':19-len(changed)})
review.write_text(review_text,encoding='utf8');write(PLAN/'六套逐题蓝图.json',rows);write(OUT/'成卷结构核对.json',structure)
audit=read(OUT/'内容复查核对.json')
for x in audit['records']+audit['changes']:x['student_sha256']=r[x['id']]['student_content_sha256']
write(OUT/'内容复查核对.json',audit);b.merge_all();write(HERE/'polish_delta.json',polish)
print(json.dumps(polish,ensure_ascii=False))
