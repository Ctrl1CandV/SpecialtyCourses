#include <assert.h>
#define main original_main
#include <stdio.h>
enum { CAP = 11, EMPTY = -1 };
int insertLinear(int table[], int m, int key) {
    int pos = key % m;
    for (int step = 0; step < m; ++step) {
        if (table[pos] == EMPTY) {
            table[pos] = key;
            return 1;
        }
        pos = (pos + 1) % m;
    }
    return 0;
}
int main(void) {
    int table[CAP];
    const int keys[] = {7, 18, 29, 3};
    for (int i = 0; i < CAP; ++i)
        table[i] = EMPTY;
    for (int i = 0; i < 4; ++i)
        insertLinear(table, CAP, keys[i]);
    for (int i = 0; i < CAP; ++i)
        printf("%d ", table[i]);
    putchar('\n');
    return 0;
}
#undef main
int main(void) {
  assert(original_main() == 0);
  int table[3] = {0, 1, 2};
  assert(insertLinear(table, 3, 3) == 0);
  int sparse[3] = {-1, -1, -1};
  assert(insertLinear(sparse, 3, 4) == 1);
  assert(insertLinear(sparse, 3, 7) == 1);
  assert(insertLinear(sparse, 3, 10) == 1);
  assert(sparse[0] == 10 && sparse[1] == 4 && sparse[2] == 7);
  return 0;
}
