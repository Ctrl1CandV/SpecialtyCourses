from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'资料整理/六套模拟卷成稿'; PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
rows=read(PLAN/'六套逐题蓝图.json')
byid={r['id']:r for r in rows}
quantity={'S1-II02','S1-II03','S1-II06','S1-II07','S1-II08','S1-II10','S2-II02','S2-II03','S2-II05','S2-II06','S2-II07','S2-II08','S2-II10'}
representation={'S1-II01','S1-II05','S2-II01'}
for r in rows:
    if r['task_family']=='数值填空':
        r['task_family']='数量计算' if r['id'] in quantity else '表示转换' if r['id'] in representation else '过程追踪'
    if r['task_family']=='构造计算':r['task_family']='过程追踪' if r['id'] in ('S1-III07','S2-III04','S2-III05','S2-III07') else '结构构造'
    if r['level']=='中上':r['level']='辨'
    if not r['source_ids']:r['mode']='原创'
byid['S1-II10']['task']='求95关键字升序表成功折半查找的最多比较次数'
byid['S2-II08']['task']='求16关键字升序表成功折半查找的最多比较次数'
patches={r['id']:r for r in read(ROOT/'_tmp/exam_revision_v4/metadata56.json')}
for qid in ('S5-I02','S6-II08'):
    for key in ('source_ids','history_ids','reference_alignment'):
        byid[qid][key]=patches[qid][key]
    byid[qid]['mode']='改编' if byid[qid]['source_ids'] else '原创'
    byid[qid]['transfer']=byid[qid]['reference_alignment']
for r in rows:r['objective']=r['task']
write(PLAN/'六套逐题蓝图.json',rows)

# Preserve the complete queue program while compacting declarations and simple
# adjacent assignments; there is no control-flow or algorithm change.
p=read(OUT/'试题源稿/第3套.json')
q=next(q for q in p['questions'] if q['id']=='S3-I03')
q['content']=q['content'].replace('typedef struct Node {\n    int data;\n    struct Node *next;\n} Node;', 'typedef struct Node { int data; struct Node *next; } Node;').replace('    Queue q;\n    int x;', '    Queue q; int x;').replace('    p->data = x;\n    p->next = NULL;', '    p->data = x; p->next = NULL;')
write(OUT/'试题源稿/第3套.json',p)
write(ROOT/'_tmp/exam_revision_v4/paper3.json',p)
byid['S3-I03']['student_content_sha256']=hashlib.sha256(q['content'].encode('utf8')).hexdigest()
write(PLAN/'六套逐题蓝图.json',rows)
audit=read(OUT/'内容复查核对.json')
for r in audit['changes']+audit['records']:
    qid=r['id']
    r['student_sha256']=byid[qid]['student_content_sha256']
    if 'reference_alignment' in r:r['reference_alignment']=byid[qid]['reference_alignment']
write(OUT/'内容复查核对.json',audit)
print('Normalized metadata and compacted S3-I03 declarations.')
