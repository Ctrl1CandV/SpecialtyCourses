from pathlib import Path
import hashlib,json,zipfile
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'资料整理/六套模拟卷成稿';PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def content_sha(q):return hashlib.sha256(q['content'].encode('utf8')).hexdigest()
papers=[read(OUT/f'试题源稿/第{p}套.json') for p in range(1,7)]
questions={q['id']:q for p in papers for q in p['questions']}
rows=read(PLAN/'六套逐题蓝图.json')
assert len(questions)==len(rows)==144
assert all(p['version']=='2026-10-22-student-v4' for p in papers)
assert all(r['design_version']=='2026-10-22-r6' for r in rows)
for r in rows:assert r['student_content_sha256']==content_sha(questions[r['id']]),r['id']
audit=read(OUT/'内容复查核对.json')
assert audit['questions_reviewed']==len(audit['records'])==144
assert len(audit['changes'])==audit['changed_count']==124
for r in audit['records']+audit['changes']:
    assert r['student_sha256']==content_sha(questions[r['id']]),r['id']
spec=read(OUT/'题型规范.json');assert spec['version']=='2026-10-22-format-v4'
assert sha(ROOT/spec['reference'])==spec['reference_sha256']
structure=read(OUT/'成卷结构核对.json');texts=[];files=[];page_counts=[]
for p,s in zip(papers,structure['papers']):
    n=p['paper'];assert s['paper']==n
    assert s['source_sha256']==sha(OUT/f'试题源稿/第{n}套.json')
    assert s['questions']==24 and s['points']==150
    pdf=OUT/f'学生卷PDF/重邮802模拟试卷第{n}套.pdf';md=OUT/f'可编辑试题/第{n}套试卷.md'
    pages=PdfReader(pdf).pages;assert len(pages)==s['pages']==19
    page_counts.append(len(pages));pt=[x.extract_text() for x in pages]
    assert all(t.strip() for t in pt);texts.extend(pt);files.extend([pdf,md])
combined=OUT/'六套模拟试卷合订本.pdf';reader=PdfReader(combined)
assert [p.extract_text() for p in reader.pages]==texts
assert len(reader.outline)==6 and len(texts)==114
times=[sum(r['minutes'] for r in rows if r['paper']==p) for p in range(1,7)]
innovation_ids={str(p):[r['id'] for r in rows if r['paper']==p and r['innovation']] for p in range(1,7)}
assert [len(x) for x in innovation_ids.values()]==[0,0,0,4,4,4]
readme=f'''2027重邮802六套模拟试卷｜学生卷第4版
版本：2026-10-22-student-v4

第1—3套：保守卷，按2024—2026本校802常见任务巩固练习。
第4—6套：适度创新卷，常考基础上每套设置4个明确拓展题位。
本包包含六份独立PDF、六份可编辑Markdown及本说明，共13个文件。

每套24题、150分、180分钟：
程序阅读4×5分；填空10×3分；综合应用7×10分；算法设计8、10、12分。
程序阅读以补全代码为主；第二部分无选择项；综合应用为计算、构造及执行过程。
算法设计统一要求基本思想、C语言实现、时间复杂度和辅助空间复杂度。

各大题内独立编号，请在题后作答区写明小题及空号。
每套PDF19页。程序阅读和应用每题一页；算法设计每题附整页续答空间。
Markdown与PDF来自同一题面源，PDF为正式打印版。

本轮复查144个题位，修改124道题面；不附标准答案、参考代码或内部核算记录。
预计作答用时依次为{'、'.join(map(str,times))}分钟，尚未经学生限时试做。
中等偏上是命题目标，实际难度、理解和时间需结合审卷与试做校准。
用户审定题面后，再制作对应答案和评分细则。
'''
archive=OUT/'六套学生卷_无答案.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.relative_to(OUT).as_posix())
    z.writestr('使用说明.txt',readme.encode('utf8'))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==13
    for f in files:assert z.read(f.relative_to(OUT).as_posix())==f.read_bytes()
dbhash=sha(ROOT/'题库数据库/tiku.db').upper()
assert dbhash=='3F050FEA3CF82D0753DD24C8E518C0B1C49ED70C740B703D572A0B37E7B4D718'
visuals=[read(Path(__file__).parent/f'visual{pair}.json') for pair in ('12','34','56')]
delta=read(Path(__file__).parent/'visual_polish_delta.json')
for x in delta:
    assert x['root_final_visual_review']=='pass'
    assert sha(OUT/f"学生卷PDF/重邮802模拟试卷第{x['paper']}套.pdf")==x['final_pdf_sha256']
baseline_visual=visuals[0]['papers']+visuals[1]['pdfs']+list(visuals[2]['pdfs'].values())
assert sum(len(x['pages']) for x in baseline_visual)==114
delta_by_paper={x['paper']:x for x in delta}
for x in baseline_visual:
    path=x.get('pdf',x.get('pdf_path'));n=int(Path(path).stem.split('第')[1][0])
    checked_hash=x.get('sha256',x.get('pdf_sha256')).lower()
    if n in delta_by_paper:
        assert checked_hash==delta_by_paper[n]['previous_pdf_sha256']
    else:assert checked_hash==sha(ROOT/path)
visuals.append({'root_final_polish_review':delta,'note':'三处文字换行修整后逐页复看；54张其他PNG逐字节未变。其余57页原视觉检查有效，共114页。'})
manifest={
 'date':'2026-10-22','version':'2026-10-22-student-v4','format_version':spec['version'],'design_version':'2026-10-22-r6',
 'student_questions':144,'total_points':900,'pdf_pages':114,'pages_per_paper':page_counts,'answers_produced':False,
 'paper_profiles':spec['paper_profiles'],'innovation_ids':innovation_ids,
 'files':[{'file':f.relative_to(OUT).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size} for f in [combined,archive]+files],
 'source_checks':structure['papers'],'reference':spec['reference'],'reference_sha256':spec['reference_sha256'],
 'student_content_hashes_checked':144,'changed_student_texts':audit['changed_count'],
 'scope_policy':'以近三年本校802实际任务为强参考；保守卷同型或同法小幅迁移，适度创新卷每套4个明确拓展。低频非重点不为覆盖率加入。',
 'content_review':'144题分组内容审查和交叉复核，记录取舍、微迁移与来源关系；修正含糊填空、解释小问、分步算法和重复数据。',
 'code_review':{'recompiled_and_run_this_revision':9,'changed_reading_code':3,'ids':['S1-I01','S1-I02','S1-I03','S1-I04','S2-I01','S2-I02','S2-I03','S2-I04','S3-I03'],'other_reading_code':'其余15道代码主体沿用第3版已核代码，本轮精简题干；未声称全部重新编译。'},
 'visual_review':visuals,'combined_pdf_check':'114页逐页文字与六份独立PDF按序拼接完全相同；6个分卷书签。',
 'archive_check':'13项；CRC通过；12份PDF/Markdown逐项字节相同。',
 'seed_verification':'旧21项输入绑定不适用于本轮新题，未重贴哈希沿用旧通过结论。',
 'estimated_minutes':times,'timing_empirically_validated':False,
 'limitations':['实际难度、完成时间与考生理解仍需限时试做。','考纲使用此前存档的802转载副本，未核对原站附件与转载一致性。','2026参考资料为回忆版，缺失的题干和数据不作为已确认事实。'],
 'database_sha256':dbhash,'git_base':'4c819505ff381100aa8097a6bb4f3e7b56170d18'}
(OUT/'交付核对.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('PASS v4: 144 hashes; 124 updated texts; 114 pages; 6 bookmarks; 13 ZIP entries; database unchanged.')
