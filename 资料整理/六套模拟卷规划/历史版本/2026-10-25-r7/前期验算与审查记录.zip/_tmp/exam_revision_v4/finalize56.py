"""Build review metadata and notes for draft papers 5/6 only."""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "_tmp/exam_revision_v4"
BLUEPRINT = ROOT / "资料整理/六套模拟卷规划/六套逐题蓝图.json"
FORMAL = ROOT / "资料整理/六套模拟卷成稿/试题源稿"

def pts(*items: tuple[str, int]) -> list[list[object]]:
    return [[label, score] for label, score in items]

META: dict[str, dict] = {
    "S5-I02": dict(source_ids=[], history_ids=["真题-2026-阅读3"], reference_alignment="2026回忆稿p2阅读3在链表交集中重连并释放原结点；本题单表删除偶数的目标和扫描条件不同，仅作指针维护与free方法锚点，不把原题当直接同型来源。"),
    "S5-II01": dict(title="有序输入下冒泡排序比较与交换次数", task="比较提前停止与固定趟数的冒泡排序操作次数", data="8个升序互异元素；固定趟第r趟比较8-r次", rubric=pts(("提前停止比较7次",1),("交换0次",1),("固定7趟共28次比较",1)), reference_alignment="2025 PDF p10填空1是冒泡程序复杂度；此题改为具体操作次数，属于同算法的量化练习。"),
    "S5-II04": dict(title="给定约定下的KMP next数组", chapter="串", tags=["KMP","next数组","前后缀"], task="填写模式abcabca的完整1基next数组", data="P=abcabca，next[1]=0，余项最长真前后缀长度加1", minutes=3, level="中", rubric=pts(("next=(0,1,1,1,2,3,4)",3)), history_ids=["真题-2024-填空3","真题-2025-填空8"], source_ids=["真题-2025-填空8"], reference_alignment="2024 PDF p5填空3及2025 PDF p11填空8均考KMP next；本题模式串改为abcabca，避免与第4套重复。"),
    "S5-II08": dict(title="折半查找比较轨迹", chapter="查找", tags=["折半查找","比较轨迹"], task="填写查找26时的比较下标和次数", data="A[1..15]=2,4,...,30；闭区间下中点", minutes=2, level="基", rubric=pts(("比较下标8、12、14、13",2),("共4次",1)), history_ids=["真题-2025-综合4","真题-2026-填空13"], source_ids=[], reference_alignment="2025 PDF p12综合4折半判定树；2026回忆稿p4填空13折半最坏比较数。本题只要求具体轨迹。"),
    "S5-II09": dict(title="小根堆插入后的数组", chapter="排序", tags=["小根堆","插入上滤"], task="填写插入2并上滤后的堆数组", data="A[1..6]=(3,7,5,10,9,8)", minutes=2, level="基", rubric=pts(("插入后的完整数组(2,7,3,10,9,8,5)",3)), history_ids=["真题-2025-填空10"], source_ids=["真题-2025-填空10"], reference_alignment="2025 PDF p11填空10为小根堆插入后数组，同题型换数据。"),
    "S5-II10": dict(title="Huffman树结点与叶数", chapter="树", tags=["Huffman树","叶结点数"], task="由严格二叉Huffman树总结点数求字符数", data="总结点数217", minutes=2, level="基", rubric=pts(("叶数109",3)), history_ids=["真题-2025-填空4"], source_ids=["真题-2025-填空4"], reference_alignment="2025 PDF p11填空4同为Huffman树总结点数求叶数；本题改数据为217。2024 PDF p5填空4为1247结点，但曾出现库映射错位，核证以原PDF为准。"),
    "S5-III01": dict(title="二叉树双序重建与线索位置", chapter="树", tags=["先中序重建","后序遍历","中序线索"], task="画树、求后序、求叶结点中序前驱后继", data="先序ABDECFG；中序DBEAFCG", minutes=10, level="中", rubric=pts(("正确画出全部左右孩子",4),("后序DEBFGCA",3),("D的前驱空后继B；F的前驱A后继C",3)), history_ids=["真题-2024-综合3","真题-2026-综合16"], source_ids=[], reference_alignment="2024 PDF p5综合3为树遍历与线索；2026回忆稿p5综合16由先中序恢复树。本题组合两种同题型动作。"),
    "S5-III02": dict(title="折半查找判定树与平均查找长度", chapter="查找", tags=["折半查找","判定树","ASL"], task="画折半判定树、给成功失败轨迹、求成功ASL", data="A[1..10]=(5,12,18,23,31,42,57,66,74,89)；下中点", minutes=10, level="中", rubric=pts(("完整10结点判定树",5),("找57轨迹31、66、42、57",2),("找60轨迹31、66、42、57",1),("成功ASL为29/10",2)), history_ids=["真题-2025-综合4","真题-2026-综合23"], source_ids=["真题-2025-综合4"], reference_alignment="2025 PDF p12综合4画折半判定树并求ASL；2026回忆稿p6综合23亦为折半判定树。"),
    "S5-III03": dict(title="频率变化后的Huffman码代价", chapter="树", tags=["Huffman树","WPL","频率变化"], task="构造原树、计算沿用旧码代价并重建最优树", data="原频率2,4,7,10,15,25；A频率改为9", minutes=11, level="中", rubric=pts(("原合并权与WPL143",4),("沿用旧码WPL178",2),("新合并权与最优WPL170",4)), history_ids=["真题-2024-综合5","真题-2025-综合3"], source_ids=[], reference_alignment="2024 PDF p6综合5、2025 PDF p12综合3均为Huffman构造编码；频率变化是本卷指定创新，不说原题已有。"),
    "S5-III04": dict(title="二叉排序树构造、遍历与ASL", chapter="查找", tags=["BST","后序遍历","成功ASL"], task="构造BST、写后序与失败轨迹、求成功ASL", data="按40,20,10,30,60,50,70插入", minutes=10, level="中", rubric=pts(("正确BST",4),("后序10、30、20、50、70、60、40",2),("失败找55轨迹40、60、50及成功ASL17/7",4)), history_ids=["真题-2024-综合6","真题-2025-综合1"], source_ids=[], reference_alignment="2024 PDF p6综合6为BST/折半/AVL，2025 PDF p11综合1为BST重建与遍历；本题只做常规BST构造。"),
    "S5-III05": dict(title="双散列构造与成功ASL", chapter="查找", tags=["双散列","开放定址","成功ASL"], task="构造双散列表并计算插入探测与成功ASL", data="m=11；键22,1,13,11,24,35,46；给定双散列公式", minutes=11, level="中", rubric=pts(("各键地址与探测次数及最终散列表",6),("七键等概率成功ASL",4)), history_ids=["真题-2025-综合2"], source_ids=["真题-2025-综合2"], reference_alignment="2025 PDF p11综合2为双散列建表及成功ASL，同题型换数据。"),
    "S5-III06": dict(title="不连通图的DFS/BFS及生成森林", chapter="图", tags=["DFS","BFS","生成森林"], task="按指定邻接顺序列遍历序列、树边和分量数", data="7顶点无向图边0-1,0-2,1-2,3-4,4-5；6孤立", minutes=10, level="中", rubric=pts(("DFS/BFS访问序列",4),("两种森林树边",4),("3分量、各4树边",2)), history_ids=["真题-2025-综合5"], source_ids=["真题-2025-综合5"], reference_alignment="2025 PDF p12综合5含BFS/DFS及生成树计算；本题改为不连通图的森林。"),
    "S5-III07": dict(title="多关键字稳定排序的趟序", chapter="排序", tags=["稳定排序","多关键字","LSD"], task="按两种趟序写多关键字排序中间及最终记录顺序", data="a=(C,2),b=(A,1),c=(B,2),d=(A,2),e=(B,1),f=(A,1)", minutes=10, level="中", rubric=pts(("次关键字稳定排序后序列",3),("主关键字稳定排序后的词典序",3),("反向趟序的最终序列",4)), history_ids=["真题-2024-综合1"], source_ids=[], reference_alignment="2024 PDF p5综合1为多种排序过程，非本题多关键字稳定排序；本题是指定创新位。"),
    "S5-IV01": dict(title="有序链表保留同键最后原结点", chapter="线性表", tags=["有序单链表","结点删除","指针操作"], task="带头结点的有序链表每键保留最后一个原结点并释放其余", data="Node{key,next}；空表和重复键；不新建数据结点", minutes=10, level="中", rubric=pts(("遍历和修改指针的基本思想",2),("处理同键段、空表并正确释放的C代码",4),("时间和辅助空间复杂度",2)), history_ids=["真题-2025-算法1","真题-2026-算法24"], source_ids=[], reference_alignment="2025 PDF p13算法1和2026回忆稿p6算法24均要求单链表指针操作；本题为不同目标的保守微迁移，不声称同功能。"),
    "S5-IV02": dict(title="拓扑序前缀合法性", chapter="图", tags=["拓扑排序","前缀合法性"], task="给定DAG及合法互异顶点序列，判能否作某拓扑序前缀", data="G为DAG；0≤k≤V；P元素互异且合法；k=0返回真", minutes=11, level="中", rubric=pts(("逐项前缀约束判定思想",2),("按入度或等价条件实现并处理空前缀",6),("时间和辅助空间复杂度",2)), history_ids=["真题-2026-算法26"], source_ids=[], reference_alignment="2026回忆稿p7算法26检验完整拓扑序；本题只把序列缩为合法前缀，原图保证DAG、序列合法，属轻目标变化。"),
    "S5-IV03": dict(title="二叉树最长简单路径长度", chapter="树", tags=["二叉树","最长路径","递归"], task="只求任意两结点最长简单路径的边数", data="Node{left,right}；空树单结点返回0", minutes=15, level="中", rubric=pts(("递归汇总的基本思想",3),("线性遍历并覆盖空树的C代码",6),("时间和辅助空间复杂度",3)), history_ids=["真题-2025-算法2"], source_ids=[], reference_alignment="2025 PDF p13算法2求最长根叶路径；本题求任意两结点路径长度，属指定创新，不复用原功能。"),
    "S6-II02": dict(title="二维数组行主序地址", chapter="数组广义表", tags=["二维数组","行主序","地址计算"], task="求A[2][3]首地址", data="int A[4][5]；基址100；int占4字节", minutes=2, level="基", rubric=pts(("地址152",3)), history_ids=["真题-2024-填空6","真题-2025-填空3","真题-2026-填空8"], source_ids=["真题-2024-填空6"], reference_alignment="2024 PDF p5、2025 PDF p11、2026回忆稿p4均见数组地址填空；本题同任务换数据。"),
    "S6-II03": dict(title="指定首项的出栈序列数", chapter="栈队列", tags=["栈","出栈序列","计数"], task="计数首出3的全部四元素出栈序列", data="1,2,3,4依次入栈；每个恰入出各一次", minutes=2, level="基", rubric=pts(("共3种",3)), history_ids=["真题-2025-填空2","真题-2026-填空9"], source_ids=["真题-2025-填空2"], reference_alignment="2025 PDF p11填空2为指定首项的出栈序列数，2026回忆稿p4填空9亦为栈弹出序列。"),
    "S6-II04": dict(title="朴素模式匹配的比较次数", chapter="串", tags=["朴素匹配","重叠匹配","比较次数"], task="按朴素匹配逐起点求全部命中位置和比较次数", data="T=ababa，P=aba，0基且每个合法起点都比较", minutes=3, level="中", rubric=pts(("起点0、2",2),("总比较7次",1)), history_ids=[], source_ids=[], reference_alignment="2024–2026 PDF填空出现KMP next而非朴素逐起点比较；此题为本卷唯一朴素匹配创新位。"),
    "S6-II05": dict(title="广义表Head/Tail运算", chapter="数组广义表", tags=["广义表","Head","Tail"], task="计算Head(Tail(X))", data="X=((a,b),(c,d),e)", minutes=2, level="基", rubric=pts(("结果(c,d)",3)), history_ids=["真题-2025-填空7"], source_ids=["真题-2025-填空7"], reference_alignment="2025 PDF p11填空7直接考Head/Tail；2026回忆稿p4该题表达式缺失，不能引其数值。"),
    "S6-II07": dict(title="完全二叉树指定层叶数与最大规模", chapter="树", tags=["完全二叉树","叶结点","结点数"], task="由第4层恰有2叶求最大结点数", data="根第1层；完全二叉树", minutes=2, level="基", rubric=pts(("最大27个结点",3)), history_ids=["真题-2024-填空9"], source_ids=["真题-2024-填空9"], reference_alignment="2024 PDF p5填空9同为给定层叶数求完全二叉树最大结点数。"),
    "S6-II08": dict(source_ids=["真题-2025-填空10"], history_ids=["真题-2025-填空10","真题-2026-填空15"], reference_alignment="2025 PDF p11填空10同为小根堆插入后填写完整堆数组，换初堆和插入值；2026回忆稿p4填空15考上滤比较次数，仅作方法旁证。"),
    "S6-II09": dict(title="二叉链表空指针域个数", chapter="树", tags=["二叉链表","空指针","结点数"], task="由18结点求左右孩子空指针域数", data="普通二叉树18结点、每结点两个孩子指针", minutes=2, level="基", rubric=pts(("19个空指针域",3)), history_ids=["真题-2026-填空11"], source_ids=["真题-2026-填空11"], reference_alignment="2026回忆稿p4填空11同为n结点二叉树的空指针数。"),
    "S6-II10": dict(title="折半查找最多成功比较次数", chapter="查找", tags=["折半查找","最坏比较次数"], task="求180个有序键成功查找最多比较次数", data="180键；闭区间取下中点；每访问一键计一次比较", minutes=2, level="基", rubric=pts(("最多8次",3)), history_ids=["真题-2026-填空13"], source_ids=["真题-2026-填空13"], reference_alignment="2026回忆稿p4填空13为125个有序元素的折半最多成功比较次数；本题换成180键，同型巩固而非创新。"),
    "S6-III01": dict(title="Huffman树构造、编码与WPL", chapter="树", tags=["Huffman树","编码","WPL"], task="按给定左右约定构造Huffman树、列编码和WPL", data="A-F频率3,5,7,11,13,18", minutes=11, level="中", rubric=pts(("合并权8、15、24、33、57",3),("树形及6个编码",5),("WPL137",2)), history_ids=["真题-2024-综合5","真题-2025-综合3","真题-2026-综合22"], source_ids=["真题-2024-综合5"], reference_alignment="2024 PDF p6综合5、2025 PDF p12综合3、2026回忆稿p6综合22均为Huffman构造与编码。"),
    "S6-III02": dict(title="孩子兄弟表示还原森林与遍历", chapter="树", tags=["孩子兄弟","森林","后根遍历"], task="由left/right表还原森林并求遍历和深度", data="7结点孩子兄弟二叉树表", minutes=10, level="中", rubric=pts(("正确恢复森林",4),("森林后根遍历",3),("森林和二叉树最大深度",3)), history_ids=["真题-2024-填空8","真题-2026-综合16"], source_ids=[], reference_alignment="2024 PDF p5填空8为森林二叉树转换；2026回忆稿p5综合16含树与森林表示。"),
    "S6-III03": dict(title="由比较轨迹逆推折半查找判定树", chapter="查找", tags=["折半查找","判定树","逆推"], task="由查找28比较轨迹逆推下标、画树并求ASL", data="A[1..11]严格递增，已知A[6]=25、轨迹25,33,28", minutes=10, level="中", rubric=pts(("比较后的区间和33/28下标",4),("11结点下标判定树",3),("成功ASL",3)), history_ids=["真题-2026-综合23"], source_ids=[], reference_alignment="2026回忆稿p6综合23为折半判定树；比较轨迹反推是本卷指定创新位。"),
    "S6-III04": dict(title="BST、AVL与折半判定树的构造", chapter="查找", tags=["BST","AVL","折半查找","ASL"], task="同组键构造三种树并求各自成功ASL", data="插入30,10,20,50,40,60,70；数组1..7闭区间下中点", minutes=11, level="中", rubric=pts(("BST及ASL",3),("AVL及ASL",4),("折半树及ASL",3)), history_ids=["真题-2024-综合6","真题-2026-综合18"], source_ids=[], reference_alignment="2024 PDF p6综合6比较BST/折半/AVL；2026回忆稿p5综合18为BST/AVL构造。"),
    "S6-III05": dict(title="AOE事件活动时刻与关键路径", chapter="图", tags=["AOE","ve/vl","关键路径"], task="求事件、活动最早最晚时刻及关键路径", data="6顶点8活动的AOE网，起点0终点5", minutes=11, level="中", rubric=pts(("全部ve/vl和总工期",4),("8活动e/l",4),("关键活动和关键路径",2)), history_ids=["真题-2025-综合6","真题-2026-综合20"], source_ids=["真题-2025-综合6"], reference_alignment="2025 PDF p12综合6和2026回忆稿p5综合20均为AOE时刻表及关键路径。"),
    "S6-III06": dict(title="同图最小生成树与最短路径树", chapter="图", tags=["MST","单源最短路","树权比较"], task="分别构造MST和A源最短路径树并求权值", data="五顶点七边正权无向图", minutes=10, level="中", rubric=pts(("MST边集与总权",4),("A源四个距离",4),("一棵最短路径树边集和总权",2)), history_ids=["真题-2025-综合5","真题-2026-综合21"], source_ids=[], reference_alignment="2025 PDF p12综合5含MST，2026回忆稿p5-6综合21为Dijkstra；同图比较两树是本卷指定创新位。"),
    "S6-III07": dict(title="线性探测散列表构造与成功ASL", chapter="查找", tags=["线性探测","散列表","成功ASL"], task="依次插入建表、列探测次数并求成功ASL", data="m=11，H(k)=k mod11，键18,29,40,7,22,35,46", minutes=10, level="中", rubric=pts(("最终散列表",4),("逐键成功查找探测次数",3),("成功ASL=2",3)), history_ids=["真题-2024-综合2","真题-2026-综合17"], source_ids=["真题-2024-综合2"], reference_alignment="2024 PDF p5综合2为线性探测建表与ASL；2026回忆稿p5综合17为散列表构造。"),
    "S6-IV01": dict(title="有序单链表对称差", chapter="线性表", tags=["有序单链表","同步扫描","结点释放"], task="两条严格递增单链表原结点求对称差", data="A/B无头、不共享、各可空；公共键双结点释放", minutes=10, level="中", rubric=pts(("双链同步扫描思想",2),("原结点重连及公共键释放的C代码",4),("时间和辅助空间复杂度",2)), history_ids=["真题-2024-阅读3","真题-2026-阅读3"], source_ids=[], reference_alignment="2024 PDF p3阅读3有序链表归并与2026回忆稿p2阅读3有序链表交集，同表示同扫描方法；改目标为对称差，不照抄原功能。"),
    "S6-IV02": dict(title="先中序直接写后序序列", chapter="树", tags=["先中序","后序","递归"], task="由合法先中序直接输出后序数组，不建树结点", data="pre/in标识互异且合法，post容量≥n，n可为0", minutes=12, level="中", rubric=pts(("区间划分思想",2),("正确边界与输出顺序的C代码",6),("时间和辅助空间复杂度",2)), history_ids=["真题-2026-算法25"], source_ids=[], reference_alignment="2026回忆稿p7算法25由先中序重建树；新题不建树而直接输出后序，方法接近、功能不同。"),
    "S6-IV03": dict(title="增弧后的拓扑序与环分类", chapter="图", tags=["拓扑排序","可达性","环判定"], task="不改图，判增弧后原序可用、需重排或成环", data="原DAG已给合法完整拓扑序；新弧u→v允许自环", minutes=16, level="中", rubric=pts(("三类情况的判定思想",3),("处理位置与可达性的C代码",6),("时间和辅助空间复杂度",3)), history_ids=["真题-2026-算法26"], source_ids=[], reference_alignment="2026回忆稿p7算法26检验既有拓扑序；增弧后的三态分类是本卷指定创新位。"),
}

INNOVATION = {
    "S5-II07", "S5-III03", "S5-III07", "S5-IV03",
    "S6-II04", "S6-III03", "S6-III06", "S6-IV03",
}

NOVELTY = {
    "S5-II07": "目标变化", "S5-III03": "条件辨析",
    "S5-III07": "表示转换", "S5-IV03": "目标变化",
    "S6-II04": "目标变化", "S6-III03": "逆向推断",
    "S6-III06": "条件辨析", "S6-IV03": "目标变化",
}

ALIGN = {
    "S5-I01": "2025 PDF p8阅读1为递归复杂度；此题递归结构换数据。",
    "S5-I02": "2024 PDF p2阅读2及2025 PDF p8阅读2为链表补码；此题删除偶数结点。",
    "S5-I03": "2026回忆稿p2阅读2为共享双栈补码，改边界数据。",
    "S5-I04": "2026回忆稿p3阅读5为平衡树求高补码，改数据。",
    "S5-II02": "2024 PDF p5填空2为中缀转后缀，换表达式。",
    "S5-II03": "2024 PDF p5填空1为环队列容量/长度，同概念换约定。",
    "S5-II04": "2024 PDF p5填空3及2025 PDF p11填空8为KMP next，约定已明示。",
    "S5-II05": "2024 PDF p5填空6、2025 PDF p11填空3及2026回忆稿p4填空8均为数组地址；由给定地址逆求列数仍属同一行主序公式，非额外创新。",
    "S5-II06": "2025 PDF p11填空9为树度数与叶数；此题用二叉树结点数恒等式。",
    "S5-II07": "2026回忆稿p7算法26为拓扑序校验；本题小DAG拓扑序计数是指定创新位。",
    "S6-I01": "2024 PDF p2阅读1为循环复杂度；此题换循环增长结构。",
    "S6-I02": "2024 PDF p3阅读3为有序链表归并；此题逆序输出并强调结点不共享。",
    "S6-I03": "2024 PDF p4阅读5递归数叶与2026回忆稿p3阅读5树求高；本题按层累加叶数。",
    "S6-I04": "2024 PDF p3阅读4为拓扑排序补码；此题Kahn判定。",
    "S6-II01": "2024 PDF p5填空1为环队列指针差求长度。",
    "S6-II06": "2024 PDF p5填空7、8为树森林转换与结点计数。",
    "S6-II08": "2025 PDF p11填空10为小根堆插入后数组。",
}

def build_metadata() -> list[dict]:
    source_rows = json.loads(BLUEPRINT.read_text(encoding="utf-8"))
    by_id = {x["id"]: x for x in source_rows}
    result = []
    fields = ["id", "title", "chapter", "tags", "task", "data", "minutes", "level",
              "rubric", "history_ids", "mode", "source_ids", "task_family", "novelty_type"]
    for no in (5, 6):
        draft = json.loads((OUT / f"paper{no}.json").read_text(encoding="utf-8"))
        formal = {q["id"]: q for q in json.loads((FORMAL / f"第{no}套.json").read_text(encoding="utf-8"))["questions"]}
        for q in draft["questions"]:
            qid = q["id"]
            row = {key: by_id[qid][key] for key in fields}
            row.update(META.get(qid, {}))
            row["paper"] = no
            row["section"] = q["section"]
            row["number"] = q["number"]
            row["points"] = q["points"]
            row["innovation"] = qid in INNOVATION
            row["novelty_type"] = NOVELTY.get(qid, "平行练习")
            row["reference_alignment"] = row.get("reference_alignment", ALIGN.get(qid, "本题承接对应课内核心方法，尚需按原PDF逐项确认直接同型证据。"))
            row["change"] = ("v4题面已修订；见参考对齐说明。" if q["content"] != formal[qid]["content"] else "沿用v3题面。")
            row["student_content_sha256"] = hashlib.sha256(q["content"].encode("utf-8")).hexdigest()
            if qid in META:
                row["mode"] = "原创" if qid in INNOVATION else "改编"
            if qid.startswith(("S5-IV", "S6-IV")):
                row["task_family"] = "算法设计"
            elif qid.endswith(("I02", "I03", "I04")) and q["section"] == "I":
                row["task_family"] = "代码补全"
            elif q["section"] == "II":
                row["task_family"] = "过程追踪"
            elif qid in ("S5-III03", "S6-III06"):
                row["task_family"] = "性能比较"
            elif qid == "S6-III03":
                row["task_family"] = "逆向推断"
            elif qid in ("S5-III06", "S5-III07"):
                row["task_family"] = "过程追踪"
            else:
                row["task_family"] = "结构构造" if q["section"] == "III" else "复杂度分析"
            # No direct-source claim when the historical item only supports a method or chapter.
            if qid in ("S5-II01", "S5-II07", "S5-III03", "S5-III07", "S5-IV01", "S5-IV02", "S5-IV03",
                      "S6-I02", "S6-I03", "S6-II04", "S6-II06", "S6-III03", "S6-III06",
                      "S6-IV01", "S6-IV02", "S6-IV03"):
                row["source_ids"] = []
            if qid == "S5-II10":
                row["pdf_evidence"] = "真题资料/真题24-25.pdf 物理p5填空4、p11填空4；首条DB映射曾被发现错位，直接采用p11填空4的可核对原PDF。"
            result.append(row)
    assert len(result) == 48 and len({x["id"] for x in result}) == 48
    assert Counter((x["paper"], x["innovation"]) for x in result)[(5, True)] == 4
    assert Counter((x["paper"], x["innovation"]) for x in result)[(6, True)] == 4
    return result

def finalize_algorithm_review() -> None:
    path = OUT / "algorithm_review.json"
    report = json.loads(path.read_text(encoding="utf-8"))
    for row in report["items"]:
        if row["id"] == "S5-IV01":
            row.update(action="换为链表指针微迁移", topic="有序链表保留同键最后原结点",
                current_risk="原有序数组和为K计数在本校近三年IV没有同题型任务证据，且提示双指针方法。",
                exam_anchor="2025 p13链表定位、2026 p6约瑟夫的原链指针操作；本题目标不同。",
                proposal="带头结点的有序单链表允许重复和空表。设计void keepLastOfEachKey(Node *L)，对每种键值只保留其原链中的最后一个数据结点，释放同键其余结点；不新建数据结点。",
                api="typedef struct Node { int key; struct Node *next; } Node; void keepLastOfEachKey(Node *L);",
                expected_internal="遍历相邻同键段并释放前面重复结点；O(n)时间、O(1)辅助空间。",
                source_action="删除原校外FindSum直接来源；2025/26仅作链表方法锚点。")
        if row["id"] == "S5-IV03":
            row.update(topic="二叉树直径长度",
                proposal="普通二叉树以左右孩子指针存储。设计int treeDiameter(const Node *root)，只返回任意两结点之间最长简单路径的边数；空树、单结点返回0，不改动树。",
                api="typedef struct Node { struct Node *left, *right; } Node; int treeDiameter(const Node *root);",
                expected_internal="一次递归求最长路径长度；O(n)时间、O(h)递归栈，题面不提示合并方式。",
                time_minutes=15)
        if row["id"] == "S5-IV02":
            row.update(topic="DAG拓扑序合法前缀",
                proposal="有向无环图G采用邻接表存储。给定0≤k≤V且元素互异、合法的顶点序列P。设计bool canBePrefix(const Graph *G, const int P[], int k)，判断P能否作为某个完整拓扑序的前k项；k=0返回真，不修改G。",
                expected_internal="计算入度并按P依次检验当前是否可选；原图保证DAG，任一合法前缀均可补完；O(V+E)时间、O(V)辅助空间。",
                time_minutes=11)
        if row["id"] == "S6-IV01":
            row.update(action="改回同表示链表微迁移", topic="两有序链表对称差",
                exam_anchor="2024阅读3有序链表归并、2026阅读3链表交集；同表示同步扫描。",
                proposal="无头、互不共享且各严格递增的单链表A、B可为空。设计Node *symmetricDiff(Node *A, Node *B)，只保留恰出现于一表的键，原结点重连后仍严格递增；公共键对应两结点释放，不新建结点。",
                api="typedef struct Node { int key; struct Node *next; } Node; Node *symmetricDiff(Node *A, Node *B);",
                expected_internal="同步扫描两链，共同键双释放，其余原结点尾接；O(m+n)时间、O(1)辅助空间。",
                source_action="2024/26只作同表示同扫描方法锚点，不称原题功能相同。")
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# 六套算法设计题审查（18题）", "",
        "依据本地《真题24-25.pdf》2024物理p6、2025物理p13及2026回忆稿物理p6–7，并核对课件讲稿。2026资料为回忆版，具体数字和措辞需谨慎。所有建议均保持每套IV题8/10/12分，学生题面统一要求基本思想、C语言实现、时间与辅助空间复杂度，不拆小问。", "",
        "| 题号 | 处理 | 历年方法锚点 | 建议任务 |", "|---|---|---|---|",
    ]
    for x in report["items"]:
        proposal = x["proposal"].replace("|", "｜").replace("\n", " ")
        anchor = x["exam_anchor"].replace("|", "｜")
        lines.append(f"| {x['id']} | {x['action']} | {anchor} | {proposal} |")
    lines += ["", "## 核心审查结论", "",
              "- 三套保守卷的算法题沿近三年链表、树、图题的方法，但撤掉题面中的解题路线；避免重复倒数第k个、原版约瑟夫和原版拓扑序合法性判定。",
              "- 第5、6套各仅保留末题一个算法创新位。S5-IV01改为有序链表原结点去重，S5-IV02收窄为DAG合法前缀，S5-IV03仅求直径长度；S6-IV01为有序链表对称差，S6-IV02为双序写后序，两者均为同方法微迁移。",
              "- 本表是审查建议和草案依据，学生卷仍需独立核验程序契约、边界及作答量。", ""]
    (OUT / "algorithm_review.md").write_text("\n".join(lines), encoding="utf-8")

def write_checks(metadata: list[dict]) -> None:
    lines = [
        "# 第5、6套v4草案内部核查", "",
        "本文件为教师内部审查，不随学生卷发放；不提供成套答案。正式学生源稿、蓝图、PDF均未改动。", "",
        "## 结构与分值", "",
    ]
    for no in (5, 6):
        draft = json.loads((OUT / f"paper{no}.json").read_text(encoding="utf-8"))
        qs = draft["questions"]
        assert len(qs) == 24
        assert Counter(q["section"] for q in qs) == {"I": 4, "II": 10, "III": 7, "IV": 3}
        total = sum(q["points"] for q in qs)
        assert total == 150
        for q in qs:
            if q["section"] != "IV":
                assert sum(map(int, re.findall(r"（(\d+)分）", q["content"]))) == q["points"], q["id"]
            else:
                assert "请写出算法的基本思想、C语言实现，并分析时间复杂度和辅助空间复杂度。" in q["content"]
                assert not re.search(r"（\d+）", q["content"])
        lines.append(f"- 第{no}套：24题150分，I4×5、II10×3、III7×10、IV8/10/12；创新位恰4道。")
    lines += ["", "## 关键独立演算", "",
        "- S5-II08：折半查找26依次查下标8、12、14、13，共4次；S5-II09插2后堆为(2,7,3,10,9,8,5)；S5-II10由217结点得109叶。",
        "- S5-III01：树后序DEBFGCA；D中序前驱空、后继B，F前驱A、后继C。",
        "- S5-III02：10结点折半判定树各层结点数1/2/4/3，成功ASL=29/10；找57与找60都比较31、66、42、57。",
        "- S5-III03：原Huffman合并权6/13/23/38/63，WPL143；A频率增7后沿用旧码WPL178；重建合并权11/19/26/44/70，WPL170。",
        "- S5-II04模式abcabca的next数组为(0,1,1,1,2,3,4)，与第4套模式串不同；II05每行10列；II06二叉树总数18；II07拓扑序2种。",
        "- S5-III04普通BST成功ASL17/7；III05双散列逐键探测1/1/1/3/2/2/2，成功ASL12/7；III06图有3个分量、各森林4树边。",
        "- S5-III07：稳定次键排序后b,e,f,a,c,d；再按主键为b,f,d,e,c,a；若主键先排再按次键，最终b,f,e,d,c,a。相同双键b/f保留原次序。",
        "- S6-II02地址152；S6-II03首出3的完整序列数3（第1套亦有同型巩固题，非新创新）；S6-II04合法起点0、2，总字符比较7；S6-II07最大27结点；S6-II09空指针19；S6-II10对180键最多8次。",
        "- S6-II01环队列长度4；II05广义表运算结果(c,d)；II06孩子兄弟二叉树右空指针7；II08堆插1后为(1,7,2,9,8,6,4)。",
        "- S6-III01：Huffman合并权8/15/24/33/57，WPL=137。",
        "- S6-III02森林最大深度3、对应二叉树最大深度4；III04普通BST成功ASL18/7，最终AVL与折半树各17/7；III05工期9，两条关键路径0→1→3→5与0→2→4→5。",
        "- S6-III06最小生成树权8，A源最短路径树权9，距离B=2、C=3、D=6、E=7。",
        "- S6-III07：线性探测逐键成功探测1/2/3/4/1/1/2，总14，ASL=2。", "",
        "## 来源与难度边界", "",
        "- 题型依据按2024–2026原PDF同题型任务判断，不能把相同章节冒充相同题型；每套仅四个明确创新位。",
        "- 2026为回忆稿，个别题目原数据缺失。历史ID仅作方法锚点时，metadata56.json的source_ids清空。",
        "- 曾发现2024填空4的数据库导出与PDF错位；Huffman叶数题直接采用可核对的2025 PDF p11填空4作为source_id。",
        "- I代码沿v3主体，只精简阅读题干；III/IV压缩证明与提示。S5-IV02已收窄为DAG合法前缀，S6-IV01改回有序链表同表示扫描。估时为审稿估计，仍须限时试做验证。", "",
        "## 逐题目的与预计时间", "",
        "| 题号 | 考点/任务 | 预计分钟 | 难度 | 变化 |", "|---|---|---:|---|---|",
    ]
    for row in metadata:
        lines.append(f"| {row['id']} | {row['task']} | {row['minutes']} | {row['level']} | {'指定创新' if row['innovation'] else '同型练习/方法微迁移'} |")
    lines.append("")
    (OUT / "internal_checks56.md").write_text("\n".join(lines), encoding="utf-8")

def main() -> None:
    metadata = build_metadata()
    (OUT / "metadata56.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    finalize_algorithm_review()
    write_checks(metadata)
    print("metadata", len(metadata), "algorithm", 18)

if __name__ == "__main__":
    main()
