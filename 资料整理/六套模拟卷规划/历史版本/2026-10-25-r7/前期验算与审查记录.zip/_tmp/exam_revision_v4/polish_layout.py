from pathlib import Path
import json,hashlib,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'资料整理/六套模拟卷成稿';PLAN=ROOT/'资料整理/六套模拟卷规划';HERE=Path(__file__).parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'tools'));import build_exam_papers as b
from pypdf import PdfReader
changes={4:('S4-III02','先依次插入 10','\n\n先依次插入 10'),5:('S5-III07','若颠倒两趟的先后顺序，即先按第一关键字、再按第二关键字，写出最终记录标识序列。','若改为先按第一关键字、再按第二关键字排序，写出最终记录标识序列。'),6:('S6-II10','每轮使用闭区间 [lo,hi] 并取 mid=floor((lo+hi)/2)，','每轮取当前闭区间的中点，下标向下取整；')}
rows=read(PLAN/'六套逐题蓝图.json');byid={r['id']:r for r in rows};structure=read(OUT/'成卷结构核对.json');delta=[]
b.init_pdf()
for n,(qid,old,new) in changes.items():
    path=OUT/f'试题源稿/第{n}套.json';p=read(path);q=next(q for q in p['questions'] if q['id']==qid)
    assert old in q['content'];q['content']=q['content'].replace(old,new)
    write(path,p);byid[qid]['student_content_sha256']=hashlib.sha256(q['content'].encode('utf8')).hexdigest()
    dest=b.QA_DIR/f'重邮802模拟试卷第{n}套';before={x.name:sha(x) for x in dest.glob('page-*.png')}
    target=b.PDF_DIR/f'重邮802模拟试卷第{n}套.pdf';previous=sha(target)
    d=b.load_paper(n);assert not b.validate(d);b.check_font_coverage([d])
    spaces,qpages=b.build_pdf(d,target);b.render_pdf(target)
    (b.MD_DIR/f'第{n}套试卷.md').write_text(b.markdown(d),encoding='utf8')
    after={x.name:sha(x) for x in dest.glob('page-*.png')};assert set(before)==set(after)
    changed=[k for k in after if after[k]!=before[k]]
    delta.append({'paper':n,'previous_pdf_sha256':previous,'final_pdf_sha256':sha(target),'changed_render_pages':changed,'unchanged_render_pages':len(after)-len(changed)})
    s=next(x for x in structure['papers'] if x['paper']==n)
    s.update(pages=len(PdfReader(target).pages),answer_spaces=spaces,question_pages=qpages,source_sha256=sha(path))
write(PLAN/'六套逐题蓝图.json',rows);write(OUT/'成卷结构核对.json',structure)
audit=read(OUT/'内容复查核对.json')
for r in audit['records']+audit['changes']:r['student_sha256']=byid[r['id']]['student_content_sha256']
write(OUT/'内容复查核对.json',audit);b.merge_all();write(HERE/'visual_polish_delta.json',delta)
print(json.dumps(delta,ensure_ascii=False))
