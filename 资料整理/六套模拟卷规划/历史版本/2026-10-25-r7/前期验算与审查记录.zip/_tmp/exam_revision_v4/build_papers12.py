"""Draft conservative student papers in the temporary review area only."""
import copy
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
STUDENT = ROOT / "资料整理/六套模拟卷成稿/试题源稿"
BLUEPRINT = ROOT / "资料整理/六套模拟卷规划/六套逐题蓝图.json"

papers = {}
old_content = {}
for p in (1, 2):
    d = json.loads((STUDENT / f"第{p}套.json").read_text(encoding="utf-8"))
    papers[p] = d
    for q in d["questions"]:
        old_content[q["id"]] = q["content"]
    d["version"] = "2026-10-22-student-v4-conservative-draft"

questions = {q["id"]: q for d in papers.values() for q in d["questions"]}


def setq(qid, content):
    questions[qid]["content"] = content.strip()


def trim_intro(qid, intro):
    s = questions[qid]["content"]
    pos = s.index("```c")
    questions[qid]["content"] = intro + "\n\n" + s[pos:]


# I: 保留真题所见程序阅读任务，压缩解释性题干。第4题选树的递归统计/平衡判断。
trim_intro("S1-I01", "readings 存放 n=2^k（k≥1）个读数，outSum 有效。阅读程序并填写执行次数与复杂度。")
trim_intro("S1-I02", "带头结点的单链表中，p 是表内数据结点，s 是尚未入表的新结点。补全在 p 前插入 s 的代码。")
trim_intro("S1-I03", "循环单链队列只存尾指针 rear；空队列时 rear=NULL，出队结点由调用者管理。补全代码。")
trim_intro("S2-I01", "move 为一次 O(1) 的盘片移动；输入 n≥1。阅读程序并填写移动次数与复杂度。")
trim_intro("S2-I02", "双向链表局部为 x↔q↔p↔y，x、y 为哨兵。补全相邻数据结点 q、p 的交换代码。")
trim_intro("S2-I03", "两个栈共用长度为 6 的数组，左栈、右栈分别从数组两端增长。补全代码。")

setq("S1-I04", r"""
下列程序统计二叉树的叶结点数。空树的叶结点数为 0，叶结点的左右孩子均为空。补全代码。

```c
#include <stdio.h>
typedef struct TNode {
    int data;
    struct TNode *left, *right;
} TNode;
int leafCount(const TNode *t) {
    if (t == NULL) return __1__;
    if (t->left == NULL && t->right == NULL)
        return __2__;
    return __3__;
}
void report(const char *name, const TNode *root) {
    printf("%s: %d\n", name, leafCount(root));
}
int main(void) {
    TNode d = {4, NULL, NULL};
    TNode e = {5, NULL, NULL};
    TNode b = {2, &d, &e};
    TNode c = {3, NULL, NULL};
    TNode a = {1, &b, &c};
    report("tree", &a);
    report("single", &c);
    report("empty", NULL);
    return 0;
}
```

填写 __1__（1分）、__2__（1分）、__3__（3分），均为表达式。
""")

setq("S2-I04", r"""
下列程序在一次递归中检查二叉树是否平衡；高度指根到最深叶的结点数，空树高度为 0。补全代码。

```c
#include <stdio.h>
typedef struct TNode {
    struct TNode *left, *right;
} TNode;
int heightIfBalanced(const TNode *t) {
    if (t == NULL) return __1__;
    int a = heightIfBalanced(t->left);
    if (a < 0) return -1;
    int b = heightIfBalanced(t->right);
    if (b < 0) return -1;
    if (__2__) return -1;
    return __3__;
}
int balanced(const TNode *t) {
    return heightIfBalanced(t) >= 0;
}
int main(void) {
    TNode x = {NULL, NULL}, y = {NULL, NULL};
    TNode root = {&x, &y};
    TNode p = {NULL, NULL}, q = {&p, NULL};
    TNode chain = {&q, NULL};
    printf("%d %d %d\n", balanced(&root),
           balanced(&chain), balanced(NULL));
    return 0;
}
```

填写 __1__（1分）、__2__（2分）、__3__（2分），均为表达式。
""")

# II: 仅保留可判定的传统填空。每个空有明确分值。
setq("S1-II01", "将中缀表达式 (a+b)×c−d 按通常优先级和左结合性转换为后缀表达式，结果为 __1__（3分）。运算数之间用空格分隔。")
setq("S1-II02", "二维数组 A[1..4][0..5] 按行优先顺序连续存放，每个元素占 4 字节。A[1,0] 的起始地址为 1000，则 A[3,2] 的起始地址为 __1__（3分）。")
setq("S1-II04", "模式 P=ababaca，字符位置从 1 开始。设 π(i) 为 P[1..i] 最长的相等真前缀与后缀的长度，并规定 next[1]=0，j>1 时 next[j]=π(j−1)+1。则 next[5]=__1__（1分），next[7]=__2__（2分）。")
setq("S1-II07", "元素 1、2、3、4、5 按顺序入栈，允许在任意两次入栈之间弹栈，最终全部出栈。若第一个弹出的元素规定为 3，则不同的完整出栈序列共有 __1__ 种（3分）。")
setq("S1-II08", "依次向空 AVL 树插入 2、4、6、8、10、12、14。完成全部插入并按 AVL 规则调整后，平衡因子为 0 的结点共有 __1__ 个（3分）；平衡因子定义为左子树高度减右子树高度。")
setq("S1-II09", "大根堆的顺序表初值为 [90,70,80,20,50,60]，把关键字 85 插入末尾并逐层上滤。完成插入后根的左孩子为 __1__（1分），新关键字所在的数组下标为 __2__（2分）；数组下标从 1 开始。")
setq("S1-II10", "对 95 个互异关键字构成的升序表作折半查找。搜索区间为闭区间，mid=⌊(low+high)/2⌋，每访问一个中间关键字计一次比较。成功查找最多比较 __1__ 次关键字（3分）。")

setq("S2-II01", "按通常的二元运算规则，自左向右计算后缀表达式 8 3 − 2 × 4 +，其值为 __1__（3分）。运算符读入时先弹出右操作数。")
setq("S2-II02", "元素 1、2、3、4 依次入栈，允许在任意两次入栈之间弹栈，最终全部出栈。所有可能的不同出栈序列共有 __1__ 种（3分）。")
setq("S2-II03", "容量为 8 的循环队列留一个空槽，front 指向队首元素，rear 指向下一次入队位置。当前 front=6、rear=1，队中有 __1__ 个元素（1分）；此时再入队一个元素后 rear=__2__（2分）。")
setq("S2-II06", "一片森林共有 12 个结点和 9 条边，边均连接本森林内的父子结点。森林共有 __1__ 棵树（3分）。")
setq("S2-II07", "有 n 个结点的非空二叉链表，每个结点各有 left、right 两个孩子指针，整个结构没有共享结点。值为 NULL 的孩子指针共 __1__ 个（3分）。")
setq("S2-II08", "对 16 个不同关键字组成的升序顺序表做折半查找。搜索区间采用闭区间 [low,high]，mid=⌊(low+high)/2⌋；每轮与 A[mid] 作一次三路比较。一次成功查找最多比较 __1__ 次关键字（3分）。")
setq("S2-II09", "顺序表示的小根堆初值为 [10,20,15,40,30,25]，数组下标从 1 开始。插入 12 并逐层上滤，新关键字最终位于下标 __1__（1分），上滤过程中与父结点进行了 __2__ 次关键字比较（2分）。")
setq("S2-II10", "一棵严格二叉 Huffman 树有 15 个结点（每个非叶结点恰有两个孩子），其中叶结点有 __1__ 个（3分）。")

# III: 直接构造、计算、列过程；删除诊错和性质解释小问。
setq("S1-III01", """
二叉树的先序序列为 ABDECFG，中序序列为 DBEACGF。结点关键字互异。中序线索化时，仅用原本为空的孩子指针存前驱或后继；标志 0 表示孩子指针，1 表示线索，不设置头结点。

（1）画出重建的二叉树，或用“结点:左孩子,右孩子”（空写 ∅）列出结构。（4分）
（2）写出后序遍历序列。（2分）
（3）分别给出结点 C、G 在线索化后的左、右指针所指结点及对应标志；不存在的前驱/后继记 ∅。（4分）
""")

setq("S1-III02", """
符号 A、B、C、D、E 的出现频率依次为 3、5、7、9、20。按 Huffman 方法，每次取当前权值最小的两个结点合并；两子树权值相同则按其最小符号的字母序选择，左边标 0、右边标 1。

（1）按先后顺序列出每次合并的两个权值及合并后权值。（3分）
（2）画出 Huffman 树，或列出 A～E 的一组对应码字。（5分）
（3）求带权路径长度 WPL。（2分）
""")

setq("S1-III03", """
散列表长 m=11，地址为 0～10，散列函数 H(key)=key mod 11。按 14、25、36、5、16 的顺序插入，冲突时线性探测；空槽记“—”。成功查找的五个关键字等概率；失败查找的 11 个起始散列地址等概率，探测到首个空槽也计 1 次。

（1）写出插入完成后全部 0～10 号槽的内容。（4分）
（2）列出五个成功查找的探测次数，求成功 ASL。（3分）
（3）列出或分组给出 11 个起始地址的失败探测次数，求失败 ASL。（3分）
""")

setq("S1-III04", """
升序表为 [4,9,13,18,25,29,35,41,50,58]，下标从 0 开始。按闭区间折半查找，mid=⌊(low+high)/2⌋；每访问一个中间关键字并比较一次，区间变空即判失败。

（1）画出成功查找判定树，或用“结点:左孩子,右孩子”（空写 ∅）列出结构。（5分）
（2）各关键字等概率被查找时，求成功 ASL，写出按比较次数分组的计算式。（3分）
（3）查找不存在的 27 时，按顺序写出比较过的关键字和比较次数。（2分）
""")

setq("S1-III05", """
无向连通带权图的顶点为 A、B、C、D、E、F，全部边及权值如下，未列出的边不存在。边权互异。

| 边 | AB | AC | BC | BD | CD | CE | DE | DF | EF |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 权值 | 2 | 5 | 3 | 7 | 4 | 8 | 6 | 9 | 1 |

（1）从 A 出发，按加入顺序列出 Prim 算法选取的 5 条边。（5分）
（2）按考虑权值由小到大，列出 Kruskal 算法纳入最小生成树的 5 条边。（3分）
（3）求最小生成树总权值。（2分）
""")

setq("S1-III06", """
向空二叉排序树依次插入 30、10、20、40、35，关键字互异。另从空树开始按相同顺序插入 AVL 树；两棵树分别构造，互不影响。查找成功的五个关键字等概率，每访问一个结点算一次比较。

（1）画出普通二叉排序树，并列出其中五个关键字的成功查找比较次数。（3分）
（2）求普通二叉排序树的成功 ASL。（2分）
（3）按插入顺序写出 AVL 树每次发生的失衡类型，并画出全部插入完成后的 AVL 树。（5分）
""")

setq("S1-III07", """
数组 A=[42,17,63,28,9,54,31,22]，下标从 0 开始。甲、乙分别从原数组开始，互不影响。

甲：以首元素为枢轴，仅执行如下“挖坑”式快速排序的一趟划分：
```c
int pivot=A[0], i=0, j=7;
while (i<j) {
    while (i<j && A[j]>=pivot) --j;
    if (i<j) A[i++]=A[j];
    while (i<j && A[i]<=pivot) ++i;
    if (i<j) A[j--]=A[i];
}
A[i]=pivot;
```
乙：按从最后一个非叶结点到根的顺序，自下而上筛选建小根堆；两个孩子都存在时选较小者。

（1）写出甲结束后的完整数组及枢轴最终下标。（5分）
（2）写出乙结束后的完整数组。（5分）
""")

setq("S2-III01", """
有序森林有结点 A～I，下表给出各结点的父结点；“—”表示根。根从左到右为 A、F；同一父结点的孩子按字母序从左到右排列。

| 结点 | A | B | C | D | E | F | G | H | I |
|---|---|---|---|---|---|---|---|---|---|
| 父结点 | — | A | A | B | B | — | F | G | F |

按“第一个孩子为左孩子、下一个兄弟为右孩子”转换为二叉链表。

（1）列出转换后每个结点的左孩子、右孩子，空指针写 ∅。（4分）
（2）写出原森林的先根和后根遍历序列。（4分）
（3）写出原森林的根数、边数。（2分）
""")

setq("S2-III02", """
升序表为 [3,8,12,17,21,26,31,44]，下标从 0 开始。按闭区间折半查找，mid=⌊(low+high)/2⌋；每访问一个中间关键字算一次比较，区间变空即判失败。成功查找时八个关键字等概率；失败查找时九个相邻关键字之间及两端的间隙等概率。

（1）画出成功查找判定树，或用“结点:左孩子,右孩子”（空写 ∅）列出结构。（4分）
（2）求成功 ASL，写出按比较次数分组的计算式。（3分）
（3）求失败 ASL，写出九个失败间隙的比较次数或等价分组。（3分）
""")

setq("S2-III03", """
散列表长 m=11，H(key)=key mod 11。依次插入 12、23、34、4、15、26、7。分别采用线性探测与拉链法，两个表互不影响。线性探测地址循环；查找失败到首个空槽也计一次。拉链法把冲突结点接在桶链尾，失败查找只计实际比较过的关键字，空桶计 0 次。成功查找的七个关键字等概率；失败查找的 11 个起始散列地址等概率。

（1）写出线性探测完成后的 0～10 号槽，以及拉链法的全部非空桶链。（4分）
（2）分别求两种方法的成功 ASL，写出关键字比较次数或等价分组。（3分）
（3）分别求两种方法的失败 ASL，写出各起始地址比较次数或等价分组。（3分）
""")

setq("S2-III04", """
有向带权图的顶点为 A、B、C、D、E、F；F 是孤立顶点。全部弧及权值如下，未列出的弧不存在。以 A 为源点执行 Dijkstra 算法；暂定距离相同先确定字母较小的顶点。

| 弧 | A→B | A→C | B→C | B→D | C→D | C→E | D→E |
|---|---:|---:|---:|---:|---:|---:|---:|
| 权值 | 0 | 4 | 2 | 7 | 1 | 6 | 3 |

（1）逐轮写出选入已确定集合 S 的顶点，并在松弛其出弧后列出 B、C、D、E、F 的暂定距离；未可达记 ∞。只列可达顶点被选入的轮次。（6分）
（2）写出 A 到所有顶点的最终最短距离，不可达写 ∞。（2分）
（3）写出 A 到 E 的一条最短路径。（2分）
""")

setq("S2-III05", """
AOE 网以事件 0 为唯一源点、事件 5 为唯一汇点，活动与持续时间如下。未列出的活动不存在。

| 活动 | A | B | C | D | E | F | G | H |
|---|---|---|---|---|---|---|---|---|
| 弧 | 0→1 | 0→2 | 1→3 | 1→4 | 2→3 | 1→5 | 3→5 | 4→5 |
| 持续时间 | 3 | 2 | 2 | 3 | 4 | 3 | 2 | 1 |

（1）写出事件 0～5 的最早发生时间 ve。（3分）
（2）写出事件 0～5 的最迟发生时间 vl。（3分）
（3）求工期，列出关键活动和全部关键路径。（4分）
""")

setq("S2-III06", """
符号 A、B、C、D、E、F 的频率依次为 2、3、4、7、8、12。构造 Huffman 树时每次合并当前权值最小的两个结点；同权时按包含的最小符号字母序选择，左边标 0、右边标 1。

（1）按顺序列出每次合并的两个权值及合并后权值。（3分）
（2）画出 Huffman 树，或列出 A～F 的一组码字。（5分）
（3）求带权路径长度 WPL。（2分）
""")

setq("S2-III07", """
关键字序列 A=[53,17,72,24,36,91,45,68]，两个处理分别从原序列开始，按升序排列，互不影响。

甲采用稳定的 LSD 基数排序，基数为 10，先按个位再按十位分配与收集；每次按桶号从小到大收集，桶内保留原次序。分别写出第一、第二趟收集后的完整序列。（5分）

乙采用 Shell 排序，增量依次为 4、2；每趟对增量相隔的各子序列做直接插入排序。分别写出增量 4 和增量 2 两趟结束后的完整序列。（5分）
""")

# IV: 本校所考的链、树、图能力作轻量任务迁移；学生题面不预设算法路线。
setq("S1-IV01", """
两个带头结点的单链表 A、B 均按 data 严格递增，且没有共享结点。设计函数求差集 A\\B：删除 A 中所有关键字也在 B 中的原结点并释放它们；A 中保留的结点保持原先顺序，不新建数据结点，B 不变。空表允许，A 的头结点地址不变。

```c
typedef struct Node {
    int data;
    struct Node *next;
} Node;
void listDifference(Node *A, const Node *B);
```

请写出算法的基本思想、C语言实现，并分析时间复杂度和辅助空间复杂度。
""")

setq("S1-IV02", """
一棵非空二叉树的结点 data 是整数，可为负数。设计函数求从根到某个叶结点的最大结点权值和，并把对应路径上的 data 按从根到叶的顺序写入 path；若多条路径的权值和并列，输出任意一条。path 的容量至少为结点总数，pathLen 为有效指针；函数返回最大权值和。叶结点的两个孩子均为空。

```c
typedef struct TNode {
    int data;
    struct TNode *left, *right;
} TNode;
int maxRootLeafSum(const TNode *root, int *path, int *pathLen);
```

请写出算法的基本思想、C语言实现，并分析时间复杂度和辅助空间复杂度。
""")

setq("S1-IV03", """
无向简单图 G 用邻接表存储，顶点编号 0～V−1（1≤V≤100）。给定互不相同的合法顶点 s、t、w。设计函数找一条从 s 到 t、途中完全不经过 w、顶点不重复的路径。找到时将完整顶点序列写入容量至少 V 的 path，并把结点数写入 pathLen，返回 1；不存在时令 *pathLen=0，返回 0。无向边在两个端点的链表中各出现一次；E 表示无向边数。

```c
typedef struct Arc {
    int to;
    struct Arc *next;
} Arc;
typedef struct {
    int V, E;
    Arc **head;
} Graph;
int pathAvoidingVertex(const Graph *G, int s, int t, int w,
                       int *path, int *pathLen);
```

请写出算法的基本思想、C语言实现，并分析时间复杂度和辅助空间复杂度。
""")

setq("S2-IV01", """
带头结点的单链表存放整数。设计函数把全部负数结点稳定地移到全部非负数结点之前：两类结点各自的原相对次序必须保留。仅重连原有数据结点，不新建数据结点；头结点地址 L 保持不变。空表及只有一类结点的表也应正确处理。

```c
typedef struct Node {
    int data;
    struct Node *next;
} Node;
void stableNegFirst(Node *L);
```

请写出算法的基本思想、C语言实现，并分析时间复杂度和辅助空间复杂度。
""")

setq("S2-IV02", """
普通二叉树的每个结点带有 count 字段。设计函数在每个结点的 count 中写入“以该结点为根的子树的叶结点数”；叶结点的左右孩子均为空，空树无需写入。不得改变树的孩子指针。

```c
typedef struct TNode {
    int data;
    int count;
    struct TNode *left, *right;
} TNode;
void fillLeafCounts(TNode *root);
```

请写出算法的基本思想、C语言实现，并分析时间复杂度和辅助空间复杂度。
""")

setq("S2-IV03", """
无向简单图 G 用邻接表存储，顶点编号 0～V−1（1≤V≤100）。输入合法顶点 s、t（允许相同）和整数 k。设计函数寻找一条从 s 到 t、顶点不重复且边数不超过 k 的路径；找到时把完整顶点序列写入容量至少 V 的 path，将结点数写入 pathLen，返回 1。找不到或 k<0 时令 *pathLen=0，返回 0。无向边在两个端点的邻接链表中各出现一次，E 是无向边数。

```c
typedef struct Arc {
    int to;
    struct Arc *next;
} Arc;
typedef struct {
    int V, E;
    Arc **head;
} Graph;
int pathAtMostK(const Graph *G, int s, int t, int k,
                int *path, int *pathLen);
```

请写出算法的基本思想、C语言实现，并分析时间复杂度和辅助空间复杂度。
""")

# Metadata uses only meaningfully matching local 802 history anchors. The 2024
# fill-4 database record is corrupt (matrix instead of Huffman) and is not used.
META = {
    "S1-I01": ("循环访问次数与复杂度", "绪论", "循环频度,时间复杂度", "阅读几何增长的双层循环并填写次数和复杂度", 6, "中", "真题-2024-阅读1,真题-2025-阅读1"),
    "S1-I02": ("单链表指定结点前插补码", "线性表", "单链表,指针重连", "补全前驱遍历与前插链接", 6, "基", "真题-2024-阅读2"),
    "S1-I03": ("循环单链队列补码", "栈队列", "链队列,循环链表", "补全仅尾指针队列入队和出队", 7, "中", "真题-2025-阅读3"),
    "S1-I04": ("递归统计二叉树叶数", "树", "二叉树,递归,叶结点", "补全叶结点计数递归代码", 5, "基", "真题-2024-阅读5"),
    "S1-II01": ("中缀表达式转后缀", "栈队列", "表达式,后缀式", "写出确定的后缀表达式", 2, "基", "真题-2024-填空2"),
    "S1-II02": ("二维数组行优先地址", "数组广义表", "数组地址,行优先", "计算给定元素地址", 2, "基", "真题-2024-填空6,真题-2025-填空3,真题-2026-填空8"),
    "S1-II03": ("循环队列长度与满条件", "栈队列", "循环队列,队长", "计算队长并写满条件", 2, "基", "真题-2024-填空1,真题-2026-填空7"),
    "S1-II04": ("KMP next数值", "串", "KMP,next", "按明示定义计算两个next值", 2, "中", "真题-2024-填空3,真题-2025-填空8"),
    "S1-II05": ("广义表Head与Tail", "数组广义表", "广义表,Head,Tail", "计算广义表嵌套操作结果", 2, "基", "真题-2025-填空7,真题-2026-填空14"),
    "S1-II06": ("完全二叉树结点上界", "树", "完全二叉树,叶结点", "由倒数第二层叶数求最多结点", 2, "中", "真题-2024-填空9"),
    "S1-II07": ("限制首个弹出元素的出栈序列数", "栈队列", "栈,出栈序列", "计算首个弹出元素固定时的完整出栈序列数量", 3, "中", "真题-2025-填空2,真题-2026-填空9"),
    "S1-II08": ("AVL插入后的平衡因子计数", "查找", "AVL树,平衡因子", "计算逐键插入并调整后的零平衡因子结点数", 2, "中", "真题-2024-填空5"),
    "S1-II09": ("大根堆插入上滤", "排序", "大根堆,插入", "计算新关键字上滤后的结构位置", 2, "基", "真题-2025-填空10,真题-2026-填空15"),
    "S1-II10": ("折半成功比较上界", "查找", "折半查找,比较次数", "求固定规模成功查找最多比较次数", 2, "中", "真题-2026-填空13"),
    "S1-III01": ("遍历重建与中序线索", "树", "先中序重建,后序遍历,中序线索", "重建二叉树并求遍历、指定线索", 12, "中", "真题-2024-综合3,真题-2025-综合1"),
    "S1-III02": ("Huffman构造与编码", "树", "Huffman树,Huffman编码,WPL", "列合并过程、编码和带权路径长度", 10, "中", "真题-2024-综合5,真题-2025-综合3,真题-2026-综合22"),
    "S1-III03": ("线性探测散列表与ASL", "查找", "散列表,线性探测,ASL", "插入散列表并计算成功和失败ASL", 10, "中", "真题-2024-综合2,真题-2026-综合17"),
    "S1-III04": ("折半判定树与查找长度", "查找", "折半查找,判定树,ASL", "构造判定树、成功ASL及具体失败轨迹", 10, "中", "真题-2025-综合4,真题-2026-综合23"),
    "S1-III05": ("Prim与Kruskal生成树", "图", "最小生成树,Prim,Kruskal", "按两种算法列出最小生成树选择顺序", 12, "中", "真题-2025-综合5"),
    "S1-III06": ("BST与AVL插入构造", "查找", "BST,AVL,ASL", "构造普通BST和AVL并计算成功ASL", 10, "中", "真题-2024-综合6,真题-2026-综合18"),
    "S1-III07": ("快速划分与建小根堆", "排序", "快速排序,小根堆", "写一趟快速划分及自下而上建堆结果", 12, "中", "真题-2024-综合1"),
    "S1-IV01": ("有序链表原结点差集", "线性表", "有序链表,指针重连,差集", "求原结点A\\B且保留A顺序", 13, "中", "真题-2026-阅读3"),
    "S1-IV02": ("根叶路径最大权值和", "树", "二叉树,根叶路径,权值", "输出权值和最大的根叶路径及总和", 15, "中上", "真题-2025-算法2"),
    "S1-IV03": ("避开禁用顶点的图路径", "图", "邻接表,简单路径,DFS", "输出s到t且不经过w的一条简单路径", 19, "中上", "真题-2025-算法3"),
    "S2-I01": ("汉诺塔递归次数与复杂度", "绪论", "递归,汉诺塔,时间复杂度", "阅读程序求移动次数、递推及复杂度", 6, "中", "真题-2025-阅读1"),
    "S2-I02": ("双向链表相邻结点交换补码", "线性表", "双向链表,指针重连", "补全双链表邻接结点交换的链接", 6, "中", "真题-2025-阅读2"),
    "S2-I03": ("共享双栈边界与进出栈补码", "栈队列", "共享栈,边界", "补全共享双栈判满和右栈进出", 7, "中", "真题-2026-阅读2"),
    "S2-I04": ("平衡树求高代码补全", "树", "二叉树,平衡,递归", "补全一次后序递归求高兼查平衡", 6, "中", "真题-2026-阅读5"),
    "S2-II01": ("后缀表达式求值", "栈队列", "后缀式,表达式求值", "计算给定后缀表达式值", 2, "基", "真题-2025-填空5,真题-2026-填空6"),
    "S2-II02": ("栈弹出序列数", "栈队列", "栈,出栈序列", "计算四元素合法出栈序列数", 2, "中", "真题-2025-填空2"),
    "S2-II03": ("循环队列指针更新", "栈队列", "循环队列,队长,入队", "求环队列当前长度与一次入队后的rear", 2, "基", "真题-2024-填空1,真题-2026-填空7"),
    "S2-II04": ("KMP next与前缀函数", "串", "KMP,next,前缀函数", "按明示定义求模式串next和π", 2, "中", "真题-2024-填空3,真题-2025-填空8"),
    "S2-II05": ("三维数组行优先寻址", "数组广义表", "数组地址,行优先", "由数组下界和元素长度求目标地址", 2, "中", "真题-2025-填空3"),
    "S2-II06": ("森林树数与边数", "树", "森林,结点数,边数", "由森林结点数与边数求树数", 2, "基", "真题-2025-填空6"),
    "S2-II07": ("二叉链表空指针计数", "树", "二叉链表,空指针", "由结点数求二叉链表空指针数量", 2, "基", "真题-2026-填空11"),
    "S2-II08": ("折半成功比较上界", "查找", "折半查找,比较次数", "求固定规模成功查找最多比较次数", 2, "中", "真题-2026-填空13"),
    "S2-II09": ("小根堆插入比较次数", "排序", "小根堆,插入,比较次数", "求新关键字插入后的下标及上滤比较次数", 2, "中", "真题-2025-填空10,真题-2026-填空15"),
    "S2-II10": ("严格二叉Huffman树叶数", "树", "Huffman树,叶结点", "由Huffman树总结点数求叶数", 2, "基", "真题-2025-填空4"),
    "S2-III01": ("森林孩子兄弟表示与遍历", "树", "森林,孩子兄弟,遍历", "写二叉链表示、先根和后根序列、根边计数", 11, "中", "真题-2025-综合1,真题-2026-综合16"),
    "S2-III02": ("折半判定树与成功失败ASL", "查找", "折半查找,判定树,ASL", "构造折半判定树并算成功/失败ASL", 10, "中", "真题-2025-综合4,真题-2026-综合23"),
    "S2-III03": ("开放定址与拉链散列", "查找", "散列表,线性探测,拉链,ASL", "构造两类散列表并计算成功/失败ASL", 12, "中上", "真题-2026-综合17"),
    "S2-III04": ("Dijkstra逐轮最短路径", "图", "Dijkstra,暂定距离,最短路径", "逐轮列确定顶点与暂定距离，再求最终距离和路径", 13, "中", "真题-2026-综合21"),
    "S2-III05": ("AOE关键路径计算", "图", "AOE,ve,vl,关键路径", "算事件时刻、工期、关键活动和路径", 12, "中", "真题-2025-综合6,真题-2026-综合20"),
    "S2-III06": ("Huffman树构造与WPL", "树", "Huffman树,编码,WPL", "列合并过程、码字及WPL", 10, "中", "真题-2024-综合5,真题-2025-综合3,真题-2026-综合22"),
    "S2-III07": ("基数与Shell排序过程", "排序", "LSD基数排序,Shell排序", "给出基数和Shell各两趟执行结果", 12, "中", "真题-2024-综合1"),
    "S2-IV01": ("单链表稳定负数分段", "线性表", "单链表,稳定分段,指针重连", "原结点稳定分为负数与非负数两段", 13, "中", "真题-2026-阅读3"),
    "S2-IV02": ("二叉树各子树叶数", "树", "二叉树,递归,叶结点计数", "为每个结点填其子树叶数", 15, "中", "真题-2024-阅读5"),
    "S2-IV03": ("至多k边的简单图路径", "图", "邻接表,路径,长度上界", "找s到t边数不超过k的一条简单路径", 18, "中上", "真题-2024-算法2"),
}

assert len(META) == 48 and set(META) == set(questions)
anchors = json.loads(BLUEPRINT.read_text(encoding="utf-8"))
anchors = {r["id"]: r for r in anchors if r["id"] in questions}


def pdf_evidence(history_id):
    m = re.fullmatch(r"真题-(20\d\d)-(阅读|填空|综合|算法)(\d+)", history_id)
    if not m:
        raise ValueError(history_id)
    year, sec, no = int(m[1]), m[2], int(m[3])
    if year == 2024:
        path = "真题资料/真题24-25.pdf"
        page = {"阅读": 2 if no <= 2 else 3 if no == 3 else 4,
                "填空": 5, "综合": 5 if no <= 3 else 6, "算法": 6}[sec]
    elif year == 2025:
        path = "真题资料/真题24-25.pdf"
        page = {"阅读": 8 if no <= 2 else 9 if no == 3 else 10,
                "填空": 10 if no == 1 else 11,
                "综合": 11 if no <= 2 else 12, "算法": 13}[sec]
    else:
        path = "真题资料/26重邮208数据结构真题回忆版.pdf"
        page = {"阅读": 1 if no <= 2 else 2 if no == 3 else 3 if no == 4 else 4,
                "填空": 4, "综合": 5 if no <= 20 else 6,
                "算法": 6 if no <= 25 else 7}[sec]
    return {"year": year, "path": path, "pdf_page": page, "question": f"{sec}{no}"}


def scored_rubric(content):
    items = []
    cursor = 0
    for m in re.finditer(r"（(\d+)分）", content):
        segment = content[cursor:m.start()].strip()
        cursor = m.end()
        if "（" in segment:
            segment = re.split(r"（[1-9]）", segment)[-1]
        if "```" in segment:
            segment = segment.rsplit("```", 1)[-1]
        label = segment.strip(" ；，、。\n")[-65:]
        items.append([label, int(m[1])])
    return items


metadata = {}
for qid, vals in META.items():
    title, chapter, tags, task, minutes, level, hist = vals
    q = questions[qid]
    old = anchors[qid]
    historical = [v for v in hist.split(",") if v]
    novel = q["section"] == "IV"
    row = copy.deepcopy(old)
    row.update({
        "title": title, "chapter": chapter, "tags": tags.split(","),
        "task": task, "data": q["content"].split("\n", 1)[0][:220],
        "minutes": minutes, "level": level,
        "rubric": ([["针对本题输入输出的基本思想", max(1, q["points"] // 5)],
                    [task + "的C语言实现与边界", q["points"] - max(1, q["points"] // 5) - 2],
                    ["时间与辅助空间复杂度", 2]] if novel else
                   scored_rubric(q["content"])),
        "history_ids": historical, "source_ids": ([] if novel else historical),
        "mode": "改编", "task_family": ("复杂度分析" if q["section"] == "I" and q["number"] == 1
                      else "代码补全" if q["section"] == "I"
                      else "数值填空" if q["section"] == "II"
                      else "构造计算" if q["section"] == "III" else "算法设计"),
        "novelty_type": ("目标变化" if novel and q["number"] != 3 else
                         "条件辨析" if novel else "平行练习"),
        "reference_alignment": {
            "same_task": not novel,
            "evidence": [pdf_evidence(h) for h in historical],
            "note": ("仅继承相邻的链/树/图方法，具体输出目标或约束已改变；不宣称真题原任务复现。"
                     if novel else "对应本校近三年可见的同型作答任务；只换数据和完整题面语境，不宣称创新。")
        },
        "innovation": False,
        "change": ("保守卷v4：" + ("经典算法功能换为邻近核心任务，删除预给解法的分项。" if novel else
                          "对齐本校802真实题型，改为直接代码补全、确定填空或构造计算。")),
        "answer_blueprint": "旧版答案骨架停用；审定题面后另编答案与评分。",
        "design_version": "2026-10-22-r6-conservative-draft",
    })
    row.pop("student_content_sha256", None)
    metadata[qid] = row

for p, d in papers.items():
    assert len(d["questions"]) == 24
    counts = {sec: sum(q["section"] == sec for q in d["questions"]) for sec in "IV"}
    assert counts == {"I": 4, "V": 0} if False else True
    assert [sum(q["section"] == sec for q in d["questions"]) for sec in ("I", "II", "III", "IV")] == [4, 10, 7, 3]
    assert [sum(q["points"] for q in d["questions"] if q["section"] == sec) for sec in ("I", "II", "III", "IV")] == [20, 30, 70, 30]
    for q in d["questions"]:
        marks = sum(map(int, re.findall(r"（(\d+)分）", q["content"])))
        if q["section"] == "IV":
            assert marks == 0 and "（1）" not in q["content"], q["id"]
        else:
            assert marks == q["points"], (q["id"], marks, q["points"])
        if q["section"] == "II":
            assert "Θ(" not in q["content"] and "O(" not in q["content"] and "请说明" not in q["content"], q["id"]
        if q["section"] == "III":
            assert not any(t in q["content"] for t in ("说明原因", "解释为何", "简述为何")), q["id"]
    (OUT / f"paper{p}.json").write_text(json.dumps(d, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

(OUT / "metadata12.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("wrote 2 papers and 48 metadata rows")
