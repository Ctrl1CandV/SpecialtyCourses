from pathlib import Path
import hashlib, json, shutil

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
OUT = ROOT / '资料整理/六套模拟卷成稿'
PLAN = ROOT / '资料整理/六套模拟卷规划'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def digest(text): return hashlib.sha256(text.encode('utf8')).hexdigest()

oldrows=read(PLAN/'六套逐题蓝图.json')
assert all(r['design_version']=='2026-10-22-r5' for r in oldrows), 'Run migration once only'
oldq={q['id']:q for p in range(1,7) for q in read(OUT/f'试题源稿/第{p}套.json')['questions']}
patches={}
for suffix in ('12','34','56'):
    data=read(HERE/f'metadata{suffix}.json')
    if isinstance(data,dict):
        data=(list(data.values()) if all(str(k).startswith('S') for k in data)
              else data.get('questions',data.get('patches',data.get('rows'))))
    assert isinstance(data,list) and len(data)==48, suffix
    for r in data:
        assert r['id'] not in patches
        patches[r['id']]=r
papers=[read(HERE/f'paper{p}.json') for p in range(1,7)]
newq={q['id']:q for p in papers for q in p['questions']}
assert set(oldq)==set(newq)==set(patches) and len(newq)==144
rows=[];changes=[]
for old in oldrows:
    qid=old['id']; q=newq[qid]; patch=patches[qid]
    for key in ('title','chapter','tags','task','data','minutes','level','rubric','history_ids','mode','source_ids','task_family','novelty_type','reference_alignment','innovation','change'):
        assert key in patch,(qid,key)
    row=old.copy();row.update(patch)
    alignment=row['reference_alignment']
    if isinstance(alignment,dict):
        row['pdf_evidence']=alignment.get('evidence',[])
        refs='；'.join(f"{e['year']}年 {e['path']} PDF第{e['pdf_page']}页 {e.get('question','')}"
                      for e in row['pdf_evidence'])
        row['reference_alignment']=refs+'。'+alignment.get('note','')
        row['reference_same_task']=alignment.get('same_task')
    if row['section']=='I' and row['number']==1:
        row['mode']='原创';row['source_ids']=[]
        row['reference_alignment']+=' 对应复杂度程序阅读形式，具体代码另编。'
    row.pop('student_version',None)
    row['change']='旧任务「'+old['title']+'」调整为「'+row['title']+'」。'+row['change']
    row['design_version']='2026-10-22-r6'
    row['review_version']='2026-10-22-quality-v4'
    row['paper_profile']='保守卷' if row['paper']<=3 else '适度创新卷'
    row['student_content_sha256']=digest(q['content'])
    row['answer_blueprint']='用户审定第4版题面后再制作答案、C参考实现及详细评分细则；旧版答案骨架停用。'
    row['scope']='考纲内常考基础方法；依本轮分组及802真题任务依据选题'
    row['objective']=row['task']
    row['evidence_required']='；'.join(str(p[0]) for p in row['rubric'])
    row['misconception']='重点检查题面约定、边界与所求结果；不以开放的操作描述代替明确答案。'
    row['transfer']=row['reference_alignment']
    row['time_reason']=f"审稿估计{row['minutes']}分钟，依据当前题面；尚未经考生限时试做。"
    row['revision_note']='2026-10-22第4版：'+row['change']
    row['source_review_note']='强参考仅限2024—2026本校802；原PDF与库内转录冲突时以原PDF为准，具体同型或微迁移关系见reference_alignment。'
    row['exposure']={'status':'已排除点名的经典原题功能；实际授课重复仍需结合发放记录核查','references':[],
                     'response':'倒数第k个、原版约瑟夫和原版BST判定不作为本轮算法设计题。保留基础方法练习，不据课件标签宣称新任务未讲过。'}
    rows.append(row)
    if oldq[qid]['content']!=q['content']:
        changes.append({'id':qid,'change':row['change'],'before_sha256':digest(oldq[qid]['content']),
                        'student_sha256':digest(q['content'])})

for p in papers:
    assert len(p['questions'])==24
    p['version']='2026-10-22-student-v4'
    write(OUT/f"试题源稿/第{p['paper']}套.json",p)
write(PLAN/'六套逐题蓝图.json',rows)
spec=read(OUT/'题型规范.json')
spec['version']='2026-10-22-format-v4'
spec['paper_profiles']={str(p):'保守卷' if p<=3 else '适度创新卷' for p in range(1,7)}
spec['sections']['III']['response']='构造、计算、填写表格、执行过程；不设原因解释或性质证明小问'
spec['sections']['IV']['response']='清楚任务描述，统一要求基本思想、C语言实现、时间与辅助空间复杂度；本轮不另设小问'
spec['content_policy']={'authority':'用户2026-10-22本轮审题反馈，详见规划12号规则',
 'strong_references':'2024—2026本校802真题原资料；外校和408不作为强参考',
 'conservative_papers':[1,2,3],'moderate_innovation_papers':[4,5,6],
 'innovation_slot_cap':4,'cap_note':'本轮编辑选择，非用户指定比例',
 'complexity_fill_cap':{'conservative':0,'moderate_innovation':1},
 'naive_matching_total_cap':1,'algorithm_subquestions_this_revision':0}
write(OUT/'题型规范.json',spec)
review={'version':'2026-10-22-quality-v4','baseline':'2026-10-22-student-v3',
        'questions_reviewed':144,'changed_count':len(changes),'changes':changes,
        'policy':'12_用户审题意见与分层命题规则.md',
        'records':[{'id':r['id'],'paper_profile':r['paper_profile'],'innovation':r['innovation'],
                    'reference_alignment':r['reference_alignment'],'minutes':r['minutes'],
                    'student_sha256':r['student_content_sha256']} for r in rows]}
write(OUT/'内容复查核对.json',review)
oldformat=read(OUT/'题型修订核对.json')
oldformat['status']='历史第2版题型改造记录，不用于证明现行第4版题面通过'
oldformat['current_review']='内容复查核对.json'
write(OUT/'题型修订核对.json',oldformat)
write(PLAN/'蓝图数据复核.json',{'version':'2026-10-22-r6','status':'旧种子不适用于本轮换题',
 'count':0,'covered_ids':[],'records':[],
 'note':'第3版21项原型核验及绑定已随历史快照保留；未重新绑定到新题。当前逐题审校和专项核验见成稿目录审查与修订说明。'})
for name in ('history_evidence.md','history_evidence.json'):
    shutil.copy2(HERE/name,PLAN/('13_近三年802任务证据'+Path(name).suffix))
print('Migrated v4:',len(changes),'changed questions;', [sum(r['minutes'] for r in rows if r['paper']==p) for p in range(1,7)])
