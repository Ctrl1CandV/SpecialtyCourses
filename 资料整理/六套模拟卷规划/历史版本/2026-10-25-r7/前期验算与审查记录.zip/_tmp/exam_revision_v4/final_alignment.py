from pathlib import Path
import json,hashlib,sys
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'资料整理/六套模拟卷成稿';PLAN=ROOT/'资料整理/六套模拟卷规划'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
rows=read(PLAN/'六套逐题蓝图.json');r={x['id']:x for x in rows}
r['S3-II10'].update(mode='改编',source_ids=['真题-2026-填空11'],history_ids=['真题-2026-填空11'],data='23结点；每结点左右孩子指针各1',reference_alignment='2026回忆卷物理p4填空11：n结点二叉链表空指针计数。题目将n具体化为23，采用同型数值改编；回忆稿并非官方原卷。')
r['S4-III04'].update(history_ids=['真题-2026-综合21'],reference_alignment='2026回忆卷物理p6综合21为Dijkstra计算；原图数据不完整，仅支持任务形式。当前图与数值另编，未以2024年的Floyd题冒充直接同型。')
r['S4-III06'].update(history_ids=['真题-2024-综合6','真题-2026-综合18'],reference_alignment='2024原PDF物理p6综合6含BST、AVL与ASL；2026回忆卷物理p5综合18含BST/AVL构造。当前插入序列另编，属同型练习。')
r['S3-III01'].update(history_ids=['真题-2026-综合16','真题-2025-综合1','真题-2024-综合3'],reference_alignment='2026回忆卷物理p5综合16支持由两种遍历重建；2025原PDF物理p11综合1支持后序和线索，2024物理p5综合3支持线索化。现题组合这些已见任务，不能把2025的BST先序重建称为一般双序重建。')
for x in rows:
    x['transfer']=x['reference_alignment']
    if x['id'] in ('S3-II10','S4-III04','S4-III06','S3-III01'):x['pdf_evidence']=x['reference_alignment']
    x['source_policy']='直接题型改编，数据和题面调整' if x['source_ids'] else '仅历史方法/任务锚点，具体题目另编'
p=read(OUT/'试题源稿/第3套.json');q=next(q for q in p['questions'] if q['id']=='S3-II10')
assert '18' in q['content'];q['content']=q['content'].replace('18','23')
r[q['id']]['student_content_sha256']=hashlib.sha256(q['content'].encode('utf8')).hexdigest()
write(OUT/'试题源稿/第3套.json',p)
write(ROOT/'_tmp/exam_revision_v4/paper3.json',p)
write(PLAN/'六套逐题蓝图.json',rows)
audit=read(OUT/'内容复查核对.json')
for x in audit['records']+audit['changes']:
    x['student_sha256']=r[x['id']]['student_content_sha256']
    if 'reference_alignment' in x:x['reference_alignment']=r[x['id']]['reference_alignment']
write(OUT/'内容复查核对.json',audit)
# Rebuild only the changed paper, retaining other already-reviewed PDFs.
sys.path.insert(0,str(ROOT/'tools'));import build_exam_papers as b
d=b.load_paper(3);assert not b.validate(d);b.init_pdf();b.check_font_coverage([d])
target=b.PDF_DIR/'重邮802模拟试卷第3套.pdf'
spaces,qpages=b.build_pdf(d,target);b.render_pdf(target)
(b.MD_DIR/'第3套试卷.md').write_text(b.markdown(d),encoding='utf8')
structure=read(OUT/'成卷结构核对.json')
from pypdf import PdfReader
s=next(x for x in structure['papers'] if x['paper']==3)
s.update(pages=len(PdfReader(target).pages),answer_spaces=spaces,question_pages=qpages,source_sha256=hashlib.sha256((OUT/'试题源稿/第3套.json').read_bytes()).hexdigest())
write(OUT/'成卷结构核对.json',structure);b.merge_all()
print('Final source alignment and paper3 rebuild complete.')
